Reviewing `T-0355` as the PM-style reviewer. I’m checking the actual prompt output, the serializer tests, and whether the retry summary behaves correctly without leaking the rejection reason.

```tool
output:
tests/lifecycle/test_agent_retries.py
tests/lifecycle/test_recovery_role.py
tests/lifecycle/test_hook_config.py
tests/lifecycle/test_sqlite_adapters.py
tests/lifecycle/test_last_report.py
tests/lifecycle/test_hooks_and_commit.py
tests/lifecycle/test_hook_reject_circuit_breaker.py
tests/lifecycle/test_worktree_sync.py
tests/lifecycle/test_transitions.py
tests/lifecycle/test_journal_cli.py
tests/lifecycle/test_pre_exec_probe.py
tests/lifecycle/test_engine_adapter.py
tests/lifecycle/test_prompt_serializer.py
litehive/lifecycle/prompt_serializer.py
litehive/lifecycle/runner.py
litehive/lifecycle/nodes/hook.py
litehive/lifecycle/nodes/base.py
litehive/lifecycle/nodes/__init__.py
litehive/lifecycle/nodes/agent.py
litehive/lifecycle/nodes/system.py
litehive/lifecycle/nodes/terminal.py
litehive/lifecycle/registry.py
litehive/lifecycle/sessions.py
litehive/lifecycle/guards.py
litehive/lifecycle/events.py
litehive/lifecycle/types.py
litehive/lifecycle/stages.py
litehive/lifecycle/transitions.py
litehive/lifecycle/orchestration.py
litehive/lifecycle/persistence.py
litehive/lifecycle/rules.py
litehive/lifecycle/engines.py
litehive/lifecycle/journal.py
litehive/lifecycle/__init__.py
litehive/lifecycle/heru_factory.py
```

```tool
output:
litehive/config/engine_models.py:357:def _resolve_stage_retry_limit(task: TaskRecord, config: LitehiveConfig) -> int:
litehive/config/engine_models.py:358:    if task.retry_policy.stage_retry_limit is not None:
litehive/config/engine_models.py:359:        return task.retry_policy.stage_retry_limit
litehive/config/engine_models.py:360:    return config.default_stage_retry_limit
litehive/config/model.py:110:    default_stage_retry_limit: int = 2
litehive/lifecycle/prompt_serializer.py:13:  - surfaces ``last_rejection`` so the next agent visit can act on it
litehive/lifecycle/prompt_serializer.py:64:    last_rejection = prompt.get("last_rejection")
litehive/lifecycle/prompt_serializer.py:65:    if last_rejection:
litehive/lifecycle/prompt_serializer.py:66:        sections.append(_last_rejection_section(last_rejection))
litehive/lifecycle/prompt_serializer.py:68:    if (prompt.get("stage_retry") or 0) > 0:
litehive/lifecycle/prompt_serializer.py:69:        prior_work = _prior_work_section(prompt.get("last_report") or {}, last_rejection)
litehive/lifecycle/prompt_serializer.py:89:                last_rejection=last_rejection,
litehive/lifecycle/prompt_serializer.py:130:    retry = prompt.get("stage_retry") or 0
litehive/lifecycle/prompt_serializer.py:177:def _last_rejection_section(rejection: dict[str, Any]) -> str:
litehive/lifecycle/prompt_serializer.py:193:def _prior_work_section(last_report: dict[str, Any], last_rejection: dict[str, Any] | None = None) -> str:
litehive/lifecycle/prompt_serializer.py:194:    changed_files = _string_list(last_report.get("changed_files"))
litehive/lifecycle/prompt_serializer.py:195:    test_results = _string_list(last_report.get("test_results"))
litehive/lifecycle/prompt_serializer.py:196:    rejection_reason = str((last_rejection or {}).get("reason") or "").strip()
litehive/lifecycle/prompt_serializer.py:204:        files_changed = int(last_report.get("files_changed") or 0)
litehive/lifecycle/prompt_serializer.py:213:    return "Prior work (last attempt):\n" + "\n".join(lines)
litehive/lifecycle/prompt_serializer.py:309:def _matches_last_rejection(entry: dict[str, Any], last_rejection: dict[str, Any]) -> bool:
litehive/lifecycle/prompt_serializer.py:313:    rejection_source = str(last_rejection.get("source") or "").strip()
litehive/lifecycle/prompt_serializer.py:317:    rejection_stage = _pipeline_stage_key(str(last_rejection.get("raised_at_phase") or "").strip() or None)
litehive/lifecycle/prompt_serializer.py:322:    rejection_reason = str(last_rejection.get("reason") or "")
litehive/lifecycle/prompt_serializer.py:332:    last_rejection: dict[str, Any] | None = None,
litehive/lifecycle/prompt_serializer.py:338:    - Never duplicate an entry whose content matches last_rejection (already
litehive/lifecycle/prompt_serializer.py:355:    # Skip entries that duplicate last_rejection
litehive/lifecycle/prompt_serializer.py:356:    if last_rejection:
litehive/lifecycle/prompt_serializer.py:357:        thread = [entry for entry in thread if not _matches_last_rejection(entry, last_rejection)]
litehive/lifecycle/prompt_serializer.py:374:        # On retry, the rejection is rendered in the dedicated last_rejection
litehive/lifecycle/prompt_serializer.py:376:        if not last_rejection:
litehive/lifecycle/prompt_serializer.py:429:    last_rejection: dict[str, Any] | None = None,
litehive/lifecycle/prompt_serializer.py:431:    trimmed = _trim_thread_for_prompt(thread, current_stage, last_rejection)
litehive/cli/pipeline_cli.py:110:    if state.stage_retry:
litehive/cli/pipeline_cli.py:111:        print(f"stage_retry: {dict(state.stage_retry)}")
litehive/cli/pipeline_cli.py:118:    if state.last_rejection_by_stage:
litehive/cli/pipeline_cli.py:119:        print("last_rejection_by_stage:")
litehive/cli/pipeline_cli.py:120:        for stage, rej in state.last_rejection_by_stage.items():
litehive/lifecycle/runner.py:91:        and the Runner keeps ``state.last_report`` in sync so guards
litehive/lifecycle/runner.py:99:            state.last_report.files_changed = len(files_changed)
litehive/lifecycle/runner.py:100:            state.last_report.changed_files = [str(path).strip() for path in files_changed if str(path).strip()]
litehive/lifecycle/runner.py:102:            state.last_report.files_changed = files_changed
litehive/lifecycle/runner.py:105:            state.last_report.tests_added = tests_added
litehive/lifecycle/runner.py:106:        last_report = meta.get("last_report")
litehive/lifecycle/runner.py:107:        if isinstance(last_report, dict):
litehive/lifecycle/runner.py:108:            changed_files = last_report.get("changed_files")
litehive/lifecycle/runner.py:110:                state.last_report.changed_files = [str(path).strip() for path in changed_files if str(path).strip()]
litehive/lifecycle/runner.py:111:            test_results = last_report.get("test_results")
litehive/lifecycle/runner.py:113:                state.last_report.test_results = [str(item).strip() for item in test_results if str(item).strip()]
litehive/lifecycle/runner.py:150:        if delta.inc_stage_retry is not None:
litehive/lifecycle/runner.py:151:            stage = delta.inc_stage_retry
litehive/lifecycle/runner.py:152:            state.stage_retry[stage] = state.stage_retry.get(stage, 0) + 1
litehive/lifecycle/runner.py:153:        if delta.reset_stage_retry is not None:
litehive/lifecycle/runner.py:154:            state.stage_retry.pop(delta.reset_stage_retry, None)
litehive/lifecycle/runner.py:167:        if delta.set_last_rejection is not None:
litehive/lifecycle/runner.py:168:            stage, rejection = delta.set_last_rejection
litehive/lifecycle/runner.py:169:            state.last_rejection_by_stage[stage] = rejection
tests/lifecycle/test_sqlite_adapters.py:61:    store = SqlitePersistence(workspace, limits=Limits(stage_retry_limit=5))
tests/lifecycle/test_sqlite_adapters.py:67:        stage_retry={"implementing": 2, "testing": 1},
tests/lifecycle/test_sqlite_adapters.py:102:        last_report=LastReport(
tests/lifecycle/test_sqlite_adapters.py:108:        last_rejection_by_stage={
tests/lifecycle/test_sqlite_adapters.py:133:    assert loaded.stage_retry == {"implementing": 2, "testing": 1}
tests/lifecycle/test_sqlite_adapters.py:144:    assert loaded.last_report.files_changed == 7
tests/lifecycle/test_sqlite_adapters.py:145:    assert loaded.last_report.tests_added == 3
tests/lifecycle/test_sqlite_adapters.py:146:    assert loaded.last_report.changed_files == [
tests/lifecycle/test_sqlite_adapters.py:150:    assert loaded.last_report.test_results == [
tests/lifecycle/test_sqlite_adapters.py:153:    assert loaded.last_rejection_by_stage["implementing"].source == "qa"
tests/lifecycle/test_sqlite_adapters.py:154:    assert loaded.last_rejection_by_stage["implementing"].reason == "tests fail"
tests/lifecycle/test_sqlite_adapters.py:160:    assert loaded.limits.stage_retry_limit == 5
tests/lifecycle/test_sqlite_adapters.py:169:    state.stage_retry["implementing"] = 1
tests/lifecycle/test_sqlite_adapters.py:174:    assert loaded.stage_retry == {"implementing": 1}
litehive/roles/base.py:88:        last_rejection = self._last_rejection_for_prompt(state)
litehive/roles/base.py:95:            "stage_retry": state.stage_retry.get(self.NODE_NAME, 0),
litehive/roles/base.py:97:            "last_report": state.last_report.to_payload(),
litehive/roles/base.py:98:            "last_rejection": (
litehive/roles/base.py:100:                    "source": last_rejection.source,
litehive/roles/base.py:101:                    "reason": last_rejection.reason,
litehive/roles/base.py:102:                    "raised_at_phase": last_rejection.raised_at_phase,
litehive/roles/base.py:104:                if last_rejection is not None
litehive/roles/base.py:111:    def _last_rejection_for_prompt(self, state: TaskState) -> LastRejection | None:
litehive/roles/base.py:120:        fallback = state.last_rejection_by_stage.get(self.NODE_NAME)
litehive/roles/base.py:129:        return state.last_rejection_by_stage.get(rejection_stage) or fallback
tests/lifecycle/test_last_report.py:1:"""Pass.metadata → state.last_report wiring tests.
tests/lifecycle/test_last_report.py:4:metadata. The Runner copies that into ``state.last_report`` after each
tests/lifecycle/test_last_report.py:55:def test_runner_updates_state_last_report_from_pass_metadata() -> None:
tests/lifecycle/test_last_report.py:56:    """Runner._apply_event_side_effects copies Pass.metadata into state.last_report."""
tests/lifecycle/test_last_report.py:62:            "last_report": {
tests/lifecycle/test_last_report.py:73:    assert state.last_report.files_changed == 2
tests/lifecycle/test_last_report.py:74:    assert state.last_report.tests_added == 3
tests/lifecycle/test_last_report.py:75:    assert state.last_report.changed_files == ["x.py", "y.py"]
tests/lifecycle/test_last_report.py:76:    assert state.last_report.test_results == [
litehive/lifecycle/guards.py:58:        return state.stage_retry.get(stage, 0) < state.limits.stage_retry_limit
litehive/lifecycle/guards.py:65:        return state.stage_retry.get(stage, 0) >= state.limits.stage_retry_limit
litehive/lifecycle/guards.py:82:        return state.last_report.files_changed == 0 and state.last_report.tests_added == 0
tests/lifecycle/test_prompt_serializer.py:210:def test_serialize_includes_last_rejection(workspace: Path) -> None:
tests/lifecycle/test_prompt_serializer.py:214:    state.last_rejection_by_stage["implementing"] = LastRejection(
tests/lifecycle/test_prompt_serializer.py:227:def test_retry_prompt_includes_prior_work_summary_from_last_report(workspace: Path) -> None:
tests/lifecycle/test_prompt_serializer.py:231:    state.stage_retry["implementing"] = 1
tests/lifecycle/test_prompt_serializer.py:232:    state.last_report = LastReport(
tests/lifecycle/test_prompt_serializer.py:246:    assert "Prior work (last attempt):" in text
tests/lifecycle/test_prompt_serializer.py:257:def test_retry_prompt_omits_prior_work_when_last_report_has_no_retry_summary(workspace: Path) -> None:
tests/lifecycle/test_prompt_serializer.py:261:    state.stage_retry["implementing"] = 1
tests/lifecycle/test_prompt_serializer.py:265:    assert "Prior work (last attempt):" not in text
tests/lifecycle/test_prompt_serializer.py:268:def test_retry_prompt_filters_last_rejection_reason_from_prior_work(workspace: Path) -> None:
tests/lifecycle/test_prompt_serializer.py:272:    state.stage_retry["implementing"] = 1
tests/lifecycle/test_prompt_serializer.py:273:    state.last_report = LastReport(
tests/lifecycle/test_prompt_serializer.py:281:    state.last_rejection_by_stage["implementing"] = LastRejection(
tests/lifecycle/test_prompt_serializer.py:289:    assert "Prior work (last attempt):" in text
tests/lifecycle/test_prompt_serializer.py:295:def test_last_rejection_guidance_respects_repo_contract_and_opt_in_coverage(workspace: Path) -> None:
tests/lifecycle/test_prompt_serializer.py:299:    state.last_rejection_by_stage["implementing"] = LastRejection(
tests/lifecycle/test_prompt_serializer.py:436:def test_implementing_retry_thread_keeps_only_grooming_and_dedups_last_rejection_by_source_and_reason(
tests/lifecycle/test_prompt_serializer.py:442:    state.stage_retry["implementing"] = 1
tests/lifecycle/test_prompt_serializer.py:443:    state.last_rejection_by_stage["implementing"] = LastRejection(
tests/lifecycle/test_prompt_serializer.py:495:    state.last_rejection_by_stage["implementing"] = LastRejection(
tests/lifecycle/test_prompt_serializer.py:500:    state.last_rejection_by_stage["testing"] = LastRejection(
tests/lifecycle/test_prompt_serializer.py:508:    assert prompt["last_rejection"] == {
tests/lifecycle/test_prompt_serializer.py:539:    state.last_rejection_by_stage["implementing"] = LastRejection(
tests/lifecycle/test_prompt_serializer.py:544:    state.last_rejection_by_stage["testing"] = LastRejection(
tests/lifecycle/test_prompt_serializer.py:552:    assert prompt["last_rejection"] == {
tests/lifecycle/test_prompt_serializer.py:567:        "last_rejection": {
tests/lifecycle/test_prompt_serializer.py:586:def test_thread_dedups_agent_reject_when_last_rejection_uses_generic_agent_source(workspace: Path) -> None:
tests/lifecycle/test_prompt_serializer.py:594:        "last_rejection": {
tests/lifecycle/test_prompt_serializer.py:620:        "last_rejection": {
tests/lifecycle/test_prompt_serializer.py:647:        "last_rejection": {
litehive/lifecycle/events.py:45:    reads it after each transition and updates ``state.last_report`` so
litehive/lifecycle/events.py:182:    retried more than ``Limits.stage_retry_limit`` times. Routes that
litehive/lifecycle/events.py:184:    ``inc_stage_retry`` / ``stage_retries_exhausted`` guard combo
tests/lifecycle/test_engine_adapter.py:546:    assert verdict.metadata["last_report"] == {
litehive/lifecycle/transitions.py:19:    inc_stage_retry,
litehive/lifecycle/transitions.py:173:                with_effect=inc_stage_retry(name),
litehive/cli/templates/workspace_config.yaml:37:default_stage_retry_limit: 2
litehive/domain/lifecycle_deltas.py:43:    inc_stage_retry: NodeName | None = None
litehive/domain/lifecycle_deltas.py:44:    reset_stage_retry: NodeName | None = None
litehive/domain/lifecycle_deltas.py:51:    set_last_rejection: tuple[NodeName, LastRejection] | None = None
litehive/domain/lifecycle_deltas.py:134:            fingerprint=f"stage_retry_limit:{event.stage}",
litehive/domain/lifecycle_deltas.py:135:            classification="stage_retry_limit",
litehive/domain/lifecycle_deltas.py:301:        reset_stage_retry=_retry_counter_stage(trigger.origin_stage if trigger is not None else None),
litehive/domain/lifecycle_deltas.py:310:def inc_stage_retry(stage: NodeName) -> EffectFn:
litehive/domain/lifecycle_deltas.py:322:            inc_stage_retry=stage,
litehive/domain/lifecycle_deltas.py:323:            set_last_rejection=set_rej,
litehive/domain/recovery.py:14:    STAGE_RETRY_LIMIT = "stage_retry_limit"
litehive/domain/common.py:57:    STAGE_RETRY_LIMIT_EXHAUSTED = "stage_retry_limit_exhausted"
litehive/lifecycle/persistence.py:15:    stage_retry_limit: int = 3
litehive/lifecycle/persistence.py:77:    Populated by the ``inc_stage_retry`` effect whenever a Reject event is
litehive/lifecycle/persistence.py:158:    stage_retry: dict[NodeName, int] = field(default_factory=dict)
litehive/lifecycle/persistence.py:164:    last_report: LastReport = field(default_factory=LastReport)
litehive/lifecycle/persistence.py:165:    last_rejection_by_stage: dict[NodeName, LastRejection] = field(default_factory=dict)
litehive/lifecycle/persistence.py:222:        "stage_retry": dict(state.stage_retry),
litehive/lifecycle/persistence.py:230:        "last_report": state.last_report.to_payload(),
litehive/lifecycle/persistence.py:231:        "last_rejection_by_stage": {stage: rej.to_payload() for stage, rej in state.last_rejection_by_stage.items()},
litehive/lifecycle/persistence.py:250:    last_report_data = payload.get("last_report") or {}
litehive/lifecycle/persistence.py:251:    last_rejections_data = payload.get("last_rejection_by_stage") or {}
litehive/lifecycle/persistence.py:262:        stage_retry=dict(payload.get("stage_retry") or {}),
litehive/lifecycle/persistence.py:274:        last_report=LastReport.from_payload(last_report_data),
litehive/lifecycle/persistence.py:275:        last_rejection_by_stage={
litehive/lifecycle/persistence.py:276:            stage_name: LastRejection.from_payload(rej) for stage_name, rej in last_rejections_data.items()
litehive/lifecycle/persistence.py:299:    (counters, recovery/merge details, last_rejection_by_stage, last_report, failed_*)
litehive/domain/task.py:17:    stage_retry_limit: int | None = None
litehive/lifecycle/heru_factory.py:154:            "last_report": {
litehive/domain/runtime.py:144:    stage_retry_counts: dict[str, int] = Field(default_factory=dict)
tests/lifecycle/test_transitions.py:48:    stage_retry: dict[str, int] | None = None,
tests/lifecycle/test_transitions.py:52:    stage_retry_limit: int = 3,
tests/lifecycle/test_transitions.py:61:        stage_retry=stage_retry or {},
tests/lifecycle/test_transitions.py:66:        last_report=LastReport(files_changed=files_changed, tests_added=tests_added),
tests/lifecycle/test_transitions.py:67:        limits=Limits(stage_retry_limit=stage_retry_limit),
tests/lifecycle/test_transitions.py:150:    state = make_state("implementing", stage_retry={"implementing": 0})
tests/lifecycle/test_transitions.py:153:    assert trans.delta.inc_stage_retry == "implementing"
tests/lifecycle/test_transitions.py:157:    state = make_state("implementing", stage_retry={"implementing": 3})
tests/lifecycle/test_transitions.py:162:def test_same_hook_reject_loop_trips_recovery_before_stage_retry_limit():
tests/lifecycle/test_transitions.py:163:    state = make_state("after_implementing", stage_retry={"implementing": 0})
tests/lifecycle/test_transitions.py:191:        stage_retry={"implementing": 0},
tests/lifecycle/test_transitions.py:217:    state = make_state("testing", stage_retry={"testing": 0})
tests/lifecycle/test_transitions.py:220:    assert trans.delta.inc_stage_retry == "testing"
tests/lifecycle/test_transitions.py:224:    state = make_state("accepting", stage_retry={"accepting": 0})
tests/lifecycle/test_transitions.py:227:    assert trans.delta.inc_stage_retry == "accepting"
litehive/observability/status.py:218:                f"last_report={runtime.last_stage.stage}/{runtime.last_stage.verdict} "
```

```tool
output:
 M litehive/lifecycle/heru_factory.py
 M litehive/lifecycle/persistence.py
 M litehive/lifecycle/prompt_serializer.py
 M litehive/lifecycle/runner.py
 M litehive/roles/base.py
 M tests/lifecycle/test_engine_adapter.py
 M tests/lifecycle/test_last_report.py
 M tests/lifecycle/test_prompt_serializer.py
 M tests/lifecycle/test_sqlite_adapters.py
 M uv.lock
```

I found the task-scoped changes in the serializer path plus support for carrying `last_report`. Next I’m reading the exact retry-summary logic and the new tests before I run verification.

```tool
output:
"""Serialize a v2 ``RoleAgent.build_prompt()`` dict into a string for engines.

The v2 ``RoleAgent`` returns a structured dict so the test layer can inspect
it and the engine adapter layer can format it however its CLI expects.
``serialize_prompt()`` produces the canonical text representation: a
section-based document an engine adapter can pipe to ``codex run`` or
``claude run`` etc.

The serializer:
  - reads the v1 ``TaskRecord`` for goal / acceptance / plan / constraints
    (the dict only carries task_id; the rest comes from task.yaml)
  - composes the four instruction layers from the dict
  - surfaces ``last_rejection`` so the next agent visit can act on it
  - surfaces ``recovery_trigger`` for recovery agents
  - finishes with the ``litehive report`` verdict instructions

"""

from pathlib import Path
from typing import Any

from pydantic import ValidationError
import yaml

from litehive.domain.task import TaskRecord
from litehive.state.records import get_task
from litehive.tasks.activity import load_task_activity


SECTION_SEP = "\n"


def serialize_prompt(
    prompt: dict[str, Any],
    *,
    task_record: TaskRecord | None,
    workspace_root: Path | None = None,
) -> str:
    """Render the prompt dict + task record into the engine-facing string.

    ``task_record`` is optional so tests don't need to construct one;
    if ``None``, the goal/acceptance/plan/constraints sections are
    omitted with placeholders. ``workspace_root`` is optional and used
    for two things: (1) fall back to ``get_task()`` if the caller
    didn't already resolve the TaskRecord, and (2) load the task's
    discussion thread so the next agent visit sees previous stage
    verdicts.
    """
    if task_record is None and workspace_root is not None:
        task_record = get_task(workspace_root, prompt["task_id"])

    thread = prompt.get("thread") or []
    if not thread and workspace_root is not None and task_record is not None:
        thread = _load_task_activity_history(workspace_root, task_record)

    sections: list[str] = []
    sections.append(_header_section(prompt, task_record))
    sections.append(_instructions_section(prompt))
    sections.append(_goal_section(task_record))
    sections.append(_acceptance_criteria_section(task_record))
    sections.append(_plan_section(task_record))
    sections.append(_constraints_section(task_record))

    last_rejection = prompt.get("last_rejection")
    if last_rejection:
        sections.append(_last_rejection_section(last_rejection))

    if (prompt.get("stage_retry") or 0) > 0:
        prior_work = _prior_work_section(prompt.get("last_report") or {}, last_rejection)
        if prior_work:
            sections.append(prior_work)

    recovery_trigger = prompt.get("recovery_trigger")
    if recovery_trigger:
        sections.append(_recovery_trigger_section(recovery_trigger, prompt))

    conflict_files = prompt.get("conflict_files")
    if conflict_files:
        sections.append(_merge_conflict_section(conflict_files, prompt.get("merge_attempt")))

    if prompt.get("nudge"):
        sections.append(_nudge_section(prompt))

    if thread:
        sections.append(
            _thread_section(
                thread,
                current_stage=prompt.get("stage"),
                last_rejection=last_rejection,
            )
        )

    runner_hooks = prompt.get("runner_hooks")
    if runner_hooks is None:
        runner_hooks = prompt.get("rejecting_hooks") or []
    if runner_hooks:
        sections.append(_runner_hooks_section(prompt.get("stage"), runner_hooks))

    sections.append(_verdict_instructions_section(prompt))
    return (SECTION_SEP * 2).join(s for s in sections if s).strip() + "\n"


def _load_task_activity_history(workspace_root: Path, task_record: TaskRecord) -> list[dict[str, Any]]:
    """Read the task's persisted activity entries."""
    try:
        comments = load_task_activity(workspace_root, task_record)
    except (OSError, ValidationError, yaml.YAMLError):
        return []
    return [
        {
            "role": c.role,
            "stage": c.stage,
            "verdict": c.verdict,
            "message": c.message,
        }
        for c in comments
    ]


# ── section builders ────────────────────────────────────────────────────


def _header_section(prompt: dict[str, Any], task_record: TaskRecord | None) -> str:
    lines = [
        f"Task: {prompt['task_id']}" + (f" — {task_record.title}" if task_record is not None else ""),
        f"Stage: {prompt['stage']}",
        f"Role: {prompt['role']}",
        f"Pipeline mode: {prompt['pipeline_mode']}",
    ]
    retry = prompt.get("stage_retry") or 0
    if retry:
        lines.append(f"Stage retry attempt: {retry}")
    return "\n".join(lines)


def _instructions_section(prompt: dict[str, Any]) -> str:
    layers = prompt.get("instruction_layers") or []
    if not layers:
        return ""
    blocks: list[str] = []
    for label, text in layers:
        if not text:
            continue
        blocks.append(f"## {_label_to_heading(label)}\n{text.strip()}")
    if not blocks:
        return ""
    return "Instructions:\n\n" + "\n\n".join(blocks)


def _goal_section(task_record: TaskRecord | None) -> str:
    if task_record is None:
        return "Goal:\n(task record not loaded)"
    return f"Goal:\n{task_record.goal or task_record.title}"


def _acceptance_criteria_section(task_record: TaskRecord | None) -> str:
    if task_record is None or not task_record.acceptance_criteria:
        return "Acceptance criteria:\n- (none defined)"
    bullets = "\n".join(f"- {c}" for c in task_record.acceptance_criteria)
    return f"Acceptance criteria:\n{bullets}"


def _plan_section(task_record: TaskRecord | None) -> str:
    if task_record is None or not task_record.plan:
        return "Plan:\n- (no plan)"
    bullets = "\n".join(f"- {step}" for step in task_record.plan)
    return f"Plan:\n{bullets}"


def _constraints_section(task_record: TaskRecord | None) -> str:
    if task_record is None or not task_record.constraints:
        return "Constraints:\n- Keep changes scoped to the task."
    bullets = "\n".join(f"- {c}" for c in task_record.constraints)
    return f"Constraints:\n{bullets}"


def _last_rejection_section(rejection: dict[str, Any]) -> str:
    return (
        "Last rejection (previous attempt at this stage):\n"
        f"- Source: {rejection.get('source')}\n"
        f"- Raised at phase: {rejection.get('raised_at_phase')}\n"
        f"- Reason: {rejection.get('reason')}\n"
        "\n"
        "Rules when responding to a rejection:\n"
        "- Read every failure above. Resolve the ones required by the acceptance criteria, the repo's documented verification contract, or your changed surface.\n"
        "- Do not dismiss a failure as stale, unrelated, or environmental without current evidence from this worktree.\n"
        "- Reproduce the cited commands when they are still the correct contract for this task. If the repo documents a narrower default suite or the cited command is opt-in or external coverage, explain that and run the appropriate verification instead.\n"
        "- If the rejection itself appears to come from Litehive prompt or pipeline behavior rather than task code, call that out explicitly so recovery can fix the infrastructure.\n"
        "- Before `pass`: rerun the commands you are relying on and include output as evidence."
    )


def _prior_work_section(last_report: dict[str, Any], last_rejection: dict[str, Any] | None = None) -> str:
    changed_files = _string_list(last_report.get("changed_files"))
    test_results = _string_list(last_report.get("test_results"))
    rejection_reason = str((last_rejection or {}).get("reason") or "").strip()
    if rejection_reason:
        test_results = [result for result in test_results if rejection_reason not in result]

    lines: list[str] = []
    if changed_files:
        lines.append(f"- Changed files: {_compact_list(changed_files, limit=4)}")
    else:
        files_changed = int(last_report.get("files_changed") or 0)
        if files_changed:
            lines.append(f"- Files changed: {files_changed}")

    if test_results:
        lines.append(f"- Test results: {_compact_list(test_results, limit=2, separator='; ')}")

    if not lines:
        return ""
    return "Prior work (last attempt):\n" + "\n".join(lines)


def _recovery_trigger_section(recovery_trigger: dict[str, Any], prompt: dict[str, Any]) -> str:
    lines = ["Recovery trigger (what sent the task into recovery):"]
    for key, value in recovery_trigger.items():
        lines.append(f"- {key}: {value}")
    explanation = prompt.get("recovery_failure_explanation")
    if explanation:
        lines.append(f"- recovery_failure_explanation: {explanation}")
    return "\n".join(lines)


def _merge_conflict_section(conflict_files: list[str], merge_attempt: int | None) -> str:
    bullets = "\n".join(f"- {f}" for f in conflict_files)
    extra = f"\nMerge attempt: {merge_attempt}" if merge_attempt is not None else ""
    return f"Merge conflict files (resolve all of these):\n{bullets}{extra}"


def _nudge_section(prompt: dict[str, Any]) -> str:
    message = str(prompt.get("nudge_message") or "").strip()
    lines = [
        "IMPORTANT: this is a nudge because your prior turn ended without a verdict submission.",
    ]
    if message:
        lines.append(message)
    lines.append(
        "Do not continue exploratory work until you have submitted `litehive report` with the correct verdict."
    )
    return "\n".join(lines)


_MESSAGE_CAP = 500
_TRUNCATION_MARKER = "…(truncated)"


def _cap_message(entry: dict[str, Any]) -> dict[str, Any]:
    """Return a shallow copy with message capped to _MESSAGE_CAP chars total."""
    msg = entry.get("message", "")
    if len(msg) <= _MESSAGE_CAP:
        return entry
    keep = max(_MESSAGE_CAP - len(_TRUNCATION_MARKER), 0)
    return {**entry, "message": msg[:keep] + _TRUNCATION_MARKER}


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
```

```tool
output:
diff --git a/litehive/lifecycle/heru_factory.py b/litehive/lifecycle/heru_factory.py
index 4b2f8242..d0c14b14 100644
--- a/litehive/lifecycle/heru_factory.py
+++ b/litehive/lifecycle/heru_factory.py
@@ -19,6 +19,7 @@ translating to/from the v2 contract:
 
 from datetime import UTC, datetime
 from pathlib import Path
+import re
 from typing import Any
 
 from heru import resolve_engine_resume_session_id
@@ -27,6 +28,7 @@ from litehive.domain.agent import EngineFailure
 from litehive.git.ops import GitError, current_head, is_git_repo, status_porcelain
 from litehive.state.records import get_task
 from litehive.tasks.activity import latest_task_activity_entry
+from litehive.tasks.reports import normalized_files_changed
 from litehive.tasks.worktrees import resolve_recorded_worktree_path
 
 from .nodes.agent import (
@@ -72,6 +74,41 @@ def _execution_checkout_has_changes(workspace_root: Path, task_id: str) -> bool:
     return workspace_head != checkout_head
 
 
+_REPORT_RESULT_HINTS = (
+    "pytest",
+    "ruff",
+    "mypy",
+    "test",
+    "tests",
+    "passed",
+    "failed",
+    "error",
+    "ok",
+    "verification",
+    "verified",
+    "status --full",
+)
+
+
+def _extract_test_results(message: str) -> list[str]:
+    results: list[str] = []
+    seen: set[str] = set()
+    for raw_line in message.splitlines():
+        line = re.sub(r"^\s*(?:[-*]|\d+\.)\s*", "", raw_line).strip()
+        if not line:
+            continue
+        lower = line.lower()
+        if lower.startswith(("files changed:", "changed files:", "files:")):
+            continue
+        if not any(hint in lower for hint in _REPORT_RESULT_HINTS):
+            continue
+        if line in seen:
+            continue
+        seen.add(line)
+        results.append(line)
+    return results[:4]
+
+
 def _latest_verdict_after(
     workspace_root: Path,
     task_id: str,
@@ -107,12 +144,17 @@ def _latest_verdict_after(
                 "workspace base, so no work landed"
             ),
         )
+    changed_files = normalized_files_changed(latest.files_changed)
     return AgentVerdict(
         outcome=latest.verdict,
         reason=latest.message or "",
         metadata={
-            "files_changed": list(latest.files_changed),
+            "files_changed": changed_files,
             "target_stage": latest.target_stage,
+            "last_report": {
+                "changed_files": changed_files,
+                "test_results": _extract_test_results(latest.message or ""),
+            },
         },
     )
 
diff --git a/litehive/lifecycle/persistence.py b/litehive/lifecycle/persistence.py
index 64415b91..a5ae9aef 100644
--- a/litehive/lifecycle/persistence.py
+++ b/litehive/lifecycle/persistence.py
@@ -23,18 +23,25 @@ class Limits:
 class LastReport:
     files_changed: int = 0
     tests_added: int = 0
+    changed_files: list[str] = field(default_factory=list)
+    test_results: list[str] = field(default_factory=list)
 
-    def to_payload(self) -> dict[str, int]:
+    def to_payload(self) -> dict[str, int | list[str]]:
         return {
             "files_changed": self.files_changed,
             "tests_added": self.tests_added,
+            "changed_files": list(self.changed_files),
+            "test_results": list(self.test_results),
         }
 
     @classmethod
     def from_payload(cls, payload: dict[str, Any]) -> "LastReport":
+        files_changed = payload.get("files_changed", 0)
         return cls(
-            files_changed=int(payload.get("files_changed", 0)),
+            files_changed=len(files_changed) if isinstance(files_changed, list) else int(files_changed),
             tests_added=int(payload.get("tests_added", 0)),
+            changed_files=_string_list(payload.get("changed_files")),
+            test_results=_string_list(payload.get("test_results")),
         )
 
 
@@ -192,6 +199,20 @@ class InMemoryPersistence:
         return self._states[task_id]
 
 
+def _string_list(value: Any) -> list[str]:
+    if not isinstance(value, list):
+        return []
+    normalized: list[str] = []
+    seen: set[str] = set()
+    for item in value:
+        text = str(item).strip()
+        if not text or text in seen:
+            continue
+        seen.add(text)
+        normalized.append(text)
+    return normalized
+
+
 # ── sqlite-backed persistence ────────────────────────────────────────────
 
 
diff --git a/litehive/lifecycle/prompt_serializer.py b/litehive/lifecycle/prompt_serializer.py
index 712bfe43..0f6f37cf 100644
--- a/litehive/lifecycle/prompt_serializer.py
+++ b/litehive/lifecycle/prompt_serializer.py
@@ -65,6 +65,11 @@ def serialize_prompt(
     if last_rejection:
         sections.append(_last_rejection_section(last_rejection))
 
+    if (prompt.get("stage_retry") or 0) > 0:
+        prior_work = _prior_work_section(prompt.get("last_report") or {}, last_rejection)
+        if prior_work:
+            sections.append(prior_work)
+
     recovery_trigger = prompt.get("recovery_trigger")
     if recovery_trigger:
         sections.append(_recovery_trigger_section(recovery_trigger, prompt))
@@ -185,6 +190,29 @@ def _last_rejection_section(rejection: dict[str, Any]) -> str:
     )
 
 
+def _prior_work_section(last_report: dict[str, Any], last_rejection: dict[str, Any] | None = None) -> str:
+    changed_files = _string_list(last_report.get("changed_files"))
+    test_results = _string_list(last_report.get("test_results"))
+    rejection_reason = str((last_rejection or {}).get("reason") or "").strip()
+    if rejection_reason:
+        test_results = [result for result in test_results if rejection_reason not in result]
+
+    lines: list[str] = []
+    if changed_files:
+        lines.append(f"- Changed files: {_compact_list(changed_files, limit=4)}")
+    else:
+        files_changed = int(last_report.get("files_changed") or 0)
+        if files_changed:
+            lines.append(f"- Files changed: {files_changed}")
+
+    if test_results:
+        lines.append(f"- Test results: {_compact_list(test_results, limit=2, separator='; ')}")
+
+    if not lines:
+        return ""
+    return "Prior work (last attempt):\n" + "\n".join(lines)
+
+
 def _recovery_trigger_section(recovery_trigger: dict[str, Any], prompt: dict[str, Any]) -> str:
     lines = ["Recovery trigger (what sent the task into recovery):"]
     for key, value in recovery_trigger.items():
@@ -227,6 +255,27 @@ def _cap_message(entry: dict[str, Any]) -> dict[str, Any]:
     return {**entry, "message": msg[:keep] + _TRUNCATION_MARKER}
 
 
+def _string_list(value: Any) -> list[str]:
+    if not isinstance(value, list):
+        return []
+    normalized: list[str] = []
+    seen: set[str] = set()
+    for item in value:
+        text = str(item).strip()
+        if not text or text in seen:
+            continue
+        seen.add(text)
+        normalized.append(text)
+    return normalized
+
+
+def _compact_list(items: list[str], *, limit: int, separator: str = ", ") -> str:
+    if len(items) <= limit:
+        return separator.join(items)
+    shown = separator.join(items[:limit])
+    return f"{shown}{separator}+{len(items) - limit} more"
+
+
 def _pipeline_stage_key(name: str | None) -> str | None:
     if name in {"before_grooming", "grooming", "after_grooming"}:
         return "grooming"
diff --git a/litehive/lifecycle/runner.py b/litehive/lifecycle/runner.py
index 0c01d9c1..a8871320 100644
--- a/litehive/lifecycle/runner.py
+++ b/litehive/lifecycle/runner.py
@@ -97,11 +97,20 @@ class StateMachineRunner:
         files_changed = meta.get("files_changed")
         if isinstance(files_changed, list):
             state.last_report.files_changed = len(files_changed)
+            state.last_report.changed_files = [str(path).strip() for path in files_changed if str(path).strip()]
         elif isinstance(files_changed, int):
             state.last_report.files_changed = files_changed
         tests_added = meta.get("tests_added")
         if isinstance(tests_added, int):
             state.last_report.tests_added = tests_added
+        last_report = meta.get("last_report")
+        if isinstance(last_report, dict):
+            changed_files = last_report.get("changed_files")
+            if isinstance(changed_files, list):
+                state.last_report.changed_files = [str(path).strip() for path in changed_files if str(path).strip()]
+            test_results = last_report.get("test_results")
+            if isinstance(test_results, list):
+                state.last_report.test_results = [str(item).strip() for item in test_results if str(item).strip()]
         commit_result = meta.get("commit_result")
         if isinstance(commit_result, dict):
             head_sha = commit_result.get("head_sha")
diff --git a/tests/lifecycle/test_engine_adapter.py b/tests/lifecycle/test_engine_adapter.py
index 1ae63ab3..793f27de 100644
--- a/tests/lifecycle/test_engine_adapter.py
+++ b/tests/lifecycle/test_engine_adapter.py
@@ -508,6 +508,53 @@ def test_latest_verdict_after_allows_real_implementing_pass(tmp_path, monkeypatc
     assert verdict.outcome == "pass"
 
 
+def test_latest_verdict_after_includes_retry_summary_metadata(tmp_path, monkeypatch) -> None:
+    from litehive.state.records import create_task
+
+    task = create_task(tmp_path, title="retry summary")
+    append_activity_entry(
+        tmp_path,
+        task,
+        TaskActivityEntry(
+            role="swe",
+            stage="implementing",
+            verdict="pass",
+            message=(
+                "AC1: `uv run pytest -q tests/lifecycle/test_prompt_serializer.py` -> 8 passed\n"
+                "AC2: `uv run ruff check --select E402,F401 litehive tests` -> all checks passed"
+            ),
+            files_changed=[
+                "litehive/lifecycle/prompt_serializer.py",
+                "tests/lifecycle/test_prompt_serializer.py",
+            ],
+        ),
+    )
+    monkeypatch.setattr(
+        "litehive.lifecycle.heru_factory._execution_checkout_has_changes",
+        lambda workspace_root, task_id: True,
+    )
+
+    verdict = _latest_verdict_after(
+        tmp_path,
+        task.id,
+        "implementing",
+        datetime.now(UTC) - timedelta(minutes=1),
+    )
+
+    assert verdict is not None
+    assert verdict.outcome == "pass"
+    assert verdict.metadata["last_report"] == {
+        "changed_files": [
+            "litehive/lifecycle/prompt_serializer.py",
+            "tests/lifecycle/test_prompt_serializer.py",
+        ],
+        "test_results": [
+            "AC1: `uv run pytest -q tests/lifecycle/test_prompt_serializer.py` -> 8 passed",
+            "AC2: `uv run ruff check --select E402,F401 litehive tests` -> all checks passed",
+        ],
+    }
+
+
 def test_latest_verdict_after_accepts_recovery_resume(tmp_path) -> None:
     from litehive.state.records import create_task
 
diff --git a/tests/lifecycle/test_last_report.py b/tests/lifecycle/test_last_report.py
index 973095da..1b8d20a2 100644
--- a/tests/lifecycle/test_last_report.py
+++ b/tests/lifecycle/test_last_report.py
@@ -55,9 +55,24 @@ def test_agent_verdict_metadata_flows_into_pass_event() -> None:
 def test_runner_updates_state_last_report_from_pass_metadata() -> None:
     """Runner._apply_event_side_effects copies Pass.metadata into state.last_report."""
     state = TaskState(task_id="T-0001", stage="implementing", pipeline_mode=PipelineMode.FULL)
-    event = Pass(metadata={"files_changed": ["x.py", "y.py"], "tests_added": 3})
+    event = Pass(
+        metadata={
+            "files_changed": ["x.py", "y.py"],
+            "tests_added": 3,
+            "last_report": {
+                "changed_files": ["x.py", "y.py"],
+                "test_results": [
+                    "uv run pytest -q tests/lifecycle/test_prompt_serializer.py -> 3 passed",
+                ],
+            },
+        }
+    )
 
     StateMachineRunner._apply_event_side_effects(state, event)
 
     assert state.last_report.files_changed == 2
     assert state.last_report.tests_added == 3
+    assert state.last_report.changed_files == ["x.py", "y.py"]
+    assert state.last_report.test_results == [
+        "uv run pytest -q tests/lifecycle/test_prompt_serializer.py -> 3 passed",
+    ]
diff --git a/tests/lifecycle/test_prompt_serializer.py b/tests/lifecycle/test_prompt_serializer.py
index c93d239d..6f3955ed 100644
--- a/tests/lifecycle/test_prompt_serializer.py
+++ b/tests/lifecycle/test_prompt_serializer.py
@@ -19,7 +19,7 @@ from litehive.domain.lifecycle_deltas import StateDelta
 from litehive.domain.reports import TaskActivityEntry
 from litehive.lifecycle.events import HookOk, Pass, Reject
 from litehive.lifecycle.journal import SqliteJournal
-from litehive.lifecycle.persistence import LastRejection, TaskState
+from litehive.lifecycle.persistence import LastRejection, LastReport, TaskState
 from litehive.lifecycle.prompt_serializer import serialize_prompt
 from litehive.lifecycle.types import PipelineMode
 from litehive.state.records import create_task, save_task
@@ -224,6 +224,74 @@ def test_serialize_includes_last_rejection(workspace: Path) -> None:
     assert "tests fail with ImportError" in text
 
 
+def test_retry_prompt_includes_prior_work_summary_from_last_report(workspace: Path) -> None:
+    task = create_task(workspace, title="t", goal="g")
+    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
+    state = make_state(task.id)
+    state.stage_retry["implementing"] = 1
+    state.last_report = LastReport(
+        files_changed=2,
+        changed_files=[
+            "litehive/lifecycle/prompt_serializer.py",
+            "tests/lifecycle/test_prompt_serializer.py",
+        ],
+        test_results=[
+            "uv run pytest -q tests/lifecycle/test_prompt_serializer.py -> 8 passed",
+            "uv run ruff check --select E402,F401 litehive tests -> all checks passed",
+        ],
+    )
+
+    text = serialize_prompt(agent.build_prompt(state), task_record=task)
+
+    assert "Prior work (last attempt):" in text
+    assert (
+        "- Changed files: litehive/lifecycle/prompt_serializer.py, "
+        "tests/lifecycle/test_prompt_serializer.py"
+    ) in text
+    assert (
+        "- Test results: uv run pytest -q tests/lifecycle/test_prompt_serializer.py -> 8 passed; "
+        "uv run ruff check --select E402,F401 litehive tests -> all checks passed"
+    ) in text
+
+
+def test_retry_prompt_omits_prior_work_when_last_report_has_no_retry_summary(workspace: Path) -> None:
+    task = create_task(workspace, title="t", goal="g")
+    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
+    state = make_state(task.id)
+    state.stage_retry["implementing"] = 1
+
+    text = serialize_prompt(agent.build_prompt(state), task_record=task)
+
+    assert "Prior work (last attempt):" not in text
+
+
+def test_retry_prompt_filters_last_rejection_reason_from_prior_work(workspace: Path) -> None:
+    task = create_task(workspace, title="t", goal="g")
+    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
+    state = make_state(task.id)
+    state.stage_retry["implementing"] = 1
+    state.last_report = LastReport(
+        files_changed=1,
+        changed_files=["litehive/lifecycle/prompt_serializer.py"],
+        test_results=[
+            "uv run pytest -q tests/lifecycle/test_prompt_serializer.py -> 8 passed",
+            "tests fail with ImportError",
+        ],
+    )
+    state.last_rejection_by_stage["implementing"] = LastRejection(
+        source="qa",
+        reason="tests fail with ImportError",
+        raised_at_phase="testing",
+    )
+
+    text = serialize_prompt(agent.build_prompt(state), task_record=task)
+
+    assert "Prior work (last attempt):" in text
+    assert "uv run pytest -q tests/lifecycle/test_prompt_serializer.py -> 8 passed" in text
+    assert "- Reason: tests fail with ImportError" in text
+    assert "- Test results: tests fail with ImportError" not in text
+
+
 def test_last_rejection_guidance_respects_repo_contract_and_opt_in_coverage(workspace: Path) -> None:
     task = create_task(workspace, title="t", goal="g")
     agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
diff --git a/tests/lifecycle/test_sqlite_adapters.py b/tests/lifecycle/test_sqlite_adapters.py
index 0ff0791d..8ad44812 100644
--- a/tests/lifecycle/test_sqlite_adapters.py
+++ b/tests/lifecycle/test_sqlite_adapters.py
@@ -99,7 +99,12 @@ def test_persistence_roundtrip_preserves_full_state(workspace: Path) -> None:
             head_sha="abc123",
             reason="checkpoint_created",
         ),
-        last_report=LastReport(files_changed=7, tests_added=3),
+        last_report=LastReport(
+            files_changed=7,
+            tests_added=3,
+            changed_files=["litehive/lifecycle/prompt_serializer.py", "tests/lifecycle/test_prompt_serializer.py"],
+            test_results=["uv run pytest -q tests/lifecycle/test_prompt_serializer.py -> 12 passed"],
+        ),
         last_rejection_by_stage={
             "implementing": LastRejection(
                 source="qa",
@@ -138,6 +143,13 @@ def test_persistence_roundtrip_preserves_full_state(workspace: Path) -> None:
     assert loaded.commit_result.reason == "checkpoint_created"
     assert loaded.last_report.files_changed == 7
     assert loaded.last_report.tests_added == 3
+    assert loaded.last_report.changed_files == [
+        "litehive/lifecycle/prompt_serializer.py",
+        "tests/lifecycle/test_prompt_serializer.py",
+    ]
+    assert loaded.last_report.test_results == [
+        "uv run pytest -q tests/lifecycle/test_prompt_serializer.py -> 12 passed"
+    ]
     assert loaded.last_rejection_by_stage["implementing"].source == "qa"
     assert loaded.last_rejection_by_stage["implementing"].reason == "tests fail"
     assert loaded.consecutive_same_hook_rejects == 2
```

```tool
output:

    assert "Last rejection" in text
    assert "- Source: qa" in text
    assert "- Raised at phase: testing" in text
    assert "tests fail with ImportError" in text


def test_retry_prompt_includes_prior_work_summary_from_last_report(workspace: Path) -> None:
    task = create_task(workspace, title="t", goal="g")
    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
    state = make_state(task.id)
    state.stage_retry["implementing"] = 1
    state.last_report = LastReport(
        files_changed=2,
        changed_files=[
            "litehive/lifecycle/prompt_serializer.py",
            "tests/lifecycle/test_prompt_serializer.py",
        ],
        test_results=[
            "uv run pytest -q tests/lifecycle/test_prompt_serializer.py -> 8 passed",
            "uv run ruff check --select E402,F401 litehive tests -> all checks passed",
        ],
    )

    text = serialize_prompt(agent.build_prompt(state), task_record=task)

    assert "Prior work (last attempt):" in text
    assert (
        "- Changed files: litehive/lifecycle/prompt_serializer.py, "
        "tests/lifecycle/test_prompt_serializer.py"
    ) in text
    assert (
        "- Test results: uv run pytest -q tests/lifecycle/test_prompt_serializer.py -> 8 passed; "
        "uv run ruff check --select E402,F401 litehive tests -> all checks passed"
    ) in text


def test_retry_prompt_omits_prior_work_when_last_report_has_no_retry_summary(workspace: Path) -> None:
    task = create_task(workspace, title="t", goal="g")
    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
    state = make_state(task.id)
    state.stage_retry["implementing"] = 1

    text = serialize_prompt(agent.build_prompt(state), task_record=task)

    assert "Prior work (last attempt):" not in text


def test_retry_prompt_filters_last_rejection_reason_from_prior_work(workspace: Path) -> None:
    task = create_task(workspace, title="t", goal="g")
    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
    state = make_state(task.id)
    state.stage_retry["implementing"] = 1
    state.last_report = LastReport(
        files_changed=1,
        changed_files=["litehive/lifecycle/prompt_serializer.py"],
        test_results=[
            "uv run pytest -q tests/lifecycle/test_prompt_serializer.py -> 8 passed",
            "tests fail with ImportError",
        ],
    )
    state.last_rejection_by_stage["implementing"] = LastRejection(
        source="qa",
        reason="tests fail with ImportError",
        raised_at_phase="testing",
    )

    text = serialize_prompt(agent.build_prompt(state), task_record=task)

    assert "Prior work (last attempt):" in text
    assert "uv run pytest -q tests/lifecycle/test_prompt_serializer.py -> 8 passed" in text
    assert "- Reason: tests fail with ImportError" in text
    assert "- Test results: tests fail with ImportError" not in text


def test_last_rejection_guidance_respects_repo_contract_and_opt_in_coverage(workspace: Path) -> None:
    task = create_task(workspace, title="t", goal="g")
    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
    state = make_state(task.id)
    state.last_rejection_by_stage["implementing"] = LastRejection(
        source="qa",
        reason="integration sweep failed",
        raised_at_phase="testing",
    )

    text = serialize_prompt(agent.build_prompt(state), task_record=task)

    assert "repo's documented verification contract" in text
    assert "opt-in or external coverage" in text
    assert "Each one is yours to fix" not in text
    assert "Don't declare the rejection stale, replayed, or pipeline-confused." not in text
    assert "Don't submit `blocked` to escape." not in text


def test_qa_prompt_includes_default_vs_opt_in_verification_guidance(workspace: Path) -> None:
    task = create_task(workspace, title="t", goal="g")
    agent = QAAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())

    text = serialize_prompt(agent.build_prompt(make_state(task.id, stage="testing")), task_record=task)

    assert "## Qa startup guidance" in text
    assert "repo's documented verification flow" in text
    assert "default deterministic test suite and targeted checks first" in text
    assert "opt-in, external-boundary, or authenticated integration coverage" in text


def test_build_prompt_ignores_corrupt_hook_config(workspace: Path) -> None:
    task = create_task(workspace, title="t", goal="g")
    config_path(workspace).write_text("[\n", encoding="utf-8")

    agent = SWEAgent(
```

```tool
output:
        return []
    normalized: list[str] = []
    seen: set[str] = set()
    for item in value:
        text = str(item).strip()
        if not text or text in seen:
            continue
        seen.add(text)
        normalized.append(text)
    return normalized


def _compact_list(items: list[str], *, limit: int, separator: str = ", ") -> str:
    if len(items) <= limit:
        return separator.join(items)
    shown = separator.join(items[:limit])
    return f"{shown}{separator}+{len(items) - limit} more"


def _pipeline_stage_key(name: str | None) -> str | None:
    if name in {"before_grooming", "grooming", "after_grooming"}:
        return "grooming"
    if name in {"before_implementing", "implementing", "after_implementing"}:
        return "implementing"
    if name in {"before_testing", "testing", "after_testing"}:
        return "testing"
    if name in {"before_accepting", "accepting", "after_accepting"}:
        return "accepting"
    if name in {"before_commit", "commit", "after_commit", "merge_resolving"}:
        return "commit_to_git"
    return name


def _entry_sources(entry: dict[str, Any]) -> set[str]:
    sources: set[str] = set()
    explicit_source = str(entry.get("source") or "").strip()
    if explicit_source:
        sources.add(explicit_source)

    role = str(entry.get("role") or "").strip()
    if role:
        sources.add(role)
        if role == "hook":
            sources.add("hook")
        elif role != "recovery":
            sources.add("agent")
    return sources


def _matches_last_rejection(entry: dict[str, Any], last_rejection: dict[str, Any]) -> bool:
    if entry.get("verdict") != "reject":
        return False

    rejection_source = str(last_rejection.get("source") or "").strip()
    if rejection_source and rejection_source not in _entry_sources(entry):
        return False

    rejection_stage = _pipeline_stage_key(str(last_rejection.get("raised_at_phase") or "").strip() or None)
    entry_stage = _pipeline_stage_key(str(entry.get("stage") or "").strip() or None)
    if rejection_stage and entry_stage and rejection_stage != entry_stage:
        return False

    rejection_reason = str(last_rejection.get("reason") or "")
    message = str(entry.get("message") or "")
    if not rejection_reason:
        return False
    return message == rejection_reason or rejection_reason in message


def _trim_thread_for_prompt(
    thread: list[dict[str, Any]],
    current_stage: str | None,
    last_rejection: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Keep only the thread entries the current stage actually needs.

    Rules:
    - Never include recovery entries with verdict=comment (bookkeeping noise).
    - Never duplicate an entry whose content matches last_rejection (already
      rendered in its own section).
    - Per-stage relevance:
        grooming:     nothing (first stage, no prior context needed)
        implementing: grooming pass (scope) + last reject that sent us back
        testing:      last implementing pass (what SWE claims it did)
        accepting:    last implementing pass + last testing pass
        recovering:   last crash/rejection + last implementing pass
        fallback:     grooming pass + last entry per (stage, verdict)
    - Cap each individual message to 500 chars.
    """
    # Filter out recovery bookkeeping comments
    thread = [e for e in thread if not (e.get("role") == "recovery" and e.get("verdict") == "comment")]

    if not thread:
        return []

    # Skip entries that duplicate last_rejection
    if last_rejection:
        thread = [entry for entry in thread if not _matches_last_rejection(entry, last_rejection)]

    def _last_where(**match: str) -> dict[str, Any] | None:
        for e in reversed(thread):
            if all(e.get(k) == v for k, v in match.items()):
                return e
        return None

    kept: list[dict[str, Any]] = []

    if current_stage == "grooming":
        pass  # no thread context needed

    elif current_stage == "implementing":
        g = _last_where(stage="grooming", verdict="pass")
        if g:
            kept.append(g)
        # On retry, the rejection is rendered in the dedicated last_rejection
        # section; do not repeat older reject entries in the thread.
        if not last_rejection:
            for e in reversed(thread):
                if e.get("verdict") == "reject" and e.get("stage") in (
                    "testing",
                    "accepting",
                    "implementing",
                ):
                    kept.append(e)
                    break

    elif current_stage == "testing":
        p = _last_where(stage="implementing", verdict="pass")
        if p:
            kept.append(p)

    elif current_stage == "accepting":
        p = _last_where(stage="implementing", verdict="pass")
        if p:
            kept.append(p)
        t = _last_where(stage="testing", verdict="pass")
        if t:
            kept.append(t)

    elif current_stage == "recovering":
        p = _last_where(stage="implementing", verdict="pass")
        if p:
            kept.append(p)
        # The crash or rejection that triggered recovery
        for e in reversed(thread):
            if e.get("verdict") in ("reject", "blocked"):
                kept.append(e)
                break

    else:
        # Fallback: grooming pass + last per (stage, verdict)
        g = _last_where(stage="grooming", verdict="pass")
        if g:
            kept.append(g)
        seen: set[tuple[str, str]] = set()
        for e in reversed(thread):
            key = (e.get("stage", "?"), e.get("verdict", "?"))
            if key not in seen:
                seen.add(key)
                kept.append(e)
```

```tool
output:
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol

from litehive.db.schema import connect_workspace_db
from litehive.domain.common import utcnow
from litehive.domain.recovery import RecoveryOutcome, RecoveryTrigger

from .types import FailedReason, NodeName, PipelineMode


@dataclass(frozen=True)
class Limits:
    stage_retry_limit: int = 3
    same_hook_reject_limit: int = 3
    same_engine_retry_limit: int = 3
    overall_retry_limit: int = 30
    grace_period_seconds: int = 120


@dataclass
class LastReport:
    files_changed: int = 0
    tests_added: int = 0
    changed_files: list[str] = field(default_factory=list)
    test_results: list[str] = field(default_factory=list)

    def to_payload(self) -> dict[str, int | list[str]]:
        return {
            "files_changed": self.files_changed,
            "tests_added": self.tests_added,
            "changed_files": list(self.changed_files),
            "test_results": list(self.test_results),
        }

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "LastReport":
        files_changed = payload.get("files_changed", 0)
        return cls(
            files_changed=len(files_changed) if isinstance(files_changed, list) else int(files_changed),
            tests_added=int(payload.get("tests_added", 0)),
            changed_files=_string_list(payload.get("changed_files")),
            test_results=_string_list(payload.get("test_results")),
        )


@dataclass
class HookRejectFingerprint:
    point: NodeName
    command: str
    description: str = ""
    fingerprint: str = ""

    def to_payload(self) -> dict[str, str]:
        return {
            "point": self.point,
            "command": self.command,
            "description": self.description,
            "fingerprint": self.fingerprint,
        }

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "HookRejectFingerprint":
        return cls(
            point=payload["point"],
            command=payload["command"],
            description=payload.get("description", ""),
            fingerprint=payload["fingerprint"],
        )


@dataclass
class LastRejection:
    """Most recent reject against a retry-eligible stage.

    Populated by the ``inc_stage_retry`` effect whenever a Reject event is
    being routed back into a retry. Read by ``RoleAgent.build_prompt`` so the
    next agent visit can see exactly what the previous attempt (or hook) was
    unhappy about.
    """

    source: str  # "agent" | "hook" | "guard" | "system"
    reason: str
    raised_at_phase: NodeName  # the phase that emitted the reject

    def to_payload(self) -> dict[str, str]:
        return {
            "source": self.source,
            "reason": self.reason,
            "raised_at_phase": self.raised_at_phase,
        }

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "LastRejection":
        return cls(
            source=payload["source"],
            reason=payload["reason"],
            raised_at_phase=payload["raised_at_phase"],
        )


@dataclass
class MergeContext:
    conflict_files: tuple[str, ...] = ()
    merge_attempt: int = 1

    def to_payload(self) -> dict[str, Any]:
        return {
            "conflict_files": list(self.conflict_files),
            "merge_attempt": self.merge_attempt,
        }

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "MergeContext":
        files = payload.get("conflict_files") or []
        return cls(
            conflict_files=tuple(str(path) for path in files),
            merge_attempt=int(payload.get("merge_attempt") or 1),
        )


@dataclass
class CommitResult:
    head_sha: str
    reason: str | None = None

    def to_payload(self) -> dict[str, Any]:
        return {
            "head_sha": self.head_sha,
            "reason": self.reason,
        }

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "CommitResult":
        return cls(
            head_sha=str(payload["head_sha"]),
            reason=payload.get("reason"),
        )


@dataclass
class TaskState:
    """Single source of truth for task state the machine reads and writes.

    Guards, rule targets, and effect factories all receive a ``TaskState`` by
    convention read-only. The Runner is the only place that mutates it, via
    ``StateDelta`` patches.

    ``limits`` is runtime config (not persisted) — real persistence adapters
    should omit it on save and re-inject it on load.
    """

    task_id: str
    stage: NodeName
    pipeline_mode: PipelineMode
    entry_stage: NodeName | None = None
    stage_retry: dict[NodeName, int] = field(default_factory=dict)
    active_recovery_trigger: RecoveryTrigger | None = None
    recovery_history: list[RecoveryOutcome] = field(default_factory=list)
    pre_exec_recovery_attempt: int = 0
    merge_context: MergeContext | None = None
    commit_result: CommitResult | None = None
    last_report: LastReport = field(default_factory=LastReport)
    last_rejection_by_stage: dict[NodeName, LastRejection] = field(default_factory=dict)
    consecutive_same_hook_rejects: int = 0
    last_hook_reject_fingerprint: HookRejectFingerprint | None = None
    hook_reject_recovery_invoked: bool = False
    failed_reason: FailedReason | None = None
    failed_message: str | None = None
    recovery_failure_explanation: str | None = None
    limits: Limits = field(default_factory=Limits)

    def recovery_attempts_for_origin(self, origin_stage: NodeName) -> int:
        count = sum(1 for outcome in self.recovery_history if outcome.trigger.origin_stage == origin_stage)
        if self.active_recovery_trigger is not None and self.active_recovery_trigger.origin_stage == origin_stage:
            count += 1
        return count

    def recovery_budget_available(self, trigger: RecoveryTrigger) -> bool:
        if trigger.reason_code == "hook_reject_loop":
            return not self.hook_reject_recovery_invoked
        return all(outcome.trigger.budget_key() != trigger.budget_key() for outcome in self.recovery_history)


class Persistence(Protocol):
    def save(self, state: TaskState) -> None: ...
    def load(self, task_id: str) -> TaskState: ...


class InMemoryPersistence:
    def __init__(self) -> None:
        self._states: dict[str, TaskState] = {}

    def save(self, state: TaskState) -> None:
        self._states[state.task_id] = state

    def load(self, task_id: str) -> TaskState:
        return self._states[task_id]


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    normalized: list[str] = []
    seen: set[str] = set()
    for item in value:
        text = str(item).strip()
        if not text or text in seen:
            continue
        seen.add(text)
        normalized.append(text)
    return normalized


# ── sqlite-backed persistence ────────────────────────────────────────────


def _state_payload(state: TaskState) -> dict[str, Any]:
    return {
        "entry_stage": state.entry_stage,
        "stage_retry": dict(state.stage_retry),
        "active_recovery_trigger": (
            state.active_recovery_trigger.to_payload() if state.active_recovery_trigger is not None else None
        ),
        "recovery_history": [outcome.to_payload() for outcome in state.recovery_history],
        "pre_exec_recovery_attempt": state.pre_exec_recovery_attempt,
        "merge_context": (state.merge_context.to_payload() if state.merge_context is not None else None),
        "commit_result": (state.commit_result.to_payload() if state.commit_result is not None else None),
        "last_report": state.last_report.to_payload(),
        "last_rejection_by_stage": {stage: rej.to_payload() for stage, rej in state.last_rejection_by_stage.items()},
        "consecutive_same_hook_rejects": state.consecutive_same_hook_rejects,
        "last_hook_reject_fingerprint": (
            state.last_hook_reject_fingerprint.to_payload() if state.last_hook_reject_fingerprint is not None else None
        ),
        "hook_reject_recovery_invoked": state.hook_reject_recovery_invoked,
        "failed_reason": state.failed_reason,
        "failed_message": state.failed_message,
        "recovery_failure_explanation": state.recovery_failure_explanation,
    }
```

```tool
output:
        verdicts=_allowed_verdicts_for_stage(stage),
        after=after_ts,
    )
    if latest is None:
        return None
    if (
        stage == "implementing"
        and latest.verdict == "pass"
        and not _execution_checkout_has_changes(workspace_root, task_id)
    ):
        return AgentVerdict(
            outcome="reject",
            reason=(
                "implementing pass rejected: execution checkout is clean and HEAD matches the "
                "workspace base, so no work landed"
            ),
        )
    changed_files = normalized_files_changed(latest.files_changed)
    return AgentVerdict(
        outcome=latest.verdict,
        reason=latest.message or "",
        metadata={
            "files_changed": changed_files,
            "target_stage": latest.target_stage,
            "last_report": {
                "changed_files": changed_files,
                "test_results": _extract_test_results(latest.message or ""),
            },
        },
    )


class HeruEngineAdapter:
    """``Engine`` that delegates to ``SubagentManager`` for one turn."""

    _CRASH_RESUME_PROMPT_PREFIX = "Please continue where you left off. Complete the task.\n\n"

    def __init__(
        self,
        engine_name: str,
        workspace_root: Path,
        *,
        model_name: str | None = None,
    ) -> None:
        self.name = engine_name
        self.workspace_root = Path(workspace_root)
        self.model_name = model_name

    def with_model(self, model_name: str | None) -> "HeruEngineAdapter":
        return HeruEngineAdapter(
            self.name,
            self.workspace_root,
            model_name=model_name,
        )

    def run_turn(self, session: Session, prompt: Any, state: TaskState) -> AgentVerdict:
        if not isinstance(prompt, dict):
            raise UnrecoverableError(
                f"HeruEngineAdapter expects a prompt dict from RoleAgent.build_prompt, got {type(prompt).__name__}"
            )

        task = get_task(self.workspace_root, state.task_id)
        if task is None:
            raise UnrecoverableError(f"task {state.task_id} not found in workspace")

        stage = prompt["stage"]
        role = prompt["role"]
        prompt_text = serialize_prompt(prompt, task_record=task, workspace_root=self.workspace_root)
        execution_root = (
            resolve_recorded_worktree_path(self.workspace_root, task.runtime.git.worktree_path) or self.workspace_root
        )

        before_turn = datetime.now(UTC)
        manager = SubagentManager(self.workspace_root, execution_root=execution_root)
        result = self._run_with_crash_resume(
            manager,
            task,
            role=role,
            prompt_text=prompt_text,
            session=session,
        )
```

```tool
output:

    def __init__(
        self,
        selector: EngineSelector,
        session_provider: SessionProvider,
        *,
        prompt_context: PromptContext | None = None,
        retry_budget: int = 3,
        retry_on: tuple[str, ...] = ("execution_limit", "timeout"),
        retry_backoff_seconds: float = 0.0,
        retry_backoff_multiplier: float = 2.0,
        grace_period_seconds: int | None = None,
    ) -> None:
        if not self.NODE_NAME or not self.ROLE:
            raise TypeError(f"{type(self).__name__} must set NODE_NAME and ROLE class attributes")
        super().__init__(
            name=self.NODE_NAME,
            selector=selector,
            session_provider=session_provider,
            retry_budget=retry_budget,
            retry_on=retry_on,
            retry_backoff_seconds=retry_backoff_seconds,
            retry_backoff_multiplier=retry_backoff_multiplier,
            grace_period_seconds=grace_period_seconds,
        )
        self.prompt_context = prompt_context or PromptContext()

    def build_prompt(self, state: TaskState) -> dict[str, Any]:
        last_rejection = self._last_rejection_for_prompt(state)
        runner_hooks = self._runner_hooks_for_stage()
        return {
            "role": self.ROLE,
            "stage": self.NODE_NAME,
            "task_id": state.task_id,
            "pipeline_mode": state.pipeline_mode.value,
            "stage_retry": state.stage_retry.get(self.NODE_NAME, 0),
            "instruction_layers": self._assemble_instruction_layers(),
            "last_report": state.last_report.to_payload(),
            "last_rejection": (
                {
                    "source": last_rejection.source,
                    "reason": last_rejection.reason,
                    "raised_at_phase": last_rejection.raised_at_phase,
                }
                if last_rejection is not None
                else None
            ),
            "runner_hooks": runner_hooks,
            "rejecting_hooks": runner_hooks,
        }

    def _last_rejection_for_prompt(self, state: TaskState) -> LastRejection | None:
        """Return the rejection context the next agent turn should actually see.

        Implementing retries are special: work can be routed back there by
        rejects from implementing itself, testing, or accepting. The next SWE
        prompt should reflect the freshest reject that actually sent the task
        back to implementing, not whichever rejection was last stored under the
        implementing key.
        """
        fallback = state.last_rejection_by_stage.get(self.NODE_NAME)
        if self.NODE_NAME != "implementing":
            return fallback
        root = self.prompt_context.workspace_root
        if root is None:
            return fallback
```

```tool
output:
"""Pass.metadata → state.last_report wiring tests.

Agent verdicts carry ``files_changed`` / ``tests_added`` in their
metadata. The Runner copies that into ``state.last_report`` after each
transition so guards like ``zero_change_shortcut`` see real numbers.
"""

from typing import Any

from litehive.lifecycle.events import Pass
from litehive.lifecycle.nodes.agent import AgentNode, AgentVerdict
from litehive.lifecycle.persistence import TaskState
from litehive.lifecycle.runner import StateMachineRunner
from litehive.lifecycle.sessions import InMemorySessionStore
from litehive.lifecycle.types import PipelineMode


class _FixedSelector:
    def __init__(self, engine):
        self.engine = engine

    def select(self, state, node_name, excluded):
        return None if self.engine.name in excluded else self.engine


class _ReportingEngine:
    name = "stub"

    def run_turn(self, session: Any, prompt: Any, state: Any) -> AgentVerdict:
        return AgentVerdict(
            outcome="pass",
            reason="ok",
            metadata={"files_changed": ["a.py", "b.py", "c.py"], "tests_added": 2},
        )


class _TrivialAgent(AgentNode):
    def build_prompt(self, state: TaskState) -> dict:
        return {"stage": self.name}


def test_agent_verdict_metadata_flows_into_pass_event() -> None:
    """Verify AgentNode._verdict_to_event copies metadata onto Pass."""
    agent = _TrivialAgent(
        "implementing",
        _FixedSelector(_ReportingEngine()),
        InMemorySessionStore(),
    )
    event = agent.run(TaskState(task_id="T-0001", stage="implementing", pipeline_mode=PipelineMode.FULL))
    assert isinstance(event, Pass)
    assert event.metadata["files_changed"] == ["a.py", "b.py", "c.py"]
    assert event.metadata["tests_added"] == 2


def test_runner_updates_state_last_report_from_pass_metadata() -> None:
    """Runner._apply_event_side_effects copies Pass.metadata into state.last_report."""
    state = TaskState(task_id="T-0001", stage="implementing", pipeline_mode=PipelineMode.FULL)
    event = Pass(
        metadata={
            "files_changed": ["x.py", "y.py"],
            "tests_added": 3,
            "last_report": {
                "changed_files": ["x.py", "y.py"],
                "test_results": [
                    "uv run pytest -q tests/lifecycle/test_prompt_serializer.py -> 3 passed",
                ],
            },
        }
    )

    StateMachineRunner._apply_event_side_effects(state, event)

    assert state.last_report.files_changed == 2
    assert state.last_report.tests_added == 3
    assert state.last_report.changed_files == ["x.py", "y.py"]
    assert state.last_report.test_results == [
        "uv run pytest -q tests/lifecycle/test_prompt_serializer.py -> 3 passed",
    ]
```

```tool
output:
"""Round-trip tests for v2 pipeline sqlite adapters.

Covers ``SqlitePersistence`` (TaskState round-trip) and ``SqliteSessionStore``
(Session round-trip keyed by task/node/engine), plus isolation invariants —
different tasks and different engines must not see each other's rows.
"""

from pathlib import Path

import pytest

from litehive.config.workspace import ensure_workspace
from litehive.domain.recovery import (
    FailureFingerprint,
    RecoveryDisposition,
    RecoveryOutcome,
    RecoveryTrigger,
    TriggerEventKind,
)
from litehive.lifecycle.persistence import (
    HookRejectFingerprint,
    LastRejection,
    LastReport,
    MergeContext,
    CommitResult,
    Limits,
    SqlitePersistence,
    TaskNotFound,
    TaskState,
)
from litehive.lifecycle.sessions import Session, SqliteSessionStore
from litehive.lifecycle.types import PipelineMode


@pytest.fixture
def workspace(tmp_path: Path) -> Path:
    ensure_workspace(tmp_path)
    return tmp_path


# ── SqlitePersistence ─────────────────────────────────────────────────────


def test_persistence_load_missing_raises_task_not_found(workspace: Path) -> None:
    store = SqlitePersistence(workspace)
    with pytest.raises(TaskNotFound):
        store.load("T-9999")


def test_persistence_initialize_is_idempotent(workspace: Path) -> None:
    store = SqlitePersistence(workspace)
    first = store.initialize("T-0001", pipeline_mode=PipelineMode.SINGLE)
    second = store.initialize("T-0001", pipeline_mode=PipelineMode.FULL)
    assert first.task_id == second.task_id == "T-0001"
    # Second call is a no-op: must not overwrite the existing row
    assert second.pipeline_mode == PipelineMode.SINGLE
    assert second.stage == "ready"


def test_persistence_roundtrip_preserves_full_state(workspace: Path) -> None:
    store = SqlitePersistence(workspace, limits=Limits(stage_retry_limit=5))

    original = TaskState(
        task_id="T-0042",
        stage="implementing",
        pipeline_mode=PipelineMode.FULL,
        stage_retry={"implementing": 2, "testing": 1},
        active_recovery_trigger=RecoveryTrigger(
            origin_stage="implementing",
            trigger_event_kind=TriggerEventKind.CRASH,
            failure_fingerprint=FailureFingerprint(
                fingerprint="RuntimeError:boom",
                classification="RuntimeError",
            ),
            message="boom",
        ),
        recovery_history=[
            RecoveryOutcome(
                trigger=RecoveryTrigger(
                    origin_stage="grooming",
                    trigger_event_kind=TriggerEventKind.REJECT,
                    failure_fingerprint=FailureFingerprint(
                        fingerprint="agent:blank task",
                        classification="agent_reject",
                    ),
                    source="agent",
                    message="blank task",
                ),
                recovery_verdict="resume",
                disposition=RecoveryDisposition.RESUMED,
            )
        ],
        pre_exec_recovery_attempt=1,
        merge_context=MergeContext(
            conflict_files=["conflicted.py"],
            merge_attempt=2,
        ),
        commit_result=CommitResult(
            head_sha="abc123",
            reason="checkpoint_created",
        ),
        last_report=LastReport(
            files_changed=7,
            tests_added=3,
            changed_files=["litehive/lifecycle/prompt_serializer.py", "tests/lifecycle/test_prompt_serializer.py"],
            test_results=["uv run pytest -q tests/lifecycle/test_prompt_serializer.py -> 12 passed"],
        ),
        last_rejection_by_stage={
            "implementing": LastRejection(
                source="qa",
                reason="tests fail",
                raised_at_phase="testing",
            ),
        },
        consecutive_same_hook_rejects=2,
        last_hook_reject_fingerprint=HookRejectFingerprint(
            point="after_implementing",
            command="pytest -q",
            description="timeout watchdog",
            fingerprint="after_implementing|pytest -q|timeout watchdog",
        ),
        hook_reject_recovery_invoked=True,
        failed_reason=None,
        failed_message=None,
        recovery_failure_explanation=None,
    )
    store.save(original)

    loaded = store.load("T-0042")
    assert loaded.task_id == original.task_id
    assert loaded.stage == "implementing"
    assert loaded.pipeline_mode == PipelineMode.FULL
    assert loaded.stage_retry == {"implementing": 2, "testing": 1}
    assert loaded.active_recovery_trigger is not None
    assert loaded.active_recovery_trigger.trigger_event_kind == TriggerEventKind.CRASH
    assert loaded.recovery_history[0].disposition == RecoveryDisposition.RESUMED
    assert loaded.pre_exec_recovery_attempt == 1
    assert loaded.merge_context is not None
    assert loaded.merge_context.conflict_files == ("conflicted.py",)
    assert loaded.merge_context.merge_attempt == 2
    assert loaded.commit_result is not None
    assert loaded.commit_result.head_sha == "abc123"
    assert loaded.commit_result.reason == "checkpoint_created"
    assert loaded.last_report.files_changed == 7
    assert loaded.last_report.tests_added == 3
    assert loaded.last_report.changed_files == [
        "litehive/lifecycle/prompt_serializer.py",
        "tests/lifecycle/test_prompt_serializer.py",
    ]
    assert loaded.last_report.test_results == [
        "uv run pytest -q tests/lifecycle/test_prompt_serializer.py -> 12 passed"
    ]
    assert loaded.last_rejection_by_stage["implementing"].source == "qa"
    assert loaded.last_rejection_by_stage["implementing"].reason == "tests fail"
    assert loaded.consecutive_same_hook_rejects == 2
    assert loaded.last_hook_reject_fingerprint is not None
    assert loaded.last_hook_reject_fingerprint.command == "pytest -q"
    assert loaded.hook_reject_recovery_invoked is True
    # limits is runtime config, re-injected on load
    assert loaded.limits.stage_retry_limit == 5


def test_persistence_upsert_overwrites_on_second_save(workspace: Path) -> None:
    store = SqlitePersistence(workspace)
    state = TaskState(task_id="T-0100", stage="grooming", pipeline_mode=PipelineMode.FULL)
    store.save(state)

    state.stage = "implementing"
    state.stage_retry["implementing"] = 1
    store.save(state)

    loaded = store.load("T-0100")
    assert loaded.stage == "implementing"
    assert loaded.stage_retry == {"implementing": 1}


def test_persistence_failed_reason_and_message_roundtrip(workspace: Path) -> None:
    store = SqlitePersistence(workspace)
    state = TaskState(
        task_id="T-0200",
        stage="failed",
        pipeline_mode=PipelineMode.FULL,
        failed_reason="recovery_exhausted",
        failed_message="recovery agent gave up after one attempt",
    )
    store.save(state)

    loaded = store.load("T-0200")
    assert loaded.failed_reason == "recovery_exhausted"
    assert loaded.failed_message == "recovery agent gave up after one attempt"


# ── SqliteSessionStore ────────────────────────────────────────────────────


def test_sessions_empty_get_or_create_returns_fresh(workspace: Path) -> None:
    sessions = SqliteSessionStore(workspace)
    session = sessions.get_or_create("T-0001", "implementing", "codex")
    assert session.engine_session_id is None
    assert session.conversation_id is None
    assert session.turn_count == 0


def test_sessions_persist_roundtrip(workspace: Path) -> None:
    sessions = SqliteSessionStore(workspace)
    session = Session(
        engine_session_id="cdx-abc-123",
        conversation_id="conv-xyz",
        turn_count=4,
        metadata={"last_prompt_sha": "deadbeef"},
    )
    sessions.persist("T-0001", "implementing", "codex", session)

    loaded = sessions.get_or_create("T-0001", "implementing", "codex")
    assert loaded.engine_session_id == "cdx-abc-123"
    assert loaded.conversation_id == "conv-xyz"
    assert loaded.turn_count == 4
    assert loaded.metadata == {"last_prompt_sha": "deadbeef"}
    assert loaded.resumable() is True
```

The implementation looks aligned on paper. I’m switching to evidence now: a direct serializer proof for `stage_retry > 0`, then the targeted lifecycle suite and lint on the touched modules.

```tool
output:
All checks passed!
```

```tool
output:
Traceback (most recent call last):
  File "<stdin>", line 2, in <module>
ImportError: cannot import name 'PromptContext' from 'litehive.agents' (/home/alexey/.local/share/litehive/c16deb0d1ee209d7/worktrees/T-0355-add-prior-work-retry-summary-to-prompts-from/litehive/agents/__init__.py)
```

```tool
output:
.....................................................                    [100%]
53 passed in 0.82s
```

The targeted lifecycle suite is clean: `53 passed`, and `ruff` is clean on the touched files. I hit a bad import path in my first manual proof snippet, so I’m correcting that to inspect the exact rendered prompt lines.

```tool
output:
tests/lifecycle/test_prompt_serializer.py:83:    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
tests/lifecycle/test_prompt_serializer.py:100:    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
tests/lifecycle/test_prompt_serializer.py:113:    agent = RecoveryAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
tests/lifecycle/test_prompt_serializer.py:168:    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
tests/lifecycle/test_prompt_serializer.py:181:    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
tests/lifecycle/test_prompt_serializer.py:212:    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
tests/lifecycle/test_prompt_serializer.py:229:    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
tests/lifecycle/test_prompt_serializer.py:259:    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
tests/lifecycle/test_prompt_serializer.py:270:    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
tests/lifecycle/test_prompt_serializer.py:297:    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
tests/lifecycle/test_prompt_serializer.py:316:    agent = QAAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
tests/lifecycle/test_prompt_serializer.py:333:        prompt_context=PromptContext(workspace_root=workspace),
tests/lifecycle/test_prompt_serializer.py:367:        prompt_context=PromptContext(workspace_root=workspace),
tests/lifecycle/test_prompt_serializer.py:381:    agent = PlannerAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
tests/lifecycle/test_prompt_serializer.py:394:    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
tests/lifecycle/test_prompt_serializer.py:402:    agent = RecoveryAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
tests/lifecycle/test_prompt_serializer.py:425:    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
tests/lifecycle/test_prompt_serializer.py:440:    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
tests/lifecycle/test_prompt_serializer.py:493:    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext(workspace_root=workspace))
tests/lifecycle/test_prompt_serializer.py:537:    agent = SWEAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext(workspace_root=workspace))
litehive/lifecycle/orchestration.py:551:        prompt_context = PromptContext(workspace_root=root)
litehive/roles/base.py:15:class PromptContext:
litehive/roles/base.py:85:        self.prompt_context = prompt_context or PromptContext()
```

```tool
output:
Stage retry attempt: 1
- Reason: tests fail with ImportError
Prior work (last attempt):
- Changed files: litehive/lifecycle/prompt_serializer.py, tests/lifecycle/test_prompt_serializer.py
- Test results: uv run pytest -q tests/lifecycle/test_prompt_serializer.py -> 8 passed
```

The direct prompt proof is good: retry prompts show the new `Prior work (last attempt)` block, and the rejection reason stays only in the dedicated rejection section. I’m doing one wider `tests/lifecycle` sweep now to reduce regression risk beyond the four targeted files.

The broader lifecycle sweep is still running. I’m waiting on that before I make the final pass/reject call.

```tool
output:
........................................................................ [ 39%]
........................................................................ [ 79%]
.....................................                                    [100%]
=============================== warnings summary ===============================
tests/lifecycle/test_hook_reject_circuit_breaker.py: 8 warnings
tests/lifecycle/test_hooks_and_commit.py: 12 warnings
  /home/alexey/.local/share/litehive/c16deb0d1ee209d7/worktrees/T-0355-add-prior-work-retry-summary-to-prompts-from/.venv/lib/python3.14/site-packages/pydantic/main.py:464: UserWarning: Pydantic serializer warnings:
    PydanticSerializationUnexpectedValue(Expected `enum` - serialized value may not be as expected [field_name='status', input_value='running', input_type=str])
    return self.__pydantic_serializer__.to_python(

tests/lifecycle/test_journal_cli.py::test_pipeline_journal_prints_state_and_transitions
tests/lifecycle/test_journal_cli.py::test_pipeline_journal_prints_state_and_transitions
  /home/alexey/.local/share/litehive/c16deb0d1ee209d7/worktrees/T-0355-add-prior-work-retry-summary-to-prompts-from/.venv/lib/python3.14/site-packages/typer/params.py:946: DeprecationWarning: The 'is_flag' and 'flag_value' parameters are not supported by Typer and will be removed entirely in a future release.
    return OptionInfo(

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
181 passed, 22 warnings in 12.11s
```

The wider regression sweep is clean: `tests/lifecycle` passed in full. I have enough evidence to accept unless the `litehive report` command itself fails.

```tool
output:
task: T-0355
stage: accepting
verdict: pass
role: reviewer
```

Accepted and submitted `pass` for `T-0355`.

I verified the end-user outcome directly: on `stage_retry > 0`, the prompt now includes `Prior work (last attempt)` from `state.last_report`, shows changed files and test results, and does not repeat the last rejection reason inside that prior-work section. Verification was clean with `53` targeted tests passing, the full `tests/lifecycle` sweep passing (`181 passed`), and `ruff` passing on the touched files.

[stderr]
Reading additional input from stdin...
