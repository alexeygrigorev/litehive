I’m shaping the task record for grooming, not implementing. First I’m pulling the current task context from the workspace and Litehive so I can rewrite goal, acceptance criteria, and plan into something executable for the next agent.

```tool
output:
/home/alexey/.local/share/litehive/c16deb0d1ee209d7/worktrees/T-0370-wire-codex-mount-codex-home-into-the-sandbox-so
./PLAN.md:55:- `copilot`
./README.md:56:- copilot - GitHub Copilot CLI
./README.md:305:- copilot - GitHub Copilot CLI
./tests/test_continuation_delegation.py:53:    for engine_name in ("codex", "claude", "copilot", "gemini", "goz", "opencode"):
./tests/test_continuation_delegation.py:58:    assert captured == ["codex", "claude", "copilot", "gemini", "goz", "opencode"]
./litehive/config/normalization.py:152:def _normalize_external_engine_sandbox_policy(
./litehive/config/normalization.py:180:            extra_ro_binds=[str(item).strip() for item in raw_policy.get("extra_ro_binds", [])],
./litehive/config/normalization.py:197:    for index, raw_path in enumerate(policy.extra_ro_binds):
./litehive/config/normalization.py:202:            raise ValueError(f"{field_name}.extra_ro_binds[{index}] must be an absolute host path")
./litehive/config/normalization.py:204:    policy.extra_ro_binds = normalized_binds
./litehive/config/normalization.py:208:def normalize_external_engine_sandbox_config(
./litehive/config/normalization.py:234:                engine_name: _normalize_external_engine_sandbox_policy(
./litehive/config/normalization.py:236:                    field_name=f"external_engine_sandbox.engine_policies[{engine_name}]",
./litehive/config/normalization.py:243:        raise ValueError(f"external_engine_sandbox.backend must be one of: {allowed}")
./litehive/config/normalization.py:246:        raise ValueError(f"external_engine_sandbox.default_network_mode must be one of: {allowed}")
./litehive/config/normalization.py:250:            f"external_engine_sandbox.default_workspace_mode must be one of: {allowed}"
./litehive/config/normalization.py:253:        raise ValueError("external_engine_sandbox.workspace_mount_path must be an absolute path")
./litehive/config/normalization.py:255:        raise ValueError("external_engine_sandbox.binary_mount_root must be an absolute path")
./litehive/config/normalization.py:258:            raise ValueError(f"external_engine_sandbox.tmpfs[{index}] must be an absolute path")
./litehive/config/normalization.py:264:                f"external_engine_sandbox.engine_policies engine must be one of: {allowed}"
./litehive/config/normalization.py:266:        normalized_policies[engine_name] = _normalize_external_engine_sandbox_policy(
./litehive/config/normalization.py:268:            field_name=f"external_engine_sandbox.engine_policies[{engine_name}]",
./litehive/config/constants.py:4:VALID_ENGINE_NAMES = frozenset({"codex", "opencode", "gemini", "copilot", "claude", "goz"})
./experiments/sandbox-breakout/driver.py:43:        external_engine_sandbox=ExternalEngineSandboxConfig(
./tests/test_engine_freeze.py:220:        engine_preference=["codex", "opencode", "gemini", "copilot"],
./tests/test_config.py:302:def test_configure_persists_copilot_model(tmp_path: Path) -> None:
./tests/test_config.py:305:    raw_config["default_engine"] = "copilot"
./tests/test_config.py:306:    raw_config["copilot_model"] = "gpt-5"
./tests/test_config.py:312:    assert config.default_engine == "copilot"
./tests/test_config.py:313:    assert config.copilot_model == "gpt-5"
./litehive/agents/sandbox.py:105:    extra_ro_binds: tuple[tuple[str, str], ...] = ()
./litehive/agents/sandbox.py:116:        sandbox_enabled = self.config.external_engine_sandbox.enabled and policy is not None and policy.enabled
./litehive/agents/sandbox.py:122:            backend=self.config.external_engine_sandbox.backend,
./litehive/agents/sandbox.py:123:            runtime=self.config.external_engine_sandbox.runtime_binary,
./litehive/agents/sandbox.py:124:            image=self.config.external_engine_sandbox.image,
./litehive/agents/sandbox.py:126:                self.config.external_engine_sandbox.default_network_mode
./litehive/agents/sandbox.py:131:                self.config.external_engine_sandbox.default_workspace_mode
./litehive/agents/sandbox.py:141:                if self.config.external_engine_sandbox.backend == "bubblewrap"
./litehive/agents/sandbox.py:157:        runtime_config = self.config.external_engine_sandbox
./litehive/agents/sandbox.py:196:        runtime_config = self.config.external_engine_sandbox
./litehive/agents/sandbox.py:251:        extra_ro_binds = self._resolved_extra_ro_binds(engine_name, policy)
./litehive/agents/sandbox.py:258:        for source, target in git_plan.extra_ro_binds:
./litehive/agents/sandbox.py:260:        for host_path in extra_ro_binds:
./litehive/agents/sandbox.py:312:        runtime_config = self.config.external_engine_sandbox
./litehive/agents/sandbox.py:337:        extra_ro_binds = self._resolved_extra_ro_binds(engine_name, policy)
./litehive/agents/sandbox.py:344:        for source, target in git_plan.extra_ro_binds:
./litehive/agents/sandbox.py:346:        for host_path in extra_ro_binds:
./litehive/agents/sandbox.py:406:        return self.config.external_engine_sandbox.engine_policies.get(engine_name)
./litehive/agents/sandbox.py:409:    def _resolved_extra_ro_binds(
./litehive/agents/sandbox.py:414:        for raw_path in () if policy is None else policy.extra_ro_binds:
./litehive/agents/sandbox.py:524:            extra_ro_binds=tuple(binds),
./tests/test_tasks_and_subagents.py:996:def _subagent_manager_records_copilot_quota_monitoring_during_live_updates(
./tests/test_tasks_and_subagents.py:1002:    adapter = get_engine("copilot")
./tests/test_tasks_and_subagents.py:1019:            adapter="copilot",
./tests/test_tasks_and_subagents.py:1020:            argv=("copilot", "-p"),
./tests/test_tasks_and_subagents.py:1040:        record = monitoring.engines["copilot"]
./tests/test_tasks_and_subagents.py:1057:    result = manager.run(task, role="swe", engine_name="copilot", prompt="monitor quota")
./tests/test_tasks_and_subagents.py:1061:    record = monitoring.engines["copilot"]
./tests/test_tasks_and_subagents.py:1069:def _subagent_manager_records_copilot_quota_monitoring_during_live_updates(
./tests/test_tasks_and_subagents.py:1072:    _subagent_manager_records_copilot_quota_monitoring_during_live_updates(tmp_path, monkeypatch)
./tests/test_tasks_and_subagents.py:1506:            external_engine_sandbox=ExternalEngineSandboxConfig(
./tests/test_tasks_and_subagents.py:1590:            external_engine_sandbox=ExternalEngineSandboxConfig(
./tests/test_tasks_and_subagents.py:1668:            external_engine_sandbox=ExternalEngineSandboxConfig(
./tests/test_tasks_and_subagents.py:1745:            external_engine_sandbox=ExternalEngineSandboxConfig(
./tests/test_tasks_and_subagents.py:1846:            external_engine_sandbox=ExternalEngineSandboxConfig(
./tests/test_tasks_and_subagents.py:1910:            external_engine_sandbox=ExternalEngineSandboxConfig(
./tests/test_tasks_and_subagents.py:1997:            external_engine_sandbox=ExternalEngineSandboxConfig(
./tests/test_tasks_and_subagents.py:2083:            external_engine_sandbox=ExternalEngineSandboxConfig(
./tests/test_tasks_and_subagents.py:2164:            external_engine_sandbox=ExternalEngineSandboxConfig(
./tests/test_tasks_and_subagents.py:2337:            external_engine_sandbox=ExternalEngineSandboxConfig(
./tests/test_tasks_and_subagents.py:2687:            external_engine_sandbox=ExternalEngineSandboxConfig(
./tests/test_tasks_and_subagents.py:2842:            external_engine_sandbox=ExternalEngineSandboxConfig(
./tests_integration/helpers.py:41:            from heru.quota.codex_quota import codex_quota_block_reason
./tests_integration/helpers.py:44:            from heru.quota.claude_quota import claude_quota_block_reason
./tests_integration/helpers.py:46:        if engine_name == "copilot":
./tests_integration/helpers.py:47:            from heru.quota.copilot_quota import copilot_quota_block_reason
./tests_integration/helpers.py:48:            return copilot_quota_block_reason()
./tests_integration/helpers.py:97:        "codex": config.codex_model,
./tests_integration/helpers.py:101:        "copilot": config.copilot_model,
./tests_integration/helpers.py:102:        "claude": config.claude_model,
./tests_integration/helpers.py:115:    if engine_name == "copilot":
./tests_integration/helpers.py:186:        if engine_name == "copilot"
./tests/workspace_helpers.py:28:    format_external_engine_sandbox,
./tests/workspace_helpers.py:882:    "format_external_engine_sandbox",
./tests/conftest.py:7:import heru.quota.codex_quota as _codex_quota_mod
./tests/test_engine_parse_warnings.py:38:    from heru.adapters.claude import _extract_claude_text_delta_fallback
./tests/test_engine_parse_warnings.py:43:    with caplog.at_level(logging.WARNING, logger="litehive.agents.adapters.claude"):
./tests/test_engine_parse_warnings.py:51:    from heru.adapters.claude import _extract_claude_text_delta_fallback
./tests/test_engine_parse_warnings.py:55:    with caplog.at_level(logging.WARNING, logger="litehive.agents.adapters.claude"):
./tests/test_engine_parse_warnings.py:94:    from heru.adapters.codex import _extract_codex_transcript
./tests/test_engine_parse_warnings.py:97:    with caplog.at_level(logging.WARNING, logger="litehive.agents.adapters.codex"):
./tests/test_engine_parse_warnings.py:105:    from heru.adapters.codex import _extract_codex_transcript
./tests/test_engine_parse_warnings.py:108:    with caplog.at_level(logging.WARNING, logger="litehive.agents.adapters.codex"):
./tests/test_sandbox_git_profiles.py:40:        external_engine_sandbox=ExternalEngineSandboxConfig(
./tests/test_sandbox_git_profiles.py:234:            extra_ro_binds=[str(uv_dir)],
./tests/test_sandbox_git_profiles.py:261:            extra_ro_binds=[str(nvm_root)],
./tests/test_sandbox_git_profiles.py:287:            extra_ro_binds=[str(nvm_root)],
./tests_integration/test_copilot.py:14:def copilot_smoke_session(module_integration_root):
./tests_integration/test_copilot.py:15:    return prepare_smoke_session("copilot", cwd=module_integration_root)
./tests_integration/test_copilot.py:18:def test_copilot_smoke_prompt_succeeds(copilot_smoke_session) -> None:
./tests_integration/test_copilot.py:19:    assert_successful_smoke_session(copilot_smoke_session)
./tests_integration/test_copilot.py:22:def test_copilot_nudge_submits_verdict_via_cli(copilot_smoke_session) -> None:
./tests_integration/test_copilot.py:23:    assert_nudge_verdict_submission("copilot", smoke_session=copilot_smoke_session)
./tests/test_workspace_bootstrap.py:867:def test_copilot_extract_usage_observation_reads_quota_snapshot(tmp_path: Path) -> None:
./tests/test_workspace_bootstrap.py:868:    adapter = get_engine("copilot")
./tests/test_workspace_bootstrap.py:872:            adapter="copilot",
./tests/test_workspace_bootstrap.py:873:            argv=("copilot", "-p"),
./tests/test_workspace_bootstrap.py:919:def test_load_config_round_trips_external_engine_sandbox(tmp_path: Path) -> None:
./tests/test_workspace_bootstrap.py:923:            external_engine_sandbox=ExternalEngineSandboxConfig(
./tests/test_workspace_bootstrap.py:933:                        extra_ro_binds=["/opt/runtime"],
./tests/test_workspace_bootstrap.py:948:    assert config.external_engine_sandbox.enabled is True
./tests/test_workspace_bootstrap.py:949:    assert config.external_engine_sandbox.image == "ghcr.io/example/litehive-sandbox:latest"
./tests/test_workspace_bootstrap.py:950:    assert config.external_engine_sandbox.runtime_args == ["--pull=never"]
./tests/test_workspace_bootstrap.py:951:    policy = config.external_engine_sandbox.engine_policies["codex"]
./tests/test_workspace_bootstrap.py:956:    assert policy.extra_ro_binds == ["/opt/runtime"]
./litehive/config/engine_models.py:7:import heru.quota.claude_quota as claude_quota_mod
./litehive/config/engine_models.py:8:import heru.quota.codex_quota as codex_quota_mod
./litehive/config/engine_models.py:9:import heru.quota.copilot_quota as copilot_quota_mod
./litehive/config/engine_models.py:155:    if engine_name == "copilot":
./litehive/config/engine_models.py:156:        status = copilot_quota_mod.check_copilot_quota()
./litehive/config/engine_models.py:160:            f"copilot premium requests low ({status.long_term.percent_remaining:.0f}% remaining, resets {status.long_term.reset_at})",
./litehive/config/engine_models.py:241:        return config.codex_model
./litehive/config/engine_models.py:248:    if engine_name == "copilot":
./litehive/config/engine_models.py:249:        return config.copilot_model
./litehive/config/engine_models.py:251:        return config.claude_model
./litehive/config/formatting.py:6:def format_external_engine_sandbox(config: LitehiveConfig) -> str:
./litehive/config/formatting.py:7:    sandbox = config.external_engine_sandbox
./litehive/config/formatting.py:15:        binds = ",".join(policy.extra_ro_binds) or "-"
./tests_integration/README.md:10:- `copilot`
./tests_integration/README.md:19:LITEHIVE_INTEGRATION_ENGINES=codex,opencode,gemini,copilot,claude,goz uv run pytest tests_integration/ -q
./litehive/config/dataclasses.py:19:    extra_ro_binds: list[str] = field(default_factory=list)
./tests/test_engine_variants_and_timeline.py:37:    assert list(ENGINE_REGISTRY) == ["codex", "opencode", "goz", "gemini", "copilot", "claude"]
./tests/test_engine_variants_and_timeline.py:62:    assert not hasattr(adapters, "_copilot_live_events")
./tests/test_engine_variants_and_timeline.py:70:    for name in ("claude.py", "codex.py", "copilot.py", "gemini.py", "goz.py", "opencode.py"):
./tests/test_engine_variants_and_timeline.py:540:    assert config.claude_model == "claude-sonnet-4-20250514"
./tests/test_engine_variants_and_timeline.py:541:    assert config.claude_max_turns == 100
./tests/test_engine_variants_and_timeline.py:687:    assert config.claude_model == "claude-sonnet-4-20250514"
./tests/test_engine_variants_and_timeline.py:688:    assert config.claude_max_turns == 20
./tests/test_engine_variants_and_timeline.py:703:    assert config.claude_max_turns == 20
./tests/test_engine_variants_and_timeline.py:785:def test_extract_engine_timeline_copilot_message_events() -> None:
./tests/test_engine_variants_and_timeline.py:787:    timeline = extract_engine_timeline("copilot", stdout)
./tests/test_engine_variants_and_timeline.py:789:    assert timeline.engine == "copilot"
./litehive/config/model.py:13:    normalize_external_engine_sandbox_config,
./litehive/config/model.py:31:    copilot_model: str | None = None
./litehive/config/model.py:46:    external_engine_sandbox: ExternalEngineSandboxConfig = field(
./litehive/config/model.py:51:        default_factory=lambda: ["codex", "opencode", "gemini", "copilot", "goz"]
./litehive/config/model.py:82:        self.external_engine_sandbox = normalize_external_engine_sandbox_config(
./litehive/config/model.py:83:            self.external_engine_sandbox
./litehive/config/__init__.py:6:    format_external_engine_sandbox as format_external_engine_sandbox,
./litehive/tasks/constants.py:10:VALID_TASK_ENGINES = {"codex", "opencode", "gemini", "copilot", "claude", "goz"}
./heru/main.py:30:USAGE_PROVIDER_CHOICES = ("codex", "claude", "copilot", "zai", "gemini")
./heru/main.py:31:SUPPORTED_USAGE_PROVIDERS = ("codex", "claude", "copilot", "zai")
./heru/main.py:82:        block_reason = quota.codex_quota_block_reason()
./heru/main.py:96:        block_reason = quota.claude_quota_block_reason()
./heru/main.py:108:    if provider == "copilot":
./heru/main.py:109:        status_obj = quota.check_copilot_quota()
./heru/main.py:110:        block_reason = quota.copilot_quota_block_reason()
./docs/configuration.md:67:copilot_model: gpt-5
./docs/configuration.md:107:- `copilot`
./docs/configuration.md:138:  review: [copilot, codex]
./docs/configuration.md:146:engine_preference: [codex, opencode, gemini, copilot, goz]
./docs/configuration.md:236:external_engine_sandbox:
./litehive/cli/templates/workspace_config.yaml:22:copilot_model: null
./litehive/cli/templates/workspace_config.yaml:66:external_engine_sandbox:
./litehive/cli/templates/workspace_config.yaml:83:  #   credential_inputs[{env_var, mount_path}], extra_ro_binds
./litehive/cli/templates/workspace_config.yaml:94:  - copilot
./docs/engines.md:14:- `copilot`
./docs/engines.md:28:- `copilot_model`: optional
./docs/engines.md:62:  adapter: [codex, opencode, gemini, copilot, goz]
./docs/engines.md:63:  bugfix: [codex, opencode, copilot, gemini, goz]
./docs/engines.md:64:  research: [gemini, codex, opencode, copilot, goz]
./docs/engines.md:65:  review: [copilot, codex, opencode, gemini, goz]
./docs/engines.md:66:  refactor: [opencode, codex, copilot, gemini, goz]
./docs/engines.md:67:  docs: [codex, gemini, opencode, copilot, goz]
./docs/engines.md:68:  intake: [opencode, codex, gemini, copilot, goz]
./docs/engines.md:81:engine_preference: [codex, opencode, gemini, copilot, goz]
./docs/engines.md:142:external_engine_sandbox:
./heru/quota/copilot_quota.py:20:            ["gh", "api", "/copilot_internal/user"],
./heru/quota/copilot_quota.py:29:        logger.warning("copilot quota check failed (fail-open): %s", exc)
./heru/quota/copilot_quota.py:56:def check_copilot_quota(
./heru/quota/copilot_quota.py:71:def copilot_quota_block_reason(
./heru/quota/copilot_quota.py:77:    status = check_copilot_quota(cache_ttl=cache_ttl, _fetch=_fetch)
./heru/quota/copilot_quota.py:81:        return f"copilot premium requests low ({status.long_term.percent_remaining:.0f}% remaining, resets {status.long_term.reset_at})"
./docs/sandboxing.md:40:2. Switch `external_engine_sandbox.backend` to `docker` (heavier startup, but
./heru/quota/claude_quota.py:26:    return Path.home() / ".claude" / ".credentials.json"
./heru/quota/codex_quota.py:18:_AUTH_PATH = Path.home() / ".codex" / "auth.json"
./heru/quota/__init__.py:4:from heru.quota.claude_quota import *
./heru/quota/__init__.py:5:from heru.quota.codex_quota import *
./heru/quota/__init__.py:6:from heru.quota.copilot_quota import *
./tests_integration/test_sandbox_mock_engine.py:62:        external_engine_sandbox=ExternalEngineSandboxConfig(
./litehive/cli/workspace.py:10:from heru.quota.claude_quota import check_claude_quota
./litehive/cli/workspace.py:11:from heru.quota.codex_quota import check_codex_quota
./litehive/cli/workspace.py:12:from heru.quota.copilot_quota import check_copilot_quota
./litehive/cli/workspace.py:419:        "copilot": _copilot_quota_health(),
./litehive/cli/workspace.py:444:def _copilot_quota_health() -> _QuotaHealth:
./litehive/cli/workspace.py:445:    status = check_copilot_quota()
./litehive/cli/workspace.py:447:        return _QuotaHealth("copilot", "unavailable", status.error)
./litehive/cli/workspace.py:449:    return _QuotaHealth("copilot", "warning" if status.limit_reached else "ok", summary, status.limit_reached)
./heru/adapters/__init__.py:3:from heru.adapters.claude import ClaudeCLIAdapter
./heru/adapters/__init__.py:4:from heru.adapters.codex import CodexCLIAdapter
./heru/adapters/__init__.py:15:from heru.adapters.copilot import CopilotCLIAdapter
./heru/adapters/_codex_impl.py:11:logger = logging.getLogger("litehive.agents.adapters.codex")
./heru/adapters/_claude_impl.py:10:logger = logging.getLogger("litehive.agents.adapters.claude")
./litehive/recovery/execution_recovery.py:32:            candidates = ["claude", "codex", "copilot", "goz"]
./heru/adapters/codex.py:31:logger = logging.getLogger("litehive.agents.adapters.codex")
./heru/adapters/_copilot_impl.py:5:def copilot_usage_observation(
./heru/adapters/_copilot_impl.py:29:        selected_name, selected_snapshot = select_copilot_quota_snapshot(quota_snapshots)
./heru/adapters/_copilot_impl.py:31:            quota_usage = copilot_quota_usage_window(selected_snapshot)
./heru/adapters/_copilot_impl.py:55:def copilot_stream_event_adapter() -> StreamEventAdapter:
./heru/adapters/_copilot_impl.py:61:        continuation_id=copilot_continuation_id,
./heru/adapters/_copilot_impl.py:65:def copilot_continuation(payload: dict[str, object]) -> RuntimeEngineContinuation | None:
./heru/adapters/_copilot_impl.py:78:def copilot_continuation_id(payload: dict[str, object]) -> str | None:
./heru/adapters/_copilot_impl.py:79:    continuation = copilot_continuation(payload)
./heru/adapters/_copilot_impl.py:90:            events.append(LiveEvent(kind="message", engine="copilot", role="assistant", content=content))
./heru/adapters/_copilot_impl.py:94:            events.append(LiveEvent(kind="message", engine="copilot", role="assistant", content=content))
./heru/adapters/_copilot_impl.py:100:                engine="copilot",
./heru/adapters/_copilot_impl.py:116:                engine="copilot",
./heru/adapters/_copilot_impl.py:132:            events.append(LiveEvent(kind="usage", engine="copilot", metadata=meta))
./heru/adapters/_copilot_impl.py:134:        events.append(LiveEvent(kind="error", engine="copilot", error=data["message"]))
./heru/adapters/_copilot_impl.py:172:def copilot_quota_usage_window(snapshot: dict[str, object]) -> EngineUsageWindow | None:
./heru/adapters/_copilot_impl.py:188:def select_copilot_quota_snapshot(quota_snapshots: dict[str, object]) -> tuple[str, object]:
./heru/adapters/copilot.py:4:contract. The imported ``_copilot_impl`` helpers are internal.
./heru/adapters/copilot.py:9:from heru.adapters._copilot_impl import (
./heru/adapters/copilot.py:10:    copilot_continuation,
./heru/adapters/copilot.py:11:    copilot_stream_event_adapter,
./heru/adapters/copilot.py:12:    copilot_usage_observation,
./heru/adapters/copilot.py:27:    DEFAULT_NAME = "copilot"
./heru/adapters/copilot.py:28:    DEFAULT_BINARY = "copilot"
./heru/adapters/copilot.py:90:            observed = copilot_usage_observation(payload)
./heru/adapters/copilot.py:105:        return copilot_stream_event_adapter()
./heru/adapters/copilot.py:117:        return self.extract_continuation_from_payloads(execution, copilot_continuation)
```

```tool
output:
You are not authorized to perform this command.
```

I have the code references for sandbox policy handling. The `litehive task show` path is blocked by CLI auth in this worktree, so I’m using the task brief plus local config/docs to rewrite the task directly into a tighter grooming report.

```tool
output:
"""Supporting dataclasses for workspace configuration."""

from dataclasses import dataclass, field


@dataclass(slots=True)
class SandboxCredentialInput:
    env_var: str
    mount_path: str


@dataclass(slots=True)
class ExternalEngineSandboxPolicy:
    enabled: bool = False
    network_mode: str | None = None
    workspace_mode: str | None = None
    environment: list[str] = field(default_factory=list)
    credential_inputs: list[SandboxCredentialInput] = field(default_factory=list)
    extra_ro_binds: list[str] = field(default_factory=list)


@dataclass(slots=True)
class ExternalEngineSandboxConfig:
    enabled: bool = False
    backend: str = "docker"
    runtime_binary: str = "docker"
    image: str = "litehive-external-engine:latest"
    workspace_mount_path: str = "/workspace"
    binary_mount_root: str = "/litehive/bin"
    runtime_args: list[str] = field(default_factory=list)
    default_network_mode: str = "none"
    default_workspace_mode: str = "rw"
    read_only_rootfs: bool = True
    drop_capabilities: bool = True
    no_new_privileges: bool = True
    tmpfs: list[str] = field(default_factory=lambda: ["/tmp"])
    engine_policies: dict[str, ExternalEngineSandboxPolicy] = field(default_factory=dict)


@dataclass(slots=True)
class RunnerHookConfig:
    command: str
    reject_on_failure: bool = False
    description: str | None = None
    timeout_seconds: float | None = None
    instructions_on_failure: str | None = None


RUNNER_HOOK_EXECUTION_MODES = {"run_all", "fail_fast"}
```

```tool
output:
"""Sandbox planning and invocation wrapping for external engine execution.

Supports two backends:
- ``docker``: container-based isolation using Docker images.
- ``bubblewrap``: lightweight namespace-based isolation using bwrap(1).
"""

from dataclasses import dataclass
from enum import Enum
import hashlib
import os
from pathlib import Path, PurePosixPath
import shutil
import stat

from litehive.config import (
    ExternalEngineSandboxPolicy,
    LitehiveConfig,
)
from litehive.agents.base import CLIExecutionResult, CLIInvocation, ExternalCLIAdapter
from litehive.agents.engine_detection import (
    ORIGINAL_EXTERNAL_ADAPTER_RUN,
    ORIGINAL_EXTERNAL_ADAPTER_RUN_LIVE,
    effective_engine_callable,
    filter_supported_kwargs,
    has_callable_override,
)
from litehive.models import ResourceLimitEvent


@dataclass(frozen=True, slots=True)
class SandboxPolicySummary:
    enabled: bool
    profile: str = "no-git"
    backend: str | None = None
    runtime: str | None = None
    image: str | None = None
    network_mode: str | None = None
    workspace_mode: str | None = None
    environment: tuple[str, ...] = ()
    credential_inputs: tuple[str, ...] = ()
    propagated_mounts: tuple[str, ...] = ()

    def as_dict(self) -> dict[str, object]:
        return {
            "enabled": self.enabled,
            "profile": self.profile,
            "backend": self.backend,
            "runtime": self.runtime,
            "image": self.image,
            "network_mode": self.network_mode,
            "workspace_mode": self.workspace_mode,
            "environment": list(self.environment),
            "credential_inputs": list(self.credential_inputs),
            "propagated_mounts": list(self.propagated_mounts),
        }

    @property
    def summary(self) -> str:
        if not self.enabled:
            return "host"
        if self.backend == "bubblewrap":
            details = [
                "bwrap",
                f"profile={self.profile}",
                f"net={self.network_mode}",
                f"workspace={self.workspace_mode}",
            ]
        else:
            details = [
                f"{self.runtime}:{self.image}",
                f"profile={self.profile}",
                f"net={self.network_mode}",
                f"workspace={self.workspace_mode}",
            ]
        if self.environment:
            details.append(f"env={','.join(self.environment)}")
        if self.credential_inputs:
            details.append(f"creds={','.join(self.credential_inputs)}")
        if self.propagated_mounts:
            details.append(f"mounts={','.join(self.propagated_mounts)}")
        return "sandbox[" + " ".join(details) + "]"


class SandboxError(RuntimeError):
    """Raised when sandbox configuration cannot be applied."""


class SandboxProfile(str, Enum):
    NO_GIT = "no-git"
    MERGE_RESOLVER = "merge-resolver"


def sandbox_profile_for_role(role: str) -> SandboxProfile:
    normalized = role.strip().lower()
    if normalized == "merge-resolver":
        return SandboxProfile.MERGE_RESOLVER
    return SandboxProfile.NO_GIT


@dataclass(frozen=True, slots=True)
class _GitFilesystemPlan:
    profile: SandboxProfile
    prepend_path: tuple[str, ...] = ()
    extra_ro_binds: tuple[tuple[str, str], ...] = ()


class SandboxLauncher:
    def __init__(self, root: Path, config: LitehiveConfig) -> None:
        self.root = root.resolve()
        self.config = config

    def policy_summary(self, engine_name: str, role: str = "") -> SandboxPolicySummary:
        policy = self._policy_for_engine(engine_name)
        profile = sandbox_profile_for_role(role)
        sandbox_enabled = self.config.external_engine_sandbox.enabled and policy is not None and policy.enabled
        if not sandbox_enabled:
            return SandboxPolicySummary(enabled=False, profile=profile.value)
        return SandboxPolicySummary(
            enabled=True,
            profile=profile.value,
            backend=self.config.external_engine_sandbox.backend,
            runtime=self.config.external_engine_sandbox.runtime_binary,
            image=self.config.external_engine_sandbox.image,
            network_mode=(
                self.config.external_engine_sandbox.default_network_mode
                if policy is None or policy.network_mode is None
                else policy.network_mode
            ),
            workspace_mode=(
                self.config.external_engine_sandbox.default_workspace_mode
                if policy is None or policy.workspace_mode is None
                else policy.workspace_mode
            ),
            environment=tuple(() if policy is None else policy.environment),
            credential_inputs=tuple(
                () if policy is None else (item.env_var for item in policy.credential_inputs)
            ),
            propagated_mounts=(
                tuple(p for p in self.BWRAP_SYSTEM_RO_BINDS if Path(p).exists())
                if self.config.external_engine_sandbox.backend == "bubblewrap"
                else ()
            ),
        )

    def wrap_invocation(
        self,
        engine_name: str,
        binary_name: str,
        invocation: CLIInvocation,
        role: str = "",
    ) -> CLIInvocation:
        summary = self.policy_summary(engine_name, role)
        if not summary.enabled:
            return invocation

        runtime_config = self.config.external_engine_sandbox
        runtime_path = shutil.which(runtime_config.runtime_binary)
        if runtime_path is None:
            raise SandboxError(
                f"Sandbox runtime '{runtime_config.runtime_binary}' is unavailable for engine '{engine_name}'."
            )
        binary_path = shutil.which(binary_name)
        if binary_path is None:
            raise SandboxError(
                f"Engine '{engine_name}' is unavailable: missing binary '{binary_name}'"
            )

        if runtime_config.backend == "bubblewrap":
            return self._wrap_bubblewrap(
                engine_name,
                role,
                binary_name,
                binary_path,
                invocation,
                summary,
            )
        return self._wrap_docker(
            engine_name,
            role,
            binary_name,
            binary_path,
            invocation,
            summary,
        )

    def _wrap_docker(
        self,
        engine_name: str,
        role: str,
        binary_name: str,
        binary_path: str,
        invocation: CLIInvocation,
        summary: SandboxPolicySummary,
    ) -> CLIInvocation:
        runtime_config = self.config.external_engine_sandbox
        policy = self._policy_for_engine(engine_name)
        workspace_mount = PurePosixPath(runtime_config.workspace_mount_path)
        workspace_mode = (
            runtime_config.default_workspace_mode
            if policy is None or policy.workspace_mode is None
            else policy.workspace_mode
        )
        container_argv = self._translate_container_argv(
            invocation.argv,
            host_root=self.root,
            container_root=workspace_mount,
        )

        mounted_binary_name = Path(binary_path).name
        container_binary_path = (
            PurePosixPath(runtime_config.binary_mount_root) / mounted_binary_name
        )
        if container_argv:
            container_argv[0] = str(container_binary_path)

        argv: list[str] = [runtime_config.runtime_binary, "run", "--rm", "--init"]
        argv.extend(runtime_config.runtime_args)
        argv.extend(["--workdir", str(workspace_mount)])
        argv.extend(["--network", summary.network_mode or runtime_config.default_network_mode])
        if runtime_config.read_only_rootfs:
            argv.append("--read-only")
        if runtime_config.drop_capabilities:
            argv.extend(["--cap-drop", "ALL"])
        if runtime_config.no_new_privileges:
            argv.extend(["--security-opt", "no-new-privileges"])
        for tmpfs_path in runtime_config.tmpfs:
            argv.extend(["--tmpfs", tmpfs_path])

        argv.extend(
            [
                "--mount",
                self._bind_mount_spec(
                    self.root,
                    workspace_mount,
                    read_only=workspace_mode == "ro",
                ),
                "--mount",
                self._bind_mount_spec(
                    Path(binary_path).resolve(), container_binary_path, read_only=True
                ),
            ]
        )

        allowed_env: dict[str, str] = {}
        for env_name in () if policy is None else policy.environment:
            value = invocation.env.get(env_name)
            if value is not None:
                allowed_env[env_name] = value
        git_plan = self._prepare_git_filesystem(role)
        extra_ro_binds = self._resolved_extra_ro_binds(engine_name, policy)
        if git_plan.prepend_path:
            existing_path = invocation.env.get("PATH", os.environ.get("PATH", ""))
            segments = [*git_plan.prepend_path]
            if existing_path:
                segments.append(existing_path)
            allowed_env["PATH"] = ":".join(segments)
        for source, target in git_plan.extra_ro_binds:
            argv.extend(["--mount", self._bind_mount_spec(Path(source), PurePosixPath(target), read_only=True)])
        for host_path in extra_ro_binds:
```

```tool
output:

```yaml
pool_stop_on_failure: false
pool_max_tasks: 10
pool_stop_on_dirty_git: true
pool_selection_policy: dependency_aware
```

These values define when a draining run or daemon iteration should stop before
claiming more work.

## External Engine Sandboxing

Advanced deployments can run external engine CLIs inside a sandbox:

```yaml
external_engine_sandbox:
  enabled: true
  backend: docker
  runtime_binary: docker
  image: litehive-external-engine:latest
  default_network_mode: none
  default_workspace_mode: rw
```

Per-engine policies can selectively allow environment variables, network
settings, and mounted credentials.

Litehive now applies a role-based git sandbox on top of that engine policy:

- `merge-resolver` is the only role with a visible `git` command
- all other roles fail closed to the no-git profile

See [sandboxing.md](sandboxing.md) for the enforced profile map, denylist, and
manual adversarial audit workflow.

## Agent Startup Guidance

You can add role-specific instructions that become part of agent prompts:

```yaml
agent_startup_guidance:
  all:
    - Start from the task record and latest reports.
  swe:
    - Prefer targeted file reads over broad repo scans.
  qa:
    - Verify with focused tests before broader commands.
  recovery:
    - Inspect recovery artifacts before changing code.
```

Valid keys are `all`, `planner`, `swe`, `qa`, `reviewer`, and `recovery`.

## Recommended Starting Point

For a normal single-repo setup, this is a reasonable first config:

```yaml
default_engine: codex
recovery_engine: codex
process_profile: generic
default_retry_limit: 3
default_stage_retry_limit: 2
auto_commit: true

runner_hooks:
  before_pm_acceptance:
    - command: uv run pytest -q
      blocking: true
```

Then tune routing, fallbacks, and retry behavior only after you have a few real
runs to learn from.

---

# Timeout budget for detecting hung subagents and top-level runs.
subagent_inactivity_timeout_seconds: 360.0
inactivity_timeout_seconds: null

# External engine sandbox configuration used for adapters that launch outside the repo.
external_engine_sandbox:
  enabled: false
  backend: docker
  runtime_binary: docker
  image: litehive-external-engine:latest
  workspace_mount_path: /workspace
  binary_mount_root: /litehive/bin
  runtime_args: []
  default_network_mode: none
  default_workspace_mode: rw
  read_only_rootfs: true
  drop_capabilities: true
  no_new_privileges: true
  tmpfs:
    - /tmp
  # Per-engine sandbox overrides. Each engine policy supports:
  #   enabled, network_mode, workspace_mode, environment,
  #   credential_inputs[{env_var, mount_path}], extra_ro_binds
  engine_policies: {}

# Temporary engine freezes keyed by engine name -> UTC timestamp.
engine_freeze: {}

# Engine fallback order when the preferred engine is unavailable.
engine_preference:
  - codex
  - opencode
  - gemini
  - copilot
  - goz

# Optional startup guidance injected by role.
# Example:
# agent_startup_guidance:
#   swe:
#     - Run focused tests before reporting pass.
agent_startup_guidance: {}

# Workspace defaults for automatic commits and display labels.
auto_commit: true
task_mode_name: tasks
implementation_mode_name: implementation
```

I’ve confirmed the config model already supports both `environment` and `extra_ro_binds`, so the task should focus on shaping engine policy defaults, engine-specific mount/env resolution, and the acceptance split between unit coverage and a real sandbox smoke. I’m tightening that now so the next agent doesn’t mix infra wiring with broad engine speculation.

```tool
output:
                    Path(binary_path).resolve(), container_binary_path, read_only=True
                ),
            ]
        )

        allowed_env: dict[str, str] = {}
        for env_name in () if policy is None else policy.environment:
            value = invocation.env.get(env_name)
            if value is not None:
                allowed_env[env_name] = value
        git_plan = self._prepare_git_filesystem(role)
        extra_ro_binds = self._resolved_extra_ro_binds(engine_name, policy)
        if git_plan.prepend_path:
            existing_path = invocation.env.get("PATH", os.environ.get("PATH", ""))
            segments = [*git_plan.prepend_path]
            if existing_path:
                segments.append(existing_path)
            allowed_env["PATH"] = ":".join(segments)
        for source, target in git_plan.extra_ro_binds:
            argv.extend(["--mount", self._bind_mount_spec(Path(source), PurePosixPath(target), read_only=True)])
        for host_path in extra_ro_binds:
            argv.extend(
                [
                    "--mount",
                    self._bind_mount_spec(host_path, PurePosixPath(str(host_path)), read_only=True),
                ]
            )
        for credential in () if policy is None else policy.credential_inputs:
            raw_path = invocation.env.get(credential.env_var)
            if not raw_path:
                continue
            host_path = Path(raw_path).expanduser().resolve()
            argv.extend(
                [
                    "--mount",
                    self._bind_mount_spec(
                        host_path, PurePosixPath(credential.mount_path), read_only=True
                    ),
                ]
            )
            allowed_env[credential.env_var] = credential.mount_path

        for env_name, value in sorted(allowed_env.items()):
            argv.extend(["--env", f"{env_name}={value}"])

        argv.append(runtime_config.image)
        argv.extend(container_argv)
        return CLIInvocation(argv=tuple(argv), cwd=invocation.cwd, env=invocation.env)

    # Minimal read-only system paths exposed to the bubblewrap sandbox.
    BWRAP_SYSTEM_RO_BINDS: tuple[str, ...] = (
        "/usr",
        "/lib",
        "/lib64",
        "/bin",
        "/sbin",
        "/etc/alternatives",
        "/etc/resolv.conf",
        "/etc/ssl",
        "/etc/ca-certificates",
        "/etc/ld.so.cache",
    )

    def _wrap_bubblewrap(
        self,
        engine_name: str,
        role: str,
        binary_name: str,
        binary_path: str,
        invocation: CLIInvocation,
        summary: SandboxPolicySummary,
    ) -> CLIInvocation:
        runtime_config = self.config.external_engine_sandbox
        policy = self._policy_for_engine(engine_name)
        workspace_mode = (
            runtime_config.default_workspace_mode
            if policy is None or policy.workspace_mode is None
            else policy.workspace_mode
        )

        argv: list[str] = [runtime_config.runtime_binary]
        argv.extend(runtime_config.runtime_args)

        # Namespace isolation. Avoid hard-failing on hosts that forbid unprivileged
        # user namespaces while still isolating the filesystem and process tree.
        argv.extend(["--unshare-ipc", "--unshare-pid", "--unshare-uts", "--unshare-cgroup-try"])
        if (summary.network_mode or runtime_config.default_network_mode) == "none":
            argv.append("--unshare-net")
        argv.append("--die-with-parent")

        # Basic virtual filesystems.
        argv.extend(["--proc", "/proc"])
        argv.extend(["--dev", "/dev"])
        for tmpfs_path in runtime_config.tmpfs:
            argv.extend(["--tmpfs", tmpfs_path])

        git_plan = self._prepare_git_filesystem(role)
        extra_ro_binds = self._resolved_extra_ro_binds(engine_name, policy)

        # Read-only system mounts (only existing paths).
        for sys_path in self.BWRAP_SYSTEM_RO_BINDS:
            if Path(sys_path).exists():
                argv.extend(["--ro-bind", sys_path, sys_path])

        for source, target in git_plan.extra_ro_binds:
            argv.extend(["--ro-bind", source, target])
        for host_path in extra_ro_binds:
            host_path_str = str(host_path)
            argv.extend(["--ro-bind", host_path_str, host_path_str])

        # Workspace mount.
        workspace_root = str(self.root)
        if workspace_mode == "ro":
            argv.extend(["--ro-bind", workspace_root, workspace_root])
        else:
            argv.extend(["--bind", workspace_root, workspace_root])

        # Engine binary (read-only, at its host path).
        resolved_binary = str(Path(binary_path).resolve())
        if not resolved_binary.startswith(workspace_root + os.sep):
            argv.extend(["--ro-bind", resolved_binary, resolved_binary])

        # Credential mounts.
        for credential in () if policy is None else policy.credential_inputs:
            raw_path = invocation.env.get(credential.env_var)
            if not raw_path:
                continue
            host_path = str(Path(raw_path).expanduser().resolve())
            argv.extend(["--ro-bind", host_path, credential.mount_path])

        # Clear environment and propagate only allowed variables.
        argv.append("--clearenv")
        allowed_env: dict[str, str] = {}
        for env_name in () if policy is None else policy.environment:
            value = invocation.env.get(env_name)
            if value is not None:
                allowed_env[env_name] = value
        for credential in () if policy is None else policy.credential_inputs:
            if invocation.env.get(credential.env_var):
                allowed_env[credential.env_var] = credential.mount_path
        # Always propagate PATH and HOME for basic tool operation.
        for builtin_var in ("PATH", "HOME"):
            if builtin_var not in allowed_env:
                value = invocation.env.get(builtin_var, os.environ.get(builtin_var, ""))
                if value:
                    allowed_env[builtin_var] = value
        if git_plan.prepend_path:
            existing_path = allowed_env.get("PATH", "")
            segments = [*git_plan.prepend_path]
            if existing_path:
                segments.append(existing_path)
            allowed_env["PATH"] = ":".join(segments)
        for env_name, value in sorted(allowed_env.items()):
            argv.extend(["--setenv", env_name, value])

        # Working directory and command.
        sandbox_argv = list(invocation.argv)
        if sandbox_argv:
            sandbox_argv[0] = resolved_binary
        argv.extend(["--chdir", workspace_root])
        argv.append("--")
        argv.extend(sandbox_argv)

        return CLIInvocation(argv=tuple(argv), cwd=invocation.cwd, env=invocation.env)

    def _policy_for_engine(self, engine_name: str) -> ExternalEngineSandboxPolicy | None:
        return self.config.external_engine_sandbox.engine_policies.get(engine_name)

    @staticmethod
    def _resolved_extra_ro_binds(
        engine_name: str,
        policy: ExternalEngineSandboxPolicy | None,
    ) -> tuple[Path, ...]:
        resolved_paths: list[Path] = []
        for raw_path in () if policy is None else policy.extra_ro_binds:
            host_path = Path(raw_path).expanduser()
            if not host_path.exists():
                raise SandboxError(
                    f"Sandbox policy for engine '{engine_name}' requires read-only bind path "
                    f"'{host_path}', but it does not exist on the host."
                )
            resolved_paths.append(host_path.resolve())
        return tuple(resolved_paths)

    def classify_resource_limit_event(
        self,
        engine_name: str,
        *,
        exit_code: int,
        stdout: str,
        stderr: str,
    ) -> ResourceLimitEvent | None:
        return None

    @staticmethod
    def _translate_container_argv(
        argv: tuple[str, ...],
        *,
        host_root: Path,
        container_root: PurePosixPath,
    ) -> list[str]:
        translated: list[str] = []
        host_root_text = str(host_root)
        for arg in argv:
            if arg == host_root_text:
                translated.append(str(container_root))
                continue
            if arg.startswith(host_root_text + os.sep):
                relative = Path(arg).resolve().relative_to(host_root)
                translated.append(str(container_root / relative.as_posix()))
                continue
            translated.append(arg)
        return translated

    @staticmethod
    def _bind_mount_spec(source: Path, target: PurePosixPath, *, read_only: bool) -> str:
        mode = ",readonly" if read_only else ""
        return f"type=bind,src={source},dst={target}{mode}"

    def _prepare_git_filesystem(self, role: str) -> _GitFilesystemPlan:
        profile = sandbox_profile_for_role(role)
```

```tool
output:
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

import pytest

from litehive.config import LitehiveConfig, VALID_ENGINE_NAMES, ensure_workspace, load_config
from litehive.agents import extract_engine_continuation, get_engine
from litehive.agents.base import CLIExecutionResult


INTEGRATION_ENV = "LITEHIVE_INTEGRATION_ENGINES"
TIMEOUT_ENV = "LITEHIVE_INTEGRATION_TIMEOUT_SECONDS"
DEFAULT_TIMEOUT_SECONDS = 30
ENGINE_MATRIX = tuple(sorted(VALID_ENGINE_NAMES))


@dataclass(frozen=True, slots=True)
class SmokeSession:
    engine_name: str
    cwd: Path
    task_id: str
    engine: object
    execution: CLIExecutionResult
    resume_session_id: str | None = None


def enabled_integration_engines() -> set[str]:
    raw = os.environ.get(INTEGRATION_ENV, "")
    if not raw.strip():
        return set()
    return {item.strip() for item in raw.split(",") if item.strip()}


def _engine_quota_block_reason(engine_name: str) -> str | None:
    """Check if an engine's quota is too high to run integration tests."""
    try:
        if engine_name == "codex":
            from heru.quota.codex_quota import codex_quota_block_reason
            return codex_quota_block_reason()
        if engine_name == "claude":
            from heru.quota.claude_quota import claude_quota_block_reason
            return claude_quota_block_reason()
        if engine_name == "copilot":
            from heru.quota.copilot_quota import copilot_quota_block_reason
            return copilot_quota_block_reason()
        if engine_name in ("goz", "opencode"):
            from heru.quota.zai_quota import zai_quota_block_reason
            return zai_quota_block_reason()
    except Exception:
        pass
    return None


def require_real_engine(engine_name: str) -> None:
    engine = get_engine(engine_name)
    if not engine.is_available():
        pytest.skip(f"{engine_name} binary not available on PATH")
    quota_reason = _engine_quota_block_reason(engine_name)
    if quota_reason:
        pytest.skip(f"{engine_name} quota too high: {quota_reason}")


def integration_workspace(root: Path) -> Path:
    ensure_workspace(
        root,
        LitehiveConfig(
            default_engine="codex",
            opencode_model="zai-coding-plan/glm-5.1",
            gemini_model="gemini-2.5-flash-lite",
            claude_model="claude-sonnet-4-20250514",
        ),
    )
    return root


def smoke_prompt(engine_name: str) -> str:
    return f"Reply with exactly: {engine_name} integration smoke."


def execute_engine_prompt(
    engine_name: str,
    *,
    prompt: str,
    cwd: Path,
    max_turns: int | None = None,
    resume_session_id: str | None = None,
    extra_env: dict[str, str] | None = None,
) -> tuple[object, CLIExecutionResult]:
    engine = get_engine(engine_name)
    if max_turns is None and engine_name == "claude":
        max_turns = 1
    config = load_config(cwd)
    model = {
        "codex": config.codex_model,
        "opencode": config.opencode_model,
        "goz": config.goz_model,
        "gemini": config.gemini_model,
        "copilot": config.copilot_model,
        "claude": config.claude_model,
    }.get(engine_name)
    invocation = engine.finalize_invocation(
        engine.build_invocation(
            prompt,
            cwd,
            model=model,
            max_turns=max_turns,
            resume_session_id=resume_session_id,
            extra_env=extra_env,
        )
    )
    argv = list(invocation.argv)
    if engine_name == "copilot":
        argv.extend(
            [
                "--reasoning-effort",
                "low",
                "--max-autopilot-continues",
                "0",
                "--disable-builtin-mcps",
                "--no-custom-instructions",
            ]
        )
    elif engine_name == "gemini":
        argv.extend(["--sandbox", "false"])
    timeout_seconds = int(os.environ.get(TIMEOUT_ENV, str(DEFAULT_TIMEOUT_SECONDS)))
    try:
        completed = subprocess.run(
            argv,
            cwd=invocation.cwd,
            env=invocation.env,
            stdin=subprocess.DEVNULL,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        stdout_tail = (exc.stdout or "")[-800:]
        stderr_tail = (exc.stderr or "")[-800:]
        pytest.fail(
            f"{engine_name} timed out after {timeout_seconds}s\n"
            f"argv: {argv!r}\n"
            f"stdout_tail:\n{stdout_tail}\n"
            f"stderr_tail:\n{stderr_tail}"
        )
    sandboxed, sandbox_summary = engine.sandbox_details()
    return engine, CLIExecutionResult(
        adapter=engine.name,
        argv=tuple(argv),
        cwd=invocation.cwd,
        exit_code=completed.returncode,
        stdout=completed.stdout,
        stderr=completed.stderr,
        sandboxed=sandboxed,
        sandbox_summary=sandbox_summary,
    )


def _assistant_transcript(transcript: str) -> str:
    return transcript.partition("\n\n[stderr]\n")[0].strip()


def prepare_smoke_session(engine_name: str, *, cwd: Path) -> SmokeSession:
    from litehive.tasks import create_task, require_task, save_task, set_active_task

    require_real_engine(engine_name)
    task = create_task(cwd, title=f"{engine_name} nudge task", auto_commit=False)
    task = require_task(cwd, task.id)
    task.pipeline_status = "implementing"
    save_task(cwd, task)
    set_active_task(cwd, task.id)
    engine, execution = execute_engine_prompt(
        engine_name,
        prompt=smoke_prompt(engine_name),
        cwd=cwd,
    )
    assert execution.exit_code == 0, execution.transcript
    continuation = extract_engine_continuation(engine_name, execution)
    resume_session_id = (
        continuation.session_id
        if continuation is not None and continuation.session_id
        else "latest"
        if engine_name == "copilot"
        else None
    )
    return SmokeSession(
        engine_name=engine_name,
        cwd=cwd,
        task_id=task.id,
        engine=engine,
        execution=execution,
        resume_session_id=resume_session_id,
    )


def assert_successful_smoke_session(session: SmokeSession) -> None:
    transcript = _assistant_transcript(session.engine.render_transcript(session.execution))
    assert transcript.strip(), f"Expected assistant output from {session.engine_name}"


def assert_successful_smoke_prompt(engine_name: str, *, cwd: Path) -> None:
    assert_successful_smoke_session(prepare_smoke_session(engine_name, cwd=cwd))


def assert_nudge_verdict_submission(
    engine_name: str,
    *,
    cwd: Path | None = None,
    smoke_session: SmokeSession | None = None,
) -> None:
    """Verify the nudge flow: run engine, then nudge to submit verdict via CLI."""
    from litehive.tasks import load_task_thread, require_task

    session = smoke_session
    if session is None:
        assert cwd is not None, "cwd is required when smoke_session is not provided"
        session = prepare_smoke_session(engine_name, cwd=cwd)

---
import pytest

from .helpers import (
    assert_nudge_verdict_submission,
    assert_successful_smoke_session,
    prepare_smoke_session,
)


pytestmark = pytest.mark.integration


@pytest.fixture(scope="module")
def copilot_smoke_session(module_integration_root):
    return prepare_smoke_session("copilot", cwd=module_integration_root)


def test_copilot_smoke_prompt_succeeds(copilot_smoke_session) -> None:
    assert_successful_smoke_session(copilot_smoke_session)


def test_copilot_nudge_submits_verdict_via_cli(copilot_smoke_session) -> None:
    assert_nudge_verdict_submission("copilot", smoke_session=copilot_smoke_session)
```

```tool
output:

    assert result.ref.status == "completed"
    base = task_dir(tmp_path, task) / "subagents" / "SA-0001-swe"
    session = yaml.safe_load((base / "session.yaml").read_text(encoding="utf-8"))
    assert session["status"] == "completed"
    assert session["pid"] == 6161
    assert session["exit_code"] == 0

    refreshed = get_task(tmp_path, task.id)
    assert refreshed is not None
    assert refreshed.runtime.active_subagent is None
    assert refreshed.runtime.last_subagent is not None
    assert refreshed.runtime.last_subagent.pid == 6161

def _subagent_streaming_pid_persists_before_first_live_output(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _subagent_streaming_pid_persists_before_first_live_output(tmp_path, monkeypatch)


def _subagent_artifacts_capture_sandbox_metadata(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    ensure_workspace(
        tmp_path,
        LitehiveConfig(
            external_engine_sandbox=ExternalEngineSandboxConfig(
                enabled=True,
                image="ghcr.io/example/litehive-sandbox:latest",
                engine_policies={
                    "codex": ExternalEngineSandboxPolicy(
                        enabled=True,
                        network_mode="none",
                        workspace_mode="rw",
                        environment=["OPENAI_API_KEY"],
                    )
                },
            )
        ),
    )
    task = create_task(tmp_path, title="Persist sandbox metadata")
    manager = SubagentManager(tmp_path)
    calls: dict[str, object] = {}

    class FakePopen:
        def __init__(self, cmd, cwd, env, stdout, stderr, text, stdin=None):  # type: ignore[no-untyped-def]
            calls["cmd"] = cmd
            calls["cwd"] = cwd
            calls["env"] = env
            self.pid = 7272
            self.returncode = 0
            stdout_read, stdout_write = os.pipe()
            stderr_read, stderr_write = os.pipe()
            os.write(
                stdout_write,
                (
                    "VERDICT: PASS\nSUMMARY: sandboxed execution\nFILES_CHANGED:\n"
                    "- litehive/sandbox.py\nTESTS_ADDED: 1\nTESTS_PASSING: 1\nWARNINGS:\n"
                ).encode("utf-8"),
            )
            os.close(stdout_write)
            os.close(stderr_write)
            self.stdout = os.fdopen(stdout_read, "rb")
            self.stderr = os.fdopen(stderr_read, "rb")

        def poll(self):  # type: ignore[no-untyped-def]
            return self.returncode

        def wait(self):  # type: ignore[no-untyped-def]
            return self.returncode

    monkeypatch.setattr("shutil.which", lambda binary: f"/usr/bin/{binary}")
    monkeypatch.setattr("subprocess.Popen", FakePopen)
    monkeypatch.setattr(
        "litehive.agents.manager.supports_live_on_started", lambda engine: False
    )
    monkeypatch.setenv("OPENAI_API_KEY", "secret")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "should-not-leak")

    result = manager.run(task, role="swe", engine_name="codex", prompt="implement it")

    assert result.execution is not None
    assert result.execution.sandboxed is True
    assert "sandbox[" in result.execution.sandbox_summary
    assert "--env OPENAI_API_KEY=secret" in " ".join(calls["cmd"])
    assert "ANTHROPIC_API_KEY" not in " ".join(calls["cmd"])

    base = task_dir(tmp_path, task) / "subagents" / "SA-0001-swe"
    session = yaml.safe_load((base / "session.yaml").read_text(encoding="utf-8"))
    assert session["sandboxed"] is True
    assert session["sandbox"].startswith("sandbox[")

    refreshed = get_task(tmp_path, task.id)
    assert refreshed is not None
    assert refreshed.runtime.last_subagent is not None
    assert refreshed.runtime.last_subagent.sandboxed is True
    assert refreshed.runtime.last_subagent.sandbox_summary.startswith("sandbox[")

def _subagent_artifacts_capture_sandbox_metadata(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _subagent_artifacts_capture_sandbox_metadata(tmp_path, monkeypatch)


def _subagent_manager_uses_inherited_run_live_when_sandbox_binary_is_present(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    ensure_workspace(
        tmp_path,
        LitehiveConfig(
            external_engine_sandbox=ExternalEngineSandboxConfig(
                enabled=True,
                image="ghcr.io/example/litehive-sandbox:latest",
                engine_policies={"codex": ExternalEngineSandboxPolicy(enabled=True)},
            )
        ),
    )
    task = create_task(tmp_path, title="Sandboxed fallback usage-limit task")
    manager = SubagentManager(tmp_path)
    engine = get_engine("codex")

    monkeypatch.setattr("litehive.agents.manager.get_engine", lambda _: engine)
    monkeypatch.setattr(engine, "is_available", lambda: True)

    calls: list[str] = []

    def fail_run(*args, **kwargs) -> CLIExecutionResult:  # type: ignore[no-untyped-def]
        raise AssertionError("run should not be used when sandboxed run_live is available")

    def fake_run_live(
        self,
        prompt: str,
        cwd: Path,
        model: str | None = None,
        *,
        max_turns: int | None = None,
        resume_session_id: str | None = None,
        on_started=None,
        on_update=None,
        inactivity_timeout_seconds=None,
        **kwargs,
    ) -> CLIExecutionResult:
        del self, prompt, model, max_turns, resume_session_id, inactivity_timeout_seconds, kwargs
        calls.append("run_live")
        assert on_started is not None
        on_started(4343)
        assert on_update is not None
        on_update(
            CLIExecutionResult(
                adapter="codex",
                argv=("codex", "exec"),
                cwd=cwd,
                exit_code=1,
                stdout="",
                stderr="ERROR: You've hit your usage limit. Try again later.",
                pid=4343,
            )
        )
        return CLIExecutionResult(
            adapter="codex",
            argv=("codex", "exec"),
            cwd=cwd,
            exit_code=1,
            stdout="",
            stderr="ERROR: You've hit your usage limit. Try again later.",
            pid=4343,
        )

    monkeypatch.setattr("litehive.agents.base.ExternalCLIAdapter.run", fail_run)
    monkeypatch.setattr("litehive.agents.base.ExternalCLIAdapter.run_live", fake_run_live)

    result = manager.run(task, role="swe", engine_name="codex", prompt="implement it")

    assert calls == ["run_live"]
    assert result.failure == EngineFailure(kind="execution_limit", reason="usage limit reached")

def _subagent_manager_uses_inherited_run_live_when_sandbox_binary_is_present(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _subagent_manager_uses_inherited_run_live_when_sandbox_binary_is_present(tmp_path, monkeypatch)


def _subagent_manager_uses_inherited_run_live_when_sandboxed_and_base_run_is_rebound(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    ensure_workspace(
        tmp_path,
        LitehiveConfig(
            external_engine_sandbox=ExternalEngineSandboxConfig(
                enabled=True,
                engine_policies={"codex": ExternalEngineSandboxPolicy(enabled=True)},
            )
        ),
    )
    task = create_task(tmp_path, title="Fallback usage-limit task")
    manager = SubagentManager(tmp_path)
    engine = get_engine("codex")

    monkeypatch.setattr("litehive.agents.manager.get_engine", lambda _: engine)
    monkeypatch.setattr(engine, "is_available", lambda: True)
    monkeypatch.setattr("shutil.which", lambda binary: f"/usr/bin/{binary}")

    calls: list[str] = []

    def fail_run(*args, **kwargs) -> CLIExecutionResult:  # type: ignore[no-untyped-def]
        raise AssertionError("run should not be preferred when sandboxed run_live remains inherited")

    def fake_run_live(
        self,
        prompt: str,
        cwd: Path,
        model: str | None = None,
        *,
        max_turns: int | None = None,
        on_started=None,
        on_update=None,
        inactivity_timeout_seconds=None,
        **kwargs,
    ) -> CLIExecutionResult:
        del self, prompt, model, max_turns, inactivity_timeout_seconds, kwargs
        calls.append("run_live")
        assert on_started is not None
        on_started(4647)
        assert on_update is not None
        on_update(
            CLIExecutionResult(
                adapter="codex",
                argv=("codex", "exec"),
                cwd=cwd,
                exit_code=1,
                stdout="",
                stderr="ERROR: You've hit your usage limit. Try again later.",
                pid=4647,
            )
        )
        return CLIExecutionResult(
            adapter="codex",
            argv=("codex", "exec"),
            cwd=cwd,
            exit_code=1,
            stdout="",
            stderr="ERROR: You've hit your usage limit. Try again later.",
            pid=4647,
        )

    monkeypatch.setattr("litehive.agents.base.ExternalCLIAdapter.run", fail_run)
    monkeypatch.setattr("litehive.agents.base.ExternalCLIAdapter.run_live", fake_run_live)

    result = manager.run(task, role="swe", engine_name="codex", prompt="implement it")

    assert calls == ["run_live"]
    assert result.failure == EngineFailure(kind="execution_limit", reason="usage limit reached")

def _subagent_manager_uses_inherited_run_live_when_sandboxed_and_base_run_is_rebound(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _subagent_manager_uses_inherited_run_live_when_sandboxed_and_base_run_is_rebound(tmp_path, monkeypatch)


def _subagent_manager_ignores_class_alias_to_rebound_base_run_when_sandboxed_and_run_live_is_available(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    ensure_workspace(
        tmp_path,
        LitehiveConfig(
            external_engine_sandbox=ExternalEngineSandboxConfig(
                enabled=True,
                engine_policies={"codex": ExternalEngineSandboxPolicy(enabled=True)},
            )
        ),
    )
    task = create_task(tmp_path, title="Fallback usage-limit task")
    manager = SubagentManager(tmp_path)

    calls: list[str] = []

    def rebound_base_run(*args, **kwargs) -> CLIExecutionResult:  # type: ignore[no-untyped-def]
        raise AssertionError("run should not be used when it aliases the rebound base method")

    monkeypatch.setattr("litehive.agents.base.ExternalCLIAdapter.run", rebound_base_run)
    monkeypatch.setattr("shutil.which", lambda binary: f"/usr/bin/{binary}")

    class LivePreferredEngine(ExternalCLIAdapter):
        def __init__(self) -> None:
            super().__init__(
                name="codex",
                binary="codex",
                capabilities=AdapterCapabilities(available=True),
            )

        def is_available(self) -> bool:
```

There’s already test surface for sandbox summaries and engine prompt integrations, which means this task can demand targeted unit coverage plus one end-to-end sandbox smoke instead of inventing a brand new harness. I’m aligning the acceptance criteria to that existing structure.

```tool
output:
# Sandboxing And Git Access

Litehive now applies git access policy at the sandbox filesystem boundary, not
through prompt text, role env vars, or PATH-only tricks.

## Host Prerequisites (Bubblewrap backend)

Litehive supports two sandbox backends: `docker` and `bubblewrap`. Bubblewrap is
the lighter-weight option (no daemon, namespace-based, near-zero startup cost)
and is preferred for single-developer hosts.

On Ubuntu 24.04 and other distributions that ship with the AppArmor userns
restriction, unprivileged `bwrap` will fail at startup with:

```
bwrap: setting up uid map: Permission denied
```

This is caused by the kernel setting
`kernel.apparmor_restrict_unprivileged_userns = 1`, which blocks unprivileged
user namespace creation except for binaries with an approved AppArmor profile.
Bubblewrap is not on the default allowlist.

### Fix (one-time, requires sudo)

Persist the setting and apply it live without rebooting:

```bash
echo 'kernel.apparmor_restrict_unprivileged_userns = 0' | \
  sudo tee /etc/sysctl.d/60-bwrap.conf
sudo sysctl -w kernel.apparmor_restrict_unprivileged_userns=0
```

**Security impact.** This disables one layer of Ubuntu's user-namespace
hardening system-wide. It is fine on a single-developer workstation that you
control; it is *not* appropriate for shared multi-user hosts or production
machines. If you cannot disable the restriction system-wide, either:

1. Write an AppArmor profile that allows userns creation for just `/usr/bin/bwrap`.
2. Switch `external_engine_sandbox.backend` to `docker` (heavier startup, but
   does not depend on unprivileged user namespaces).

### Verify

After the sysctl change, a minimal bwrap invocation should succeed:

```bash
bwrap --unshare-pid --unshare-uts --unshare-ipc --die-with-parent \
  --proc /proc --dev /dev --tmpfs /tmp \
  --ro-bind /usr /usr --ro-bind /lib /lib --ro-bind /lib64 /lib64 \
  -- /usr/bin/true && echo ok
```

If it prints `ok` without a `setting up uid map` error, bubblewrap is usable.

## Profiles

Every subagent role is mapped through one audited code path in
`litehive/agents/sandbox.py`:

- `merge-resolver` -> `merge-resolver`
- every other role, including unknown roles -> `no-git`

The default is fail-closed. If Litehive does not recognize a role, it gets the
same no-git sandbox as `planner`, `swe`, `qa`, `reviewer`, `recovery`, and
other non-merge-resolver stages.

## No-Git Profile

The no-git profile builds a sandbox filesystem view where `git` is absent from
reachable executable paths. Litehive mirrors the mounted command directories
without the `git` entrypoint, so normal invocation and known absolute paths such
as `/usr/bin/git` fail inside the sandbox.

This policy does not depend on:

- `PATH`
- `LD_PRELOAD`
- `LITEHIVE_*`
- prompt text
- agent-reported role strings inside the sandbox

Even if an agent mutates its environment, there is no visible `git` binary in
the sandbox filesystem view for non-merge-resolver roles.

Litehive also removes the `origin` remote from task worktrees before handing
them to normal execution roles. That is a second layer of protection in case a
sandbox policy is bypassed.

## Merge-Resolver Profile

`merge-resolver` is the only role that receives a visible `git` command. The
profile prepends a single wrapper at `/sandbox/bin/git` and keeps the normal git
entrypoints masked from the sandboxed filesystem view.

The wrapper allows safe commands such as:

- `git --version`
- `git status`
- `git add`
- `git commit`
- normal merge-resolution flows

The wrapper rejects a hardcoded denylist and writes a rejection entry to
`.litehive/runtime/attention.log`.

Denied commands include:

- `git push --force`
- `git push -f`
- `git push --force-with-lease`
- `git push --mirror`
- `git filter-repo`
- `git filter-branch`
- `git reflog expire`
- `git gc --prune=now`
- `git update-ref -d refs/remotes/*`
- `git reset --hard origin/*`
- `git remote set-url origin ...`
- `git rebase` onto protected refs
- `git cherry-pick` onto protected refs

## Tests

Deterministic coverage lives in `tests/test_sandbox_git_profiles.py`.

Those tests spawn a real subprocess through the sandbox launcher. They are
written against the sandbox primitive directly rather than launching an LLM
agent, so they stay fast and deterministic.

On hosts where bubblewrap itself cannot create a sandbox namespace, the direct
integration cases are skipped rather than reporting a false Litehive failure.
The policy code still remains covered by the non-skipped unit tests.

## Manual Breakout Audit

Manual adversarial audits live under `experiments/sandbox-breakout/`.

That directory is intentionally outside the default pytest suite. Use it when
you want to launch a real agent CLI inside the no-git profile and probe for
unexpected escape paths such as alternate CLIs, Python subprocess tricks, or
filesystem discovery behavior that the deterministic tests did not model.
```

```tool
output:
litehive/main.py:26:        ("pipeline", "journal"),
litehive/main.py:27:        ("pipeline", "rules"),
litehive/main.py:117:            stage = task.runtime.current_stage.step or task.pipeline_status or "-"
litehive/main.py:126:            print(f"active_task_status: {task.status}/{task.pipeline_status}")
tests_integration/helpers.py:172:    task.pipeline_status = "implementing"
tests_integration/test_switching.py:18:    interrupted.pipeline_status = "implementing"
tests_integration/test_switching.py:67:    assert "pipeline_status: implementing" in completed.stdout
tests_integration/test_switching.py:75:    assert refreshed.pipeline_status == "implementing"
tests_integration/test_codex.py:31:        f'Run `litehive report --verdict pass --role swe --step implementing --task-id {task.id} '
tests/test_pipeline_v2_worktree_sync.py:5:from litehive.pipeline.nodes.system import GitWorktreeSyncNode
tests/test_pipeline_v2_worktree_sync.py:6:from litehive.pipeline.persistence import TaskState
tests/test_pipeline_v2_worktree_sync.py:7:from litehive.pipeline.types import PipelineMode
tests/test_pipeline_v2_worktree_sync.py:38:        pipeline_mode=PipelineMode.SINGLE,
tests_integration/test_sandbox_mock_engine.py:109:    # our fake script. This mirrors how the real pipeline would call a
tests/test_pipeline_v2_prompt_serializer.py:7:from litehive.pipeline.agents import PlannerAgent, RecoveryAgent, SWEAgent
tests/test_pipeline_v2_prompt_serializer.py:8:from litehive.pipeline.agents.base import PromptContext
tests/test_pipeline_v2_prompt_serializer.py:9:from litehive.pipeline.persistence import LastRejection, TaskState
tests/test_pipeline_v2_prompt_serializer.py:10:from litehive.pipeline.prompt_serializer import serialize_prompt
tests/test_pipeline_v2_prompt_serializer.py:11:from litehive.pipeline.types import PipelineMode
tests/test_pipeline_v2_prompt_serializer.py:40:        pipeline_mode=PipelineMode.FULL,
tests/test_pipeline_v2_prompt_serializer.py:117:    assert "litehive pipeline journal <task_id>" in text
tests/test_pipeline_v2_prompt_serializer.py:139:    agent = PlannerAgent(_NullSelector(), _NullSessions(), prompt_context=PromptContext())
tests/test_pipeline_v2_prompt_serializer.py:154:    assert "litehive agent report --verdict <pass|reject|blocked>" in text
tests/test_pipeline_v2_prompt_serializer.py:183:        {"role": "planner", "step": "grooming", "verdict": "pass", "message": "scope " + ("x" * 600)},
tests/test_pipeline_v2_prompt_serializer.py:193:        f"[grooming] planner (pass): {'scope ' + ('x' * 494)}…(truncated)"
tests/test_pipeline_v2_prompt_serializer.py:208:        "pipeline_mode": PipelineMode.FULL.value,
tests/test_pipeline_v2_prompt_serializer.py:216:            {"role": "planner", "step": "grooming", "verdict": "pass", "message": "scope"},
tests/test_pipeline_v2_prompt_serializer.py:217:            {"role": "reviewer", "step": "accepting", "verdict": "reject", "message": "same reason"},
tests/test_pipeline_v2_prompt_serializer.py:224:        "[grooming] planner (pass): scope",
tests/test_pipeline_v2_prompt_serializer.py:225:        "[accepting] reviewer (reject): same reason",
tests/test_pipeline_v2_prompt_serializer.py:235:        "pipeline_mode": PipelineMode.FULL.value,
tests/test_pipeline_v2_prompt_serializer.py:238:            {"role": "planner", "step": "grooming", "verdict": "pass", "message": "scope"},
tests/test_pipeline_v2_prompt_serializer.py:257:        "role": "reviewer",
tests/test_pipeline_v2_prompt_serializer.py:258:        "pipeline_mode": PipelineMode.FULL.value,
tests/test_pipeline_v2_prompt_serializer.py:261:            {"role": "planner", "step": "grooming", "verdict": "pass", "message": "scope"},
litehive/config/constants.py:6:    {"all", "planner", "swe", "qa", "reviewer", "recovery"}
tests/test_pipeline_v2_hook_config_wiring.py:5:from litehive.pipeline.nodes import HookSpec
tests/test_pipeline_v2_hook_config_wiring.py:6:from litehive.pipeline.orchestration import hook_specs_from_config
litehive/workspace/task_status.py:63:        if task.pipeline_status == "done":
litehive/workspace/task_status.py:65:        stage = task.runtime.current_stage.step or task.pipeline_status
litehive/workspace/task_status.py:78:        if task.status == "queued" and task.pipeline_status != "done":
litehive/workspace/task_status.py:184:        f"resume_from: {task.pipeline_status}",
litehive/workspace/task_status.py:207:    if task.pipeline_status == "done":
litehive/workspace/task_status.py:209:    if task.pipeline_status == "backlog":
litehive/workspace/task_status.py:228:        step=task.pipeline_status,
litehive/workspace/task_status.py:253:            step=task.pipeline_status,
litehive/workspace/task_status.py:341:            pipeline_status=implementation_entry_stage(task),
litehive/workspace/task_status.py:371:        if task.pipeline_status in {"backlog", "done"}:
litehive/workspace/task_status.py:373:        resumed_stage = task.pipeline_status
litehive/workspace/task_status.py:381:            pipeline_status=resumed_stage,
litehive/workspace/task_status.py:417:        task.runtime.last_outcome.stage = task.pipeline_status
litehive/workspace/task_status.py:431:            journal_message=f"Task abandoned via CLI at stage `{task.pipeline_status}`.",
litehive/workspace/task_status.py:490:        task.runtime.last_outcome.stage = task.pipeline_status
litehive/workspace/task_status.py:544:            journal_message=f"Task parked via CLI at stage `{task.pipeline_status}`.",
litehive/workspace/task_status.py:610:            task.pipeline_status = "done"
litehive/workspace/task_status.py:616:            task.runtime.last_outcome.stage = task.pipeline_status
litehive/workspace/task_status.py:656:                    journal_message=f"Task parked via structured report at stage `{task.pipeline_status}`.",
litehive/workspace/task_status.py:665:                    pipeline_status=implementation_entry_stage(task),
litehive/workspace/task_status.py:687:                task.runtime.last_outcome.stage = task.pipeline_status
litehive/workspace/task_status.py:701:                    journal_message=f"Task abandoned via structured report at stage `{task.pipeline_status}`.",
litehive/workspace/task_status.py:765:        task.pipeline_status = reroute_stage_for_acceptance_criteria(task)
litehive/workspace/task_status.py:770:            task.pipeline_status == "grooming"
tests/test_pipeline_v2_agent_retries.py:9:from litehive.pipeline.events import Crash, Pass
tests/test_pipeline_v2_agent_retries.py:10:from litehive.pipeline.nodes.agent import (
tests/test_pipeline_v2_agent_retries.py:17:from litehive.pipeline.persistence import TaskState
tests/test_pipeline_v2_agent_retries.py:18:from litehive.pipeline.sessions import InMemorySessionStore
tests/test_pipeline_v2_agent_retries.py:19:from litehive.pipeline.types import PipelineMode
tests/test_pipeline_v2_agent_retries.py:64:        pipeline_mode=overrides.get("pipeline_mode", PipelineMode.FULL),
tests/test_debug_command.py:264:            id="SA-grooming", role="planner", engine="gemini",
tests/test_debug_command.py:281:        (sa_path_1, "SA-grooming", "planner", "gemini", 0),
tests/test_debug_command.py:297:    assert "role=planner" in output
tests/test_main.py:53:        ["litehive", "pipeline", "journal", "T-0001"],
tests/test_main.py:59:    assert captured["argv"] == ["litehive", "pipeline", "journal", "T-0001"]
tests/test_main.py:70:        ["litehive", "pipeline", "journal", "T-0001"],
tests/test_pipeline_v2_last_report.py:10:from litehive.pipeline.events import Pass
tests/test_pipeline_v2_last_report.py:11:from litehive.pipeline.nodes.agent import AgentNode, AgentVerdict
tests/test_pipeline_v2_last_report.py:12:from litehive.pipeline.persistence import TaskState
tests/test_pipeline_v2_last_report.py:13:from litehive.pipeline.runner import StateMachineRunner
tests/test_pipeline_v2_last_report.py:14:from litehive.pipeline.sessions import InMemorySessionStore
tests/test_pipeline_v2_last_report.py:15:from litehive.pipeline.types import PipelineMode
tests/test_pipeline_v2_last_report.py:50:        TaskState(task_id="T-0001", stage="implementing", pipeline_mode=PipelineMode.FULL)
tests/test_pipeline_v2_last_report.py:59:    state = TaskState(task_id="T-0001", stage="implementing", pipeline_mode=PipelineMode.FULL)
litehive/workspace/worktree_inspection.py:206:    if task.pipeline_status in {"backlog", "done"}:
litehive/config/profiles/_shared.yaml:13:role_model: "orchestrator-as-manager: `planner` owns grooming, `reviewer` owns acceptance, both are PM-style product roles, `swe` implements, and `qa` verifies."
litehive/config/profiles/_shared.yaml:41:    - "Act as the planner: clarify the user problem, inspect the repo if needed, and produce a concrete execution plan."
litehive/config/profiles/_shared.yaml:61:    - "Act as the reviewer: validate the end-user outcome against the acceptance criteria and decide whether it should be accepted or sent back."
tests/test_pipeline_hook_reject_circuit_breaker.py:6:from litehive.pipeline import SqliteJournal, StateMachineRunner, build_registry
tests/test_pipeline_hook_reject_circuit_breaker.py:7:from litehive.pipeline.agents.base import PromptContext
tests/test_pipeline_hook_reject_circuit_breaker.py:8:from litehive.pipeline.nodes import HookResult, HookRunner, HookSpec, StubCommitNode
tests/test_pipeline_hook_reject_circuit_breaker.py:9:from litehive.pipeline.nodes.agent import AgentVerdict
tests/test_pipeline_hook_reject_circuit_breaker.py:10:from litehive.pipeline.orchestration import _sync_back
tests/test_pipeline_hook_reject_circuit_breaker.py:11:from litehive.pipeline.persistence import SqlitePersistence
tests/test_pipeline_hook_reject_circuit_breaker.py:12:from litehive.pipeline.sessions import InMemorySessionStore
tests/test_pipeline_hook_reject_circuit_breaker.py:13:from litehive.pipeline.types import PipelineMode
tests/test_pipeline_hook_reject_circuit_breaker.py:89:    task = create_task(workspace, title="Trip breaker then recover", pipeline_mode="single")
tests/test_pipeline_hook_reject_circuit_breaker.py:96:    persistence.initialize(task.id, pipeline_mode=PipelineMode.SINGLE)
tests/test_pipeline_hook_reject_circuit_breaker.py:110:    task = create_task(workspace, title="Trip breaker and stay flagged", pipeline_mode="single")
tests/test_pipeline_hook_reject_circuit_breaker.py:111:    other = create_task(workspace, title="Healthy queued task", pipeline_mode="single")
tests/test_pipeline_hook_reject_circuit_breaker.py:118:    persistence.initialize(task.id, pipeline_mode=PipelineMode.SINGLE)
tests/test_pipeline_hook_reject_circuit_breaker.py:141:    task = create_task(workspace, title="Hook eventually passes", pipeline_mode="single")
tests/test_pipeline_hook_reject_circuit_breaker.py:148:    persistence.initialize(task.id, pipeline_mode=PipelineMode.SINGLE)
tests/test_engine_variants_and_timeline.py:305:@pytest.mark.skip(reason="v2 pipeline passes max_turns via engine config, not SubagentManager.run kwarg")
tests/test_engine_variants_and_timeline.py:315:        return _completed_subagent_result(tmp_path, task.pipeline_status, engine_name="claude", task=task)
tests/test_engine_variants_and_timeline.py:1008:@pytest.mark.skip(reason="v1 TaskExecutionRunner deleted; test needs rewrite for v2 pipeline")
tests/test_engine_variants_and_timeline.py:1048:    task.pipeline_status = "implementing"
litehive/config/profiles/python.yaml:3:role_model: "`planner` frames the task, `reviewer` performs final PM-style acceptance, `swe` edits code, and `qa` runs focused verification."
litehive/config/profiles/django.yaml:3:role_model: "`planner` frames the task, `reviewer` performs final PM-style acceptance, `swe` updates apps/views/models, and `qa` verifies user-visible behavior."
litehive/workspace/runtime_tracking.py:86:            and task.pipeline_status != "done"
litehive/workspace/runtime_tracking.py:93:            and task.pipeline_status == "done"
litehive/models/task_models.py:9:    PipelineMode,
litehive/models/task_models.py:10:    PipelineStatus,
litehive/models/task_models.py:93:    pipeline_mode: PipelineMode = "full"
litehive/models/task_models.py:114:    pipeline_status: PipelineStatus = "backlog"
litehive/models/task_models.py:130:    pipeline_mode: PipelineMode = "full"
litehive/models/task_models.py:134:    pipeline_status: PipelineStatus = "backlog"
litehive/models/task_models.py:161:            pipeline_mode=self.pipeline_mode,
litehive/models/task_models.py:186:            pipeline_status=self.pipeline_status,
litehive/models/task_models.py:214:        record.pipeline_status = state.pipeline_status
litehive/config/profiles/codehive.yaml:7:role_model: "`planner` owns task shaping, `reviewer` owns final PM-style acceptance, `swe` implements, and `qa` verifies, all through deterministic stage handoffs."
litehive/config/profiles/codehive.yaml:28:    - "- Planner output should sharpen user value, scope edges, decomposition, and follow-up work."
litehive/config/profiles/codehive.yaml:34:    - "- Reviewer acceptance is managerial PM-style review against task goals, tests, and recovery policy, not a rubber stamp."
litehive/config/profiles/codehive.yaml:35:    - "- Reviewer judgment should focus on end-user outcome, regressions, and whether the task is actually done."
tests/test_workspace_bootstrap.py:370:    task.pipeline_status = "implementing"
tests/test_workspace_bootstrap.py:387:        "pipeline_mode",
tests/test_workspace_bootstrap.py:410:    assert loaded.pipeline_status == "implementing"
tests/test_workspace_bootstrap.py:428:                "pipeline_mode": "full",
tests/test_workspace_bootstrap.py:431:                "pipeline_status": "testing",
tests/test_workspace_bootstrap.py:461:    assert loaded.pipeline_status == "testing"
tests/test_workspace_bootstrap.py:470:    assert "pipeline_status" not in sanitized
tests/test_workspace_bootstrap.py:948:    assert config.external_engine_sandbox.enabled is True
tests/test_workspace_bootstrap.py:1003:    assert profile["role_model"].startswith("`planner` owns task shaping")
tests/test_workspace_bootstrap.py:1006:        "- Reviewer acceptance is managerial"
litehive/models/runtime_models.py:98:    pipeline_status: str | None = None
tests/test_pipeline_v2_task_updates.py:4:handle: (1) a structured YAML block the planner embeds in its message,
tests/test_pipeline_v2_task_updates.py:12:from litehive.pipeline.task_updates import (
tests/test_pipeline_v2_journal_cli.py:1:"""Tests for the `litehive pipeline journal` CLI command.
tests/test_pipeline_v2_journal_cli.py:13:from litehive.pipeline.deltas import StateDelta
tests/test_pipeline_v2_journal_cli.py:14:from litehive.pipeline.events import CleanState, Reject
tests/test_pipeline_v2_journal_cli.py:15:from litehive.pipeline.journal import SqliteJournal
tests/test_pipeline_v2_journal_cli.py:16:from litehive.pipeline.persistence import SqlitePersistence
tests/test_pipeline_v2_journal_cli.py:17:from litehive.pipeline.types import PipelineMode
tests/test_pipeline_v2_journal_cli.py:30:    state = store.initialize(task_id, pipeline_mode=PipelineMode.FULL)
tests/test_pipeline_v2_journal_cli.py:56:def test_pipeline_journal_prints_state_and_transitions(workspace: Path) -> None:
tests/test_pipeline_v2_journal_cli.py:60:        app, ["pipeline", "journal", "T-0099", "--workspace", str(workspace)]
tests/test_pipeline_v2_journal_cli.py:73:def test_pipeline_journal_unknown_task_returns_error(workspace: Path) -> None:
tests/test_pipeline_v2_journal_cli.py:75:        app, ["pipeline", "journal", "T-9999", "--workspace", str(workspace)]
litehive/models/__init__.py:14:    PipelineMode,
litehive/models/__init__.py:15:    PipelineStatus,
litehive/models/__init__.py:97:    "PipelineMode",
litehive/models/__init__.py:98:    "PipelineStatus",
tests/test_task_comments.py:26:                    "role": "planner",
tests/test_task_comments.py:114:                    "role": "planner",
tests/test_pipeline_v2_transitions.py:1:"""Invariant + happy-path tests for the pipeline v2 state machine.
tests/test_pipeline_v2_transitions.py:10:from litehive.pipeline import RULES, evaluate, list_transitions
tests/test_pipeline_v2_transitions.py:11:from litehive.pipeline.events import (
tests/test_pipeline_v2_transitions.py:25:from litehive.pipeline.persistence import LastReport, Limits, TaskState
tests/test_pipeline_v2_transitions.py:26:from litehive.pipeline.transitions import NoTransitionError
tests/test_pipeline_v2_transitions.py:27:from litehive.pipeline.types import (
tests/test_pipeline_v2_transitions.py:31:    PipelineMode,
tests/test_pipeline_v2_transitions.py:38:    mode: PipelineMode = PipelineMode.FULL,
tests/test_pipeline_v2_transitions.py:50:        pipeline_mode=mode,
tests/test_pipeline_v2_transitions.py:90:    state = make_state(stage, mode=PipelineMode.FULL)
tests/test_pipeline_v2_transitions.py:95:    state = make_state("ready", mode=PipelineMode.SINGLE)
tests/test_pipeline_v2_transitions.py:99:    sync_state = make_state("worktree_sync", mode=PipelineMode.SINGLE)
tests/test_pipeline_v2_transitions.py:104:    state = make_state("after_implementing", mode=PipelineMode.SINGLE, files_changed=5)
tests/test_pipeline_v2_transitions.py:111:        mode=PipelineMode.SINGLE,
tests/test_pipeline_v2_transitions.py:121:        mode=PipelineMode.FULL,
litehive/config/profiles/cpp.yaml:3:role_model: "`planner` scopes the change, `reviewer` performs final PM-style acceptance, `swe` edits native code, and `qa` verifies compile and runtime behavior."
litehive/models/common.py:8:for backward compatibility and keeps litehive-only types (PipelineMode,
litehive/models/common.py:9:TaskStatus, PipelineStatus, etc.) authoritative here.
litehive/models/common.py:36:PipelineMode = Literal["single", "full"]
litehive/models/common.py:50:PipelineStatus = Literal[
litehive/models/common.py:80:    "PipelineMode",
litehive/models/common.py:81:    "PipelineStatus",
litehive/config/profiles/rust.yaml:3:role_model: "`planner` scopes the task, `reviewer` performs final PM-style acceptance, `swe` edits crates/modules, and `qa` verifies compile and test results."
tests/test_attention_queue.py:83:                "pipeline_mode": "full",
tests/test_attention_queue.py:92:    flagged.pipeline_status = "implementing"
tests/test_attention_queue.py:98:    merge_failed.pipeline_status = "merge_failed"
tests/test_attention_queue.py:103:    stale.pipeline_status = "done"
tests/test_attention_queue.py:135:    flagged.pipeline_status = "backlog"
tests/test_attention_queue.py:139:    merge_failed.pipeline_status = "done"
tests/test_attention_queue.py:162:                "pipeline_mode": "full",
tests/test_attention_queue.py:188:                "pipeline_mode": "full",
tests/test_archive.py:39:    task.pipeline_status = "done"
tests/test_engine_freeze.py:124:    task = TaskRecord(id="T-0001", slug="test", title="test", status="queued", pipeline_status="implementing")
tests/test_engine_freeze.py:141:    task = TaskRecord(id="T-0001", slug="test", title="test", status="queued", pipeline_status="implementing")
tests/test_engine_freeze.py:222:    task = TaskRecord(id="T-0001", slug="test", title="test", status="queued", pipeline_status="implementing")
tests/test_engine_freeze.py:241:    task = TaskRecord(id="T-0001", slug="test", title="test", status="queued", pipeline_status="implementing")
tests/test_engine_freeze.py:273:    task = TaskRecord(id="T-0001", slug="test", title="test", status="queued", pipeline_status="implementing")
tests/test_engine_freeze.py:305:    task = TaskRecord(id="T-0001", slug="test", title="test", status="queued", pipeline_status="implementing")
tests/test_engine_freeze.py:339:    task = TaskRecord(id="T-0001", slug="test", title="test", status="queued", pipeline_status="implementing")
tests/test_pipeline_public_api.py:3:import litehive.pipeline as pipeline
tests/test_pipeline_public_api.py:6:def test_pipeline_package_exports_required_public_names():
tests/test_pipeline_public_api.py:19:    assert required.issubset(set(pipeline.__all__))
tests/test_pipeline_public_api.py:21:        assert hasattr(pipeline, name)
tests/test_pipeline_public_api.py:24:def test_pipeline_package_surface_stays_thin_and_public():
tests/test_pipeline_public_api.py:25:    init_path = Path(__file__).resolve().parents[1] / "litehive" / "pipeline" / "__init__.py"
tests/test_pipeline_public_api.py:28:    assert all(not name.startswith("_") for name in pipeline.__all__)
tests/test_pipeline_v2_heru_factory.py:6:from litehive.pipeline.heru_factory import HeruEngineAdapter, _latest_verdict_after
tests/test_pipeline_v2_heru_factory.py:7:from litehive.pipeline.nodes.agent import AgentVerdict
tests/test_pipeline_v2_heru_factory.py:8:from litehive.pipeline.persistence import TaskState
tests/test_pipeline_v2_heru_factory.py:9:from litehive.pipeline.sessions import Session
tests/test_pipeline_v2_heru_factory.py:10:from litehive.pipeline.types import PipelineMode
tests/test_pipeline_v2_heru_factory.py:47:    state = TaskState(task_id=task.id, stage="implementing", pipeline_mode=PipelineMode.FULL)
tests/test_pipeline_v2_heru_factory.py:50:    monkeypatch.setattr("litehive.pipeline.heru_factory.SubagentManager", _StubManager)
tests/test_pipeline_v2_heru_factory.py:52:        "litehive.pipeline.heru_factory._latest_verdict_after",
tests/test_pipeline_v2_heru_factory.py:62:            "pipeline_mode": "full",
tests/test_pipeline_v2_heru_factory.py:83:    state = TaskState(task_id=task.id, stage="implementing", pipeline_mode=PipelineMode.FULL)
tests/test_pipeline_v2_heru_factory.py:86:    monkeypatch.setattr("litehive.pipeline.heru_factory.SubagentManager", _StubManager)
tests/test_pipeline_v2_heru_factory.py:88:        "litehive.pipeline.heru_factory._latest_verdict_after",
tests/test_pipeline_v2_heru_factory.py:98:            "pipeline_mode": "full",
tests/test_pipeline_v2_heru_factory.py:122:        "litehive.pipeline.heru_factory._execution_checkout_has_changes",
tests/test_pipeline_v2_heru_factory.py:153:        "litehive.pipeline.heru_factory._execution_checkout_has_changes",
tests/test_list_and_show.py:27:    done.pipeline_status = "done"
tests/test_list_and_show.py:32:        filter_status=None, filter_pipeline_status=None, filter_engine=None,
tests/test_list_and_show.py:49:    done.pipeline_status = "done"
tests/test_list_and_show.py:54:        filter_status=None, filter_pipeline_status=None, filter_engine=None,
tests/test_list_and_show.py:75:        filter_status="interrupted", filter_pipeline_status=None, filter_engine=None,
tests/test_list_and_show.py:85:def test_list_filter_by_pipeline_status(
tests/test_list_and_show.py:91:    implementing.pipeline_status = "implementing"
tests/test_list_and_show.py:96:        filter_status=None, filter_pipeline_status="implementing", filter_engine=None,
tests/test_list_and_show.py:115:        filter_status=None, filter_pipeline_status=None, filter_engine="gemini",
tests/test_list_and_show.py:138:        filter_status="queued", filter_pipeline_status=None, filter_engine="codex",
tests/test_list_and_show.py:153:    """Each task prints as one line: ID [status/pipeline_status] title."""
tests/test_list_and_show.py:159:        filter_status=None, filter_pipeline_status=None, filter_engine=None,
tests/test_list_and_show.py:186:    assert "pipeline_status: backlog" in output
tests/test_list_and_show.py:272:    archived.pipeline_status = "done"
litehive/config/pipeline_states.py:1:"""Explicit state machine for the task pipeline.
litehive/config/pipeline_states.py:3:Pipeline stages flow in a fixed order:
litehive/config/pipeline_states.py:11:``_STEPS_FROM`` maps a task's ``pipeline_status`` to the stage that should execute next.
litehive/config/pipeline_states.py:17:class PipelineState(str, Enum):
litehive/config/pipeline_states.py:18:    """All valid pipeline states for a task.
litehive/config/pipeline_states.py:22:    * **Runnable stages** – the task is actively progressing through the pipeline.
litehive/config/pipeline_states.py:24:    * **Terminal states** – the pipeline has ended.  ``done`` means success;
litehive/config/pipeline_states.py:30:    # ── Runnable pipeline stages ─────────────────────────────────────────────
litehive/config/pipeline_states.py:62:# Maps pipeline_status -> which stage executor to invoke.
litehive/config/pipeline_states.py:108:# Single-mode pipeline: backlog ──► implementing ──► commit_to_git ──► done
tests/test_pipeline_v2_pre_exec_probe.py:3:from litehive.pipeline.events import (
tests/test_pipeline_v2_pre_exec_probe.py:9:from litehive.pipeline.nodes.system import PreExecRecoveryNode, ReadyNode
tests/test_pipeline_v2_pre_exec_probe.py:10:from litehive.pipeline.persistence import TaskState
tests/test_pipeline_v2_pre_exec_probe.py:11:from litehive.pipeline.types import PipelineMode
tests/test_pipeline_v2_pre_exec_probe.py:18:        pipeline_mode=PipelineMode.FULL,
tests/test_pipeline_v2_bootstrap.py:19:from litehive.pipeline.nodes.agent import AgentVerdict, EngineBlockedError
tests/test_pipeline_v2_bootstrap.py:20:from litehive.pipeline.orchestration import run_task
tests/test_pipeline_v2_bootstrap.py:90:        pipeline_mode="single",
tests/test_pipeline_v2_bootstrap.py:120:        pipeline_mode="full",
tests/test_pipeline_v2_bootstrap.py:144:        pipeline_mode="single",
tests/test_db_migrations.py:20:        "0002_pipeline_journal.sql",
tests/test_db_migrations.py:21:        "0003_pipeline_task_state.sql",
tests/test_db_migrations.py:27:    assert "CREATE TABLE IF NOT EXISTS pipeline_transitions" in migrations[1].sql
tests/test_db_migrations.py:28:    assert "CREATE TABLE IF NOT EXISTS pipeline_task_state" in migrations[2].sql
tests/test_recovery_runtime.py:26:    task.pipeline_status = "implementing"
tests/test_recovery_runtime.py:43:    assert refreshed.pipeline_status == "implementing"
tests/test_recovery_runtime.py:57:    task.pipeline_status = "commit_to_git"
tests/test_recovery_runtime.py:74:    assert refreshed.pipeline_status == "commit_to_git"
tests/test_recovery_runtime.py:85:    task.pipeline_status = "implementing"
tests/test_recovery_runtime.py:117:    task.pipeline_status = "implementing"
tests/test_pipeline_v2_diagram.py:3:from litehive.pipeline.diagram import render_markdown, render_mermaid_diagram
tests/test_pipeline_v2_diagram.py:4:from litehive.pipeline.rules import RULES
tests/test_pipeline_v2_diagram.py:5:from litehive.pipeline.types import STAGES, TERMINAL_NODES
litehive/pipeline/diagram.py:1:"""Mermaid diagram generator for the pipeline state machine.
litehive/pipeline/diagram.py:8:add a ``litehive pipeline graph`` command, it can call
tests/test_pipeline_v2_hooks_and_commit.py:8:from litehive.pipeline.events import HookOk, MergeConflictDetected, Pass, Reject
tests/test_pipeline_v2_hooks_and_commit.py:9:from litehive.pipeline.nodes import (
tests/test_pipeline_v2_hooks_and_commit.py:16:from litehive.pipeline.persistence import TaskState
tests/test_pipeline_v2_hooks_and_commit.py:17:from litehive.pipeline.types import PipelineMode
tests/test_pipeline_v2_hooks_and_commit.py:21:    return TaskState(task_id=task_id, stage=stage, pipeline_mode=PipelineMode.FULL)
litehive/db/migrations/0003_pipeline_task_state.sql:1:-- v2 pipeline task state. One row per task. The ``payload`` blob carries
litehive/db/migrations/0003_pipeline_task_state.sql:4:CREATE TABLE IF NOT EXISTS pipeline_task_state (
litehive/db/migrations/0003_pipeline_task_state.sql:7:    pipeline_mode TEXT NOT NULL,
litehive/db/migrations/0003_pipeline_task_state.sql:12:CREATE INDEX IF NOT EXISTS idx_pipeline_task_state_stage
litehive/db/migrations/0003_pipeline_task_state.sql:13:    ON pipeline_task_state (stage);
litehive/db/migrations/0003_pipeline_task_state.sql:18:CREATE TABLE IF NOT EXISTS pipeline_sessions (
litehive/pipeline/prompt_serializer.py:120:        f"Pipeline mode: {prompt['pipeline_mode']}",
litehive/pipeline/prompt_serializer.py:364:        "  litehive agent report --verdict <pass|reject|blocked> --message-file /tmp/verdict_msg.txt\n\n"
tests/test_flag_count_auto_defer.py:23:    task.pipeline_status = "implementing"
tests/test_flag_count_auto_defer.py:86:        t.pipeline_status = "implementing"
tests/test_flag_count_auto_defer.py:105:    t.pipeline_status = "implementing"
tests/test_flag_count_auto_defer.py:143:    t.pipeline_status = "implementing"
tests/test_flag_count_auto_defer.py:164:    t.pipeline_status = "implementing"
litehive/config/engine_models.py:388:        "grooming": "planner",
litehive/config/engine_models.py:391:        "accepting": "reviewer",
litehive/db/migrations/0002_pipeline_journal.sql:2:CREATE TABLE IF NOT EXISTS pipeline_transitions (
litehive/db/migrations/0002_pipeline_journal.sql:15:CREATE INDEX IF NOT EXISTS idx_pipeline_transitions_task_seq
litehive/db/migrations/0002_pipeline_journal.sql:16:    ON pipeline_transitions (task_id, seq);
litehive/db/migrations/0002_pipeline_journal.sql:18:CREATE INDEX IF NOT EXISTS idx_pipeline_transitions_event_type
litehive/db/migrations/0002_pipeline_journal.sql:19:    ON pipeline_transitions (event_type);
litehive/db/migrations/0002_pipeline_journal.sql:23:CREATE TABLE IF NOT EXISTS pipeline_journal (
litehive/db/migrations/0002_pipeline_journal.sql:32:CREATE INDEX IF NOT EXISTS idx_pipeline_journal_task_seq
litehive/db/migrations/0002_pipeline_journal.sql:33:    ON pipeline_journal (task_id, seq);
litehive/db/migrations/0002_pipeline_journal.sql:35:CREATE INDEX IF NOT EXISTS idx_pipeline_journal_task_kind
litehive/db/migrations/0002_pipeline_journal.sql:36:    ON pipeline_journal (task_id, kind);
litehive/pipeline/runner.py:5:from .journal import NullJournal, PipelineJournal
litehive/pipeline/runner.py:19:    Holds the rule list, the node registry, and a ``PipelineJournal``. On
litehive/pipeline/runner.py:38:        journal: PipelineJournal | None = None,
litehive/pipeline/runner.py:115:        if _pipeline_stage_for_phase(from_stage) == _pipeline_stage_for_phase(to_stage):
litehive/pipeline/runner.py:158:def _pipeline_stage_for_phase(phase: str) -> str:
tests/test_pipeline_v2_end_to_end.py:1:"""End-to-end test for the v2 pipeline state machine.
tests/test_pipeline_v2_end_to_end.py:16:  - the pipeline_transitions table has one row per hop
tests/test_pipeline_v2_end_to_end.py:25:import litehive.pipeline.orchestration as orchestration
tests/test_pipeline_v2_end_to_end.py:26:from litehive.pipeline import SqliteJournal, StateMachineRunner, build_registry
tests/test_pipeline_v2_end_to_end.py:27:from litehive.pipeline.agents.base import PromptContext
tests/test_pipeline_v2_end_to_end.py:28:from litehive.pipeline.nodes import CommitNode, HookResult, HookRunner, StubCommitNode
tests/test_pipeline_v2_end_to_end.py:29:from litehive.pipeline.nodes.agent import AgentVerdict, Engine, TransientError
tests/test_pipeline_v2_end_to_end.py:30:from litehive.pipeline.nodes.system import MergeConflict
tests/test_pipeline_v2_end_to_end.py:31:from litehive.pipeline.persistence import SqlitePersistence
tests/test_pipeline_v2_end_to_end.py:32:from litehive.pipeline.sessions import InMemorySessionStore
tests/test_pipeline_v2_end_to_end.py:33:from litehive.pipeline.types import PipelineMode
tests/test_pipeline_v2_end_to_end.py:111:    persistence.initialize("T-E2E-001", pipeline_mode=PipelineMode.FULL)
tests/test_pipeline_v2_end_to_end.py:157:    persistence.initialize("T-E2E-SINGLE-NOOP", pipeline_mode=PipelineMode.SINGLE)
tests/test_pipeline_v2_end_to_end.py:187:    state = persistence.initialize("T-E2E-SINGLE-DIFF", pipeline_mode=PipelineMode.SINGLE)
tests/test_pipeline_v2_end_to_end.py:213:    persistence.initialize("T-E2E-RESUME", pipeline_mode=PipelineMode.FULL)
tests/test_pipeline_v2_end_to_end.py:219:    assert reloaded.pipeline_mode == PipelineMode.FULL
tests/test_pipeline_v2_end_to_end.py:245:    task = create_task(tmp_path, title="Retry once on timeout", pipeline_mode="single")
tests/test_pipeline_v2_end_to_end.py:369:    task = create_task(tmp_path, title="Already landed reconcile", pipeline_mode="single")
tests/test_pipeline_v2_end_to_end.py:371:    state = persistence.initialize(task.id, pipeline_mode=PipelineMode.SINGLE)
tests/test_pipeline_v2_end_to_end.py:383:    assert refreshed.pipeline_status == "done"
tests/test_pipeline_v2_end_to_end.py:405:        pipeline_mode="single",
tests/test_pipeline_v2_end_to_end.py:449:    state = persistence.initialize("T-E2E-MERGE", pipeline_mode=PipelineMode.SINGLE)
tests/test_pipeline_v2_end_to_end.py:483:    persistence.initialize("T-E2E-RECOVER", pipeline_mode=PipelineMode.FULL)
litehive/attention.py:369:                        f"Task is paused in `{task.pipeline_status}` and requires operator review."
litehive/attention.py:374:                    metadata={"pipeline_status": task.pipeline_status, "flag_reason": task.flag_reason},
litehive/attention.py:386:                    metadata={"pipeline_status": task.pipeline_status},
tests/workspace_helpers.py:83:from litehive.pipeline.orchestration import run_task, ExecutionResult
tests/workspace_helpers.py:266:    if getattr(args, "filter_pipeline_status", None) is not None:
tests/workspace_helpers.py:267:        argv.extend(["--pipeline-status", args.filter_pipeline_status])
tests/workspace_helpers.py:649:        report_role = "planner" if effective_step == "grooming" else "swe"
tests/workspace_helpers.py:849:                active_task.pipeline_status,
tests/test_tasks_and_subagents.py:10:from litehive.pipeline.heru_factory import HeruEngineAdapter
tests/test_tasks_and_subagents.py:101:    task.pipeline_status = "testing"
tests/test_tasks_and_subagents.py:115:    assert refreshed.pipeline_status == "backlog"
tests/test_tasks_and_subagents.py:128:    active.pipeline_status = "done"
tests/test_tasks_and_subagents.py:360:    assert "You are the planner for a local multi-agent coding workspace." in prompt
tests/test_tasks_and_subagents.py:403:                stdout="TITLE: Capture queue visibility gaps\nGOAL: Turn the raw notes into a queued task planner can groom later.\n",
tests/test_tasks_and_subagents.py:431:        "Turn the raw notes into a queued task planner can groom later.\n\n"
tests/test_tasks_and_subagents.py:437:    assert task.pipeline_status == "backlog"
tests/test_tasks_and_subagents.py:781:                            "role": "planner",
tests/test_tasks_and_subagents.py:807:    manager.run(task, role="planner", engine_name="codex", prompt="groom it")
tests/test_tasks_and_subagents.py:809:    base = task_dir(tmp_path, task) / "subagents" / "SA-0001-planner"
litehive/tasks/archive.py:78:        if task.status == "done" and task.pipeline_status == "done":
litehive/tasks/reports.py:73:            summary=f"status={task.status} pipeline_status={task.pipeline_status} priority={task.priority}",
litehive/tasks/reports.py:256:            step=stage or task.pipeline_status,
litehive/tasks/templates.py:189:            "Prepare the task for planner grooming.",
litehive/tasks/templates.py:192:            "Keep the scope high-level; the planner will handle decomposition later.",
litehive/tasks/queue_management.py:79:    pipeline_status: str,
litehive/tasks/queue_management.py:85:    task.pipeline_status = pipeline_status
litehive/tasks/queue_management.py:111:        task.runtime.last_outcome.stage = pipeline_status
litehive/tasks/queue_management.py:123:        pipeline_status=recovery_stage,
litehive/tasks/normalization.py:96:    if getattr(task, "pipeline_mode", "full") == "single":
litehive/tasks/normalization.py:104:    """Return a reason if the task is underspecified and needs planner normalization before retry.
litehive/tasks/normalization.py:106:    Tasks already at backlog or grooming will naturally go through planner,
litehive/tasks/normalization.py:112:    if getattr(task, "pipeline_mode", "full") == "single":
litehive/tasks/normalization.py:114:    if task.pipeline_status in {"backlog", "grooming"}:
litehive/tasks/normalization.py:121:    return f"Task is underspecified ({', '.join(reasons)}) and needs planner normalization before retry."
litehive/tasks/normalization.py:125:    if getattr(task, "pipeline_mode", "full") == "single":
litehive/tasks/normalization.py:126:        return task.pipeline_status
litehive/tasks/normalization.py:127:    if task.pipeline_status in {"implementing", "testing", "accepting", "commit_to_git"}:
litehive/tasks/normalization.py:130:        return task.pipeline_status
litehive/tasks/normalization.py:131:    return task.pipeline_status
litehive/tasks/crud.py:219:            "pipeline_status",
litehive/tasks/crud.py:251:    pipeline_mode: str = "full",
litehive/tasks/crud.py:268:    if pipeline_mode not in {"single", "full"}:
litehive/tasks/crud.py:269:        raise ValueError(f"Unsupported pipeline_mode '{pipeline_mode}'")
litehive/tasks/crud.py:295:            pipeline_mode=pipeline_mode,  # type: ignore[arg-type]
litehive/cli/runner.py:25:from litehive.pipeline.orchestration import run_task
litehive/cli/runner.py:242:    print(f"pipeline_status: {summary.task.pipeline_status}")
litehive/cli/runner.py:280:    step = step or task.pipeline_status
litehive/pipeline/heru_factory.py:181:        # If this was a grooming verdict, the planner may have embedded a
litehive/pipeline/compat.py:1:"""Compatibility helpers for the legacy package-level pipeline surface."""
litehive/cli/task_cli.py:80:    mode: Annotated[str | None, typer.Option(click_type=choice(["full", "single"]), help="Task pipeline mode")] = None,
litehive/cli/task_cli.py:91:        pipeline_mode = mode or "full"
litehive/cli/task_cli.py:97:            pipeline_mode=pipeline_mode,
litehive/cli/task_cli.py:111:    print(f"pipeline_mode: {task.pipeline_mode}")
litehive/cli/task_cli.py:177:    filter_pipeline_status: Annotated[
litehive/cli/task_cli.py:178:        str | None, typer.Option("--pipeline-status", help="Filter by pipeline stage")
litehive/cli/task_cli.py:191:        if filter_pipeline_status and task.pipeline_status != filter_pipeline_status:
litehive/cli/task_cli.py:198:        print(f"{task.id} [{task.status}/{task.pipeline_status}] {task.title}{flag_reason}")
litehive/cli/task_cli.py:215:    print(f"pipeline_status: {task.pipeline_status}")
litehive/cli/task_cli.py:221:    print(f"pipeline_mode: {task.pipeline_mode}")
litehive/cli/task_cli.py:268:    print(f"pipeline_status: {task.pipeline_status}")
litehive/cli/task_cli.py:302:    print(f"pipeline_status: {task.pipeline_status}")
litehive/pipeline/__init__.py:7:from .journal import InMemoryJournal, NullJournal, PipelineJournal, SqliteJournal
litehive/pipeline/__init__.py:18:    "build_registry", "PipelineJournal", "SqliteJournal", "InMemoryJournal",
litehive/pipeline/nodes/agent.py:196:                "`litehive report --verdict <pass|reject|blocked>`. Please "
tests/test_pipeline_v2_sqlite_adapters.py:1:"""Round-trip tests for v2 pipeline sqlite adapters.
tests/test_pipeline_v2_sqlite_adapters.py:12:from litehive.pipeline.persistence import (
tests/test_pipeline_v2_sqlite_adapters.py:21:from litehive.pipeline.sessions import Session, SqliteSessionStore
tests/test_pipeline_v2_sqlite_adapters.py:22:from litehive.pipeline.types import PipelineMode
tests/test_pipeline_v2_sqlite_adapters.py:44:    first = store.initialize("T-0001", pipeline_mode=PipelineMode.SINGLE)
tests/test_pipeline_v2_sqlite_adapters.py:45:    second = store.initialize("T-0001", pipeline_mode=PipelineMode.FULL)
tests/test_pipeline_v2_sqlite_adapters.py:48:    assert second.pipeline_mode == PipelineMode.SINGLE
tests/test_pipeline_v2_sqlite_adapters.py:58:        pipeline_mode=PipelineMode.FULL,
tests/test_pipeline_v2_sqlite_adapters.py:88:    assert loaded.pipeline_mode == PipelineMode.FULL
tests/test_pipeline_v2_sqlite_adapters.py:108:    state = TaskState(task_id="T-0100", stage="grooming", pipeline_mode=PipelineMode.FULL)
tests/test_pipeline_v2_sqlite_adapters.py:125:        pipeline_mode=PipelineMode.FULL,
litehive/pipeline/journal.py:1:"""SQLite-backed journal of pipeline runner events.
litehive/pipeline/journal.py:49:class PipelineJournal(ABC):
litehive/pipeline/journal.py:140:class SqliteJournal(PipelineJournal):
litehive/pipeline/journal.py:143:    Transitions land in the structured ``pipeline_transitions`` table so their
litehive/pipeline/journal.py:146:    ``pipeline_journal`` with a free-form payload.
litehive/pipeline/journal.py:179:                INSERT INTO pipeline_transitions (
litehive/pipeline/journal.py:210:                INSERT INTO pipeline_journal (task_id, seq, created_at, kind, payload)
litehive/pipeline/journal.py:222:                    SELECT seq FROM pipeline_transitions WHERE task_id = ?
litehive/pipeline/journal.py:224:                    SELECT seq FROM pipeline_journal      WHERE task_id = ?
litehive/pipeline/journal.py:238:                FROM pipeline_transitions
litehive/pipeline/journal.py:263:                FROM pipeline_journal
litehive/pipeline/journal.py:280:class InMemoryJournal(PipelineJournal):
litehive/pipeline/journal.py:306:class NullJournal(PipelineJournal):
litehive/agents/prompts.py:31:    single_mode = getattr(task, "pipeline_mode", "full") == "single"
litehive/agents/prompts.py:106:                "- Pipeline mode is `single`: you are the only execution-stage agent for this task.",
litehive/agents/prompts.py:107:                "- Own the full task outcome yourself: use the goal and acceptance criteria as the contract, do the necessary implementation or research/docs/config work, and verify the result directly.",
litehive/agents/prompts.py:134:                    "- As the planner for grooming, either provide explicit `ACCEPTANCE_CRITERIA:` bullets or let the runner persist the inferred version by returning `VERDICT: PASS`.",
litehive/agents/prompts.py:154:                        "- As the planner for grooming, provide an `ACCEPTANCE_CRITERIA:` section with concrete `- ` bullets before passing grooming.",
litehive/agents/prompts.py:164:                "- Write each criterion as an observable outcome the user or reviewer can verify, not an implementation step.",
litehive/agents/prompts.py:286:            f'  litehive report --verdict <pass|reject> --role {stage_owner} --step {step} --message "<your report>"',
litehive/agents/prompts.py:313:        "grooming": "planner",
litehive/agents/prompts.py:316:        "accepting": "reviewer",
litehive/agents/prompts.py:362:            "- You are the planner, a PM-style role representing the user's and product's point of view.",
litehive/agents/prompts.py:375:            "- You are the reviewer, a PM-style role representing the user's and product's point of view.",
litehive/agents/prompts.py:389:            "- Only skip implementation and submit `litehive report --verdict pass` if `git diff main...HEAD` shows the expected changes and the acceptance criteria are met.",
litehive/agents/prompts.py:391:            "- If the task needs scope correction rather than code changes, use `litehive task update` to narrow scope or adjust the acceptance criteria so the task re-enters the pipeline with the corrected contract.",
litehive/agents/prompts.py:437:    return f"""You are the planner for a local multi-agent coding workspace.
litehive/agents/prompts.py:446:Keep the scope high-level and reviewable so planner grooming can refine it later.
litehive/tasks/queue_ops.py:91:            simulated_task.pipeline_status = "done"
litehive/tasks/queue_ops.py:132:                    stage=next_task.pipeline_status,
litehive/tasks/queue_ops.py:143:                                "from_stage": next_task.pipeline_status,
litehive/tasks/queue_ops.py:152:                    pipeline_status=recovery_stage,
litehive/tasks/queue_ops.py:155:                # Drop the v2 pipeline_task_state row so the runner starts
litehive/tasks/queue_ops.py:158:                from litehive.pipeline.persistence import SqlitePersistence
litehive/tasks/queue_ops.py:172:    if task.pipeline_status == "done":
litehive/tasks/queue_ops.py:186:    if task.pipeline_status == "commit_to_git":
litehive/tasks/queue_ops.py:192:    return task.status == "done" and task.pipeline_status == "done"
litehive/tasks/queue_ops.py:207:            blockers.append(f"{dependency.id} ({dependency.status}/{dependency.pipeline_status})")
litehive/tasks/queue_ops.py:282:        task.status == "in_progress" or task.pipeline_status != "backlog"
litehive/tasks/queue_ops.py:335:        if task.pipeline_status == "done":
litehive/tasks/queue_ops.py:475:                journal_message=f"Restored untouched active task to queue at `{task.pipeline_status}`.",
litehive/tasks/queue_ops.py:483:                stage=task.pipeline_status,
litehive/tasks/queue_ops.py:484:                summary=f"Interrupted run recovered. Resume from `{task.pipeline_status}`.",
litehive/tasks/queue_ops.py:485:                reason=stale_interruption_reason(task, task.pipeline_status),
litehive/pipeline/agents/merge.py:26:    ``MergeAgent`` is not a pipeline stage on its own — the state machine
litehive/agents/manager.py:63:        stage = task.runtime.current_stage.step or task.pipeline_status
tests/test_logs_command.py:191:            role="planner",
tests/test_logs_command.py:194:            path="subagents/SA-0001-planner",
tests/test_logs_command.py:206:    planner_dir = task_dir(tmp_path, task) / "subagents" / "SA-0001-planner"
tests/test_logs_command.py:207:    planner_dir.mkdir(parents=True, exist_ok=True)
tests/test_logs_command.py:208:    (planner_dir / "session.yaml").write_text(
litehive/pipeline/nodes/system.py:53:    ``CleanState`` advances the pipeline.
litehive/pipeline/nodes/system.py:73:                # A probe should never crash the pipeline; treat raised
litehive/pipeline/nodes/system.py:81:    """Pull main into the task worktree before the pipeline runs.
litehive/pipeline/nodes/system.py:101:    ``Pass`` so the default pipeline doesn't block on this node when
litehive/pipeline/nodes/system.py:352:    """Runs pre-execution recovery before the task enters the pipeline proper.
litehive/pipeline/nodes/system.py:385:        resume_stage = "implementing" if state.pipeline_mode.value == "single" else "grooming"
litehive/pipeline/nodes/system.py:440:    as the pipeline advances; capturing them in the checkpoint commit
litehive/pipeline/nodes/system.py:544:        files in both the worktree and the main repo as the pipeline
litehive/pipeline/agents/swe.py:6:- Treat the task goal, acceptance criteria, and plan as the execution contract; if they are missing or contradictory, submit `blocked` so the pipeline routes to recovery instead of guessing.
litehive/pipeline/agents/swe.py:9:- When you are done coding, submit `litehive report --verdict pass`. Your work will be checked by:
litehive/pipeline/agents/swe.py:12:  3. **Accepting stage (reviewer)** — a reviewer makes the final done/not-done judgment.
litehive/pipeline/agents/swe.py:15:- **You own the whole codebase, not just your diff.** "Out of scope" and "not my job" are not valid excuses. If a failure blocks verification of your work, fix the failure. The task's acceptance criteria define what you must achieve; the path to get there (including fixing unrelated broken things) is your responsibility. If a fix requires non-trivial work outside the obvious scope, still fix it — and note it in your verdict message so the reviewer sees what you did and why. The alternative is getting stuck in retry loops where QA keeps failing on something you could have fixed in 30 seconds.
litehive/pipeline/agents/swe.py:17:- You do NOT edit acceptance criteria or the task goal — only the planner (PM) can change scope. But you CAN and SHOULD fix unrelated breakage you encounter.
litehive/pipeline/agents/swe.py:18:- **If the work is already done:** run `git diff main...HEAD`, verify each acceptance criterion is met, then submit `--verdict pass` with concrete evidence (test output, command output, file contents that prove each criterion). QA and the reviewer will verify your claim.
litehive/pipeline/agents/swe.py:19:- **If this is a duplicate of another task:** submit `--verdict pass` with evidence pointing at the original task (commit sha, task id, what it implemented). QA and the reviewer verify that the original task actually covers this one.
litehive/pipeline/agents/swe.py:20:- Do NOT use `litehive task close`. Closing decisions (wont_do, duplicate, deferred) belong to the planner during grooming, not to you. Your job is to implement or to pass with evidence that implementation is unnecessary.
litehive/pipeline/agents/recovery.py:12:  - `litehive pipeline journal <task_id>` — **start here.** One command, no sqlite incantations: dumps the v2 task state (stage, origin_stage, recovery_attempt, failed_reason, last_rejection_by_stage), the lifecycle events, and the recent pipeline_transitions rows in one readable block.
litehive/pipeline/agents/recovery.py:17:  - `litehive pipeline rules` — the full v2 transition table, if you need to understand what routing decisions the state machine made.
litehive/pipeline/agents/recovery.py:21:  - If you need to go deeper than the CLI commands, the underlying tables are `pipeline_transitions` (columns: `seq, created_at, from_stage, event_type, event_payload, to_stage, rule_description, delta`) and `pipeline_journal` (columns: `seq, created_at, kind, payload`). Don't invent column names.
litehive/pipeline/agents/__init__.py:1:from .planner import PlannerAgent
litehive/pipeline/agents/__init__.py:4:from .reviewer import ReviewerAgent
litehive/pipeline/agents/__init__.py:9:    "PlannerAgent",
litehive/pipeline/agents/__init__.py:12:    "ReviewerAgent",
litehive/pipeline/agents/reviewer.py:4:- You are the reviewer, a PM-style role representing the user's and product's point of view.
litehive/pipeline/agents/reviewer.py:13:class ReviewerAgent(RoleAgent):
litehive/pipeline/agents/reviewer.py:17:    ROLE = "reviewer"
litehive/recovery/detection.py:12:        task.pipeline_status == "done"
litehive/recovery/detection.py:19:    return task.pipeline_status == "commit_to_git" and task.status in {
litehive/pipeline/registry.py:23:    PlannerAgent,
litehive/pipeline/registry.py:26:    ReviewerAgent,
litehive/pipeline/registry.py:122:        PlannerAgent,
litehive/pipeline/registry.py:125:        ReviewerAgent,
litehive/agents/sandbox.py:116:        sandbox_enabled = self.config.external_engine_sandbox.enabled and policy is not None and policy.enabled
litehive/pipeline/orchestration.py:3:One function — ``run_task(root, task)`` — that wires up the pipeline
litehive/pipeline/orchestration.py:12:   sqlite row exists with the right pipeline mode.
litehive/pipeline/orchestration.py:61:from .types import PipelineMode as _PipelineMode
litehive/pipeline/orchestration.py:69:    raw = task_record.pipeline_mode
litehive/pipeline/orchestration.py:70:    mode = _PipelineMode(raw) if isinstance(raw, str) and raw else _PipelineMode.FULL
litehive/pipeline/orchestration.py:71:    return persistence.initialize(task_id, pipeline_mode=mode)
litehive/pipeline/orchestration.py:74:_STAGE_TO_PIPELINE_STATUS: dict[str, str] = {
litehive/pipeline/orchestration.py:86:    """Mirror the pipeline stage back to the TaskRecord so litehive status stays accurate."""
litehive/pipeline/orchestration.py:106:        task_record.pipeline_status = "done"
litehive/pipeline/orchestration.py:125:            task_record.pipeline_status = "merge_failed"
litehive/pipeline/orchestration.py:130:            task_record.pipeline_status = "flagged"
litehive/pipeline/orchestration.py:135:        task_record.pipeline_status = _STAGE_TO_PIPELINE_STATUS.get(state.stage, task_record.pipeline_status)
litehive/pipeline/orchestration.py:145:    """Result of running one task through the pipeline state machine."""
litehive/pipeline/orchestration.py:286:    that produces fake ``Engine`` instances and the pipeline will use it in place
litehive/cli/workspace.py:208:        active_stage = active_task.runtime.current_stage.step or active_task.pipeline_status or "-"
litehive/cli/workspace.py:210:        print(f"active_task_status: {active_task.status}/{active_task.pipeline_status}")
litehive/cli/workspace.py:331:        print(f"active_task: {active_task.id} [{active_task.status}/{active_task.pipeline_status}] stage={stage} title={active_task.title}")
litehive/cli/workspace.py:395:    return task.runtime.current_stage.step or task.pipeline_status or "-"
litehive/pipeline/sessions.py:70:    """Persists ``Session`` rows to the ``pipeline_sessions`` sqlite table.
litehive/pipeline/sessions.py:88:                FROM pipeline_sessions
litehive/pipeline/sessions.py:109:                INSERT INTO pipeline_sessions (
litehive/cli/queue_cli.py:45:            f"active: {active_task.id} [{active_task.status}/{active_task.pipeline_status}] "
litehive/cli/queue_cli.py:55:            f"{index}. {task.id} [{task.status}/{task.pipeline_status}] "
litehive/cli/queue_cli.py:65:            f"resume {index}. {task.id} [{task.status}/{task.pipeline_status}] "
litehive/cli/queue_cli.py:100:            print(f"pipeline_status: {task.pipeline_status}")
litehive/cli/queue_cli.py:124:    if task.pipeline_status == "done" or task.status == "done":
litehive/cli/queue_cli.py:134:    print(f"pipeline_status: {task.pipeline_status}")
litehive/cli/queue_cli.py:157:    print(f"pipeline_status: {task.pipeline_status}")
litehive/cli/queue_cli.py:175:    print(f"pipeline_status: {summary.task.pipeline_status}")
litehive/cli/queue_cli.py:204:    print(f"pipeline_status: {task.pipeline_status}")
litehive/cli/queue_cli.py:223:    print(f"pipeline_status: {summary.task.pipeline_status}")
litehive/cli/app.py:19:from litehive.pipeline.orchestration import run_task
litehive/cli/app.py:25:pipeline_app = make_typer(invoke_without_command=True)
litehive/cli/app.py:58:app.add_typer(pipeline_app, name="pipeline", help="Inspect the v2 pipeline state machine")
litehive/cli/app.py:62:@pipeline_app.command("graph", help="Print a Mermaid stateDiagram-v2 of the v2 pipeline rules")
litehive/cli/app.py:63:def pipeline_graph_command(
litehive/cli/app.py:66:    from litehive.pipeline.diagram import render_markdown
litehive/cli/app.py:77:@pipeline_app.command("rules", help="List the v2 transition rules as readable rows")
litehive/cli/app.py:78:def pipeline_rules_command() -> int:
litehive/cli/app.py:79:    from litehive.pipeline.transitions import list_transitions
litehive/cli/app.py:90:@pipeline_app.command("set-state", help="Override a task's v2 pipeline stage")
litehive/cli/app.py:91:def pipeline_set_state_command(
litehive/cli/app.py:96:    from litehive.pipeline.persistence import SqlitePersistence, TaskNotFound
litehive/cli/app.py:102:        print(f"no v2 state row for {task_id}; use 'litehive pipeline add-task' first")
litehive/cli/app.py:111:@pipeline_app.command("reset", help="Clear all v2 pipeline state for a task so it starts fresh")
litehive/cli/app.py:112:def pipeline_reset_command(
litehive/cli/app.py:119:        for table in ["pipeline_task_state", "pipeline_sessions", "pipeline_transitions", "pipeline_journal"]:
litehive/cli/app.py:126:@pipeline_app.command("journal", help="Dump the v2 pipeline journal + transitions for one task")
litehive/cli/app.py:127:def pipeline_journal_command(
litehive/cli/app.py:132:    from litehive.pipeline.journal import SqliteJournal
litehive/cli/app.py:133:    from litehive.pipeline.persistence import SqlitePersistence, TaskNotFound
litehive/pipeline/guards.py:6:from .types import NodeName, PipelineMode
litehive/pipeline/guards.py:46:def mode(m: PipelineMode | str) -> Guard:
litehive/pipeline/guards.py:47:    want = m if isinstance(m, PipelineMode) else PipelineMode(m)
litehive/pipeline/guards.py:50:        return state.pipeline_mode == want
litehive/cli/worktree_support.py:441:            task.pipeline_status = "done"
litehive/pipeline/persistence.py:9:from .types import FailedReason, NodeName, PipelineMode
litehive/pipeline/persistence.py:64:    pipeline_mode: PipelineMode
litehive/pipeline/persistence.py:138:    pipeline_mode: str,
litehive/pipeline/persistence.py:148:        pipeline_mode=PipelineMode(pipeline_mode),
litehive/pipeline/persistence.py:189:    """Persists ``TaskState`` to the ``pipeline_task_state`` sqlite table.
litehive/pipeline/persistence.py:191:    The scalar fields (stage, pipeline_mode) are stored as columns so the
litehive/pipeline/persistence.py:209:                INSERT INTO pipeline_task_state (task_id, stage, pipeline_mode, payload, updated_at)
litehive/pipeline/persistence.py:213:                    pipeline_mode = excluded.pipeline_mode,
litehive/pipeline/persistence.py:220:                    state.pipeline_mode.value,
litehive/pipeline/persistence.py:230:                "SELECT stage, pipeline_mode, payload FROM pipeline_task_state WHERE task_id = ?",
litehive/pipeline/persistence.py:234:            raise TaskNotFound(f"no pipeline_task_state row for task {task_id!r}")
litehive/pipeline/persistence.py:238:            pipeline_mode=row["pipeline_mode"],
litehive/pipeline/persistence.py:244:        """Delete the v2 pipeline state row for a task.
litehive/pipeline/persistence.py:253:            connection.execute("DELETE FROM pipeline_task_state WHERE task_id = ?", (task_id,))
litehive/pipeline/persistence.py:260:        pipeline_mode: PipelineMode = PipelineMode.FULL,
litehive/pipeline/persistence.py:274:            pipeline_mode=pipeline_mode,
litehive/cli/dry_run.py:128:            f"status={task.status} pipeline_status={task.pipeline_status} "
litehive/observability/status.py:16:# Ordered pipeline stages for remaining-time estimation.
litehive/observability/status.py:17:_PIPELINE_STAGES = ["grooming", "implementing", "testing", "accepting", "commit_to_git"]
litehive/observability/status.py:31:        or task.pipeline_status
litehive/observability/status.py:32:        or _PIPELINE_STAGES[0]
litehive/observability/status.py:35:        current_idx = _PIPELINE_STAGES.index(current_step)
litehive/observability/status.py:38:    remaining_stages = len(_PIPELINE_STAGES) - current_idx
litehive/observability/status.py:70:    lines = [f"{marker} {task.id} [{task.status}/{task.pipeline_status}] {task.mode} retry_limit={retry_label} {task.title}"]
litehive/observability/status.py:199:                f"resume_from={interruption.resume_stage or interruption.pipeline_status or '-'} "
litehive/observability/status.py:329:    stage = task.runtime.current_stage.step or task.pipeline_status or "-"
litehive/observability/status.py:368:        stage = task.runtime.current_stage.step or task.pipeline_status or "-"
litehive/cli/import_cli.py:54:    source_stage: Annotated[str | None, typer.Option(help="Originating pipeline stage")] = None,
litehive/cli/import_cli.py:86:    source_stage = source_stage or (source_task_record.pipeline_status if source_task_record is not None else None)
litehive/cli/agent_cli.py:1:"""Restricted CLI for agents running inside the v2 pipeline.
litehive/cli/agent_cli.py:18:from litehive.pipeline.persistence import SqlitePersistence, TaskNotFound
litehive/cli/agent_cli.py:28:    "planner": {"pass", "blocked"},  # planners shape tasks via TASK_UPDATE, not reject
litehive/cli/agent_cli.py:31:    "reviewer": {"pass", "reject", "blocked"},
litehive/cli/agent_cli.py:101:        pipeline_state = SqlitePersistence(root).load(tid)
litehive/cli/agent_cli.py:102:        actual_step = step or pipeline_state.stage
litehive/cli/agent_cli.py:104:        actual_step = step or task.pipeline_status
litehive/cli/agent_cli.py:128:@agent_app.command("update", help="Update task fields (planner/reviewer only)")
litehive/cli/agent_cli.py:140:    _require_role({"planner", "reviewer"})
litehive/cli/agent_cli.py:168:@agent_app.command("close", help="Close a task (planner/reviewer only)")
litehive/cli/agent_cli.py:175:    _require_role({"planner", "reviewer"})
litehive/pipeline/events.py:1:"""Sealed event hierarchy for the pipeline state machine.
litehive/pipeline/events.py:66:    """The ``ready`` probe found no pre-execution trouble; enter the pipeline.
litehive/pipeline/events.py:91:      - agent nodes → ``source="agent"`` (reviewer finds a bug, QA's
litehive/pipeline/events.py:92:        tests fail, planner can't produce a plan, etc.).
litehive/pipeline/events.py:247:    """Pre-exec recovery cleared whatever was wrong; resume the pipeline.
litehive/pipeline/rules.py:1:"""The pipeline rule table. Nothing else lives here.
litehive/cli/display.py:82:        return "Capture the original intake and prepare it for planner grooming."
litehive/cli/display.py:138:        else task.runtime.current_stage.step or task.pipeline_status
litehive/pipeline/stages.py:1:"""Pipeline stages — the enum of states the machine can be in.
litehive/pipeline/stages.py:4:Ctrl+click: ``Stages.GROOMING`` → here → ``node=PlannerAgent`` → the agent code.
litehive/pipeline/stages.py:10:from .agents.planner import PlannerAgent
litehive/pipeline/stages.py:13:from .agents.reviewer import ReviewerAgent
litehive/pipeline/stages.py:55:    GROOMING = Stage("grooming", PlannerAgent)
litehive/pipeline/stages.py:70:    ACCEPTING = Stage("accepting", ReviewerAgent)
litehive/pipeline/types.py:12:class PipelineMode(str, Enum):
litehive/cli/templates/workspace_config.yaml:36:# Stage-local retry budget before the pipeline escalates.
litehive/cli/pool.py:135:    pipeline_status,
litehive/cli/pool.py:146:        "pipeline_status": pipeline_status,
litehive/cli/pool.py:157:        if task.status in {"queued", "in_progress"} and task.pipeline_status != "done":
litehive/cli/pool.py:164:                    pipeline_status=task.pipeline_status,
litehive/cli/pool.py:174:        if task.status not in {"interrupted", "parked"} or task.pipeline_status == "done":
litehive/cli/pool.py:182:                pipeline_status=task.pipeline_status,
litehive/cli/pool.py:203:                pipeline_status=task.pipeline_status,
litehive/cli/pool.py:222:        f"pipeline_status={entry['pipeline_status']} stage_outcomes={stage_outcomes_label}"
litehive/pipeline/agents/base.py:38:    - ``NODE_NAME`` — pipeline node the agent implements (``"grooming"``, …).
litehive/pipeline/agents/base.py:39:    - ``ROLE`` — logical agent role (``"planner"``, ``"swe"``, …).
litehive/pipeline/agents/base.py:92:            "pipeline_mode": state.pipeline_mode.value,
litehive/recovery/execution_recovery.py:50:    if task.status != "done" or task.pipeline_status != "done":
litehive/pipeline/agents/planner.py:4:- You are the planner, a PM-style role representing the user's and product's point of view.
litehive/pipeline/agents/planner.py:7:- **You cannot submit --verdict reject.** Your job is to SHAPE tasks, not reject them. If the task as written is wrong, rewrite it via TASK_UPDATE. If it mixes concerns, split it: narrow the current task via TASK_UPDATE and create follow-up tasks via `litehive task add`. If it's genuinely not worth doing, close it with `outcome: wont_do` in TASK_UPDATE. If it's already done, close it with `outcome: duplicate`. The planner's only valid verdicts are `pass` and `blocked` (use blocked only if you literally cannot shape the task because of infrastructure failure).
litehive/pipeline/agents/planner.py:18:class PlannerAgent(RoleAgent):
litehive/pipeline/agents/planner.py:22:    ROLE = "planner"
litehive/recovery/workspace_repair.py:283:        pipeline_status=stage,
litehive/recovery/workspace_repair.py:341:    task.pipeline_status = stage
litehive/recovery/workspace_repair.py:362:        return f"Interrupted run recorded. Resume from `{task.pipeline_status}`."
litehive/recovery/workspace_repair.py:366:            f"`{interruption.stage or task.pipeline_status}` was running."
litehive/recovery/workspace_repair.py:379:    parts.append(f"Resume from `{interruption.resume_stage or task.pipeline_status}`.")
litehive/recovery/workspace_repair.py:481:    stage = task.pipeline_status
litehive/recovery/workspace_repair.py:496:            finalized=task.pipeline_status == "done",
litehive/recovery/workspace_repair.py:514:        stage=task.pipeline_status,
litehive/recovery/workspace_repair.py:515:        summary=f"Recovered stale runner state and returned the task to `{task.pipeline_status}`.",
litehive/recovery/workspace_repair.py:522:                summary=f"Requeued the task at {task.pipeline_status}.",
litehive/recovery/workspace_repair.py:523:                metadata={"stage": task.pipeline_status},
litehive/pipeline/task_updates.py:83:    a malformed TASK_UPDATE shouldn't fail the pipeline.
```

```tool
output:
litehive/config/pool_types.py:14:    last_verdict: str | None = None
tests_integration/helpers.py:208:def assert_nudge_verdict_submission(
tests_integration/helpers.py:214:    """Verify the nudge flow: run engine, then nudge to submit verdict via CLI."""
tests_integration/helpers.py:226:        "--verdict pass "
tests_integration/helpers.py:231:    # Step 2: nudge — submit verdict via litehive report CLI
tests_integration/helpers.py:244:    # Step 3: verify verdict persisted
tests_integration/helpers.py:246:    verdicts = [c for c in thread if c.verdict != "comment"]
tests_integration/helpers.py:247:    assert len(verdicts) >= 1, f"Expected verdict from {engine_name}, got: {thread}"
tests_integration/helpers.py:248:    assert verdicts[-1].verdict == "pass"
tests_integration/helpers.py:249:    assert verdicts[-1].role == "swe"
tests_integration/test_gemini.py:4:    assert_nudge_verdict_submission,
tests_integration/test_gemini.py:22:def test_gemini_nudge_submits_verdict_via_cli(gemini_smoke_session) -> None:
tests_integration/test_gemini.py:23:    assert_nudge_verdict_submission("gemini", smoke_session=gemini_smoke_session)
tests/test_pipeline_v2_prompt_serializer.py:52:        "\n\nIMPORTANT: when you are done, submit your verdict by running:",
tests/test_pipeline_v2_prompt_serializer.py:146:    assert "litehive agent report" in text
tests/test_pipeline_v2_prompt_serializer.py:149:def test_serialize_verdict_instructions_match_role_and_stage(workspace: Path) -> None:
tests/test_pipeline_v2_prompt_serializer.py:154:    assert "litehive agent report --verdict <pass|reject|blocked>" in text
tests/test_pipeline_v2_prompt_serializer.py:165:    assert "without a verdict submission" in text
tests/test_pipeline_v2_prompt_serializer.py:166:    assert "Please review your work and submit your verdict now." in text
tests/test_pipeline_v2_prompt_serializer.py:183:        {"role": "planner", "step": "grooming", "verdict": "pass", "message": "scope " + ("x" * 600)},
tests/test_pipeline_v2_prompt_serializer.py:184:        {"role": "recovery", "step": "recovering", "verdict": "comment", "message": "bookkeeping"},
tests/test_pipeline_v2_prompt_serializer.py:185:        {"role": "swe", "step": "implementing", "verdict": "pass", "message": "old swe pass"},
tests/test_pipeline_v2_prompt_serializer.py:186:        {"role": "qa", "step": "testing", "verdict": "reject", "message": "older reject"},
tests/test_pipeline_v2_prompt_serializer.py:187:        {"role": "qa", "step": "testing", "verdict": "reject", "message": "tests fail"},
tests/test_pipeline_v2_prompt_serializer.py:216:            {"role": "planner", "step": "grooming", "verdict": "pass", "message": "scope"},
tests/test_pipeline_v2_prompt_serializer.py:217:            {"role": "reviewer", "step": "accepting", "verdict": "reject", "message": "same reason"},
tests/test_pipeline_v2_prompt_serializer.py:238:            {"role": "planner", "step": "grooming", "verdict": "pass", "message": "scope"},
tests/test_pipeline_v2_prompt_serializer.py:239:            {"role": "swe", "step": "implementing", "verdict": "pass", "message": "first impl"},
tests/test_pipeline_v2_prompt_serializer.py:240:            {"role": "qa", "step": "testing", "verdict": "reject", "message": "old reject"},
tests/test_pipeline_v2_prompt_serializer.py:241:            {"role": "swe", "step": "implementing", "verdict": "pass", "message": "latest impl"},
tests/test_pipeline_v2_prompt_serializer.py:261:            {"role": "planner", "step": "grooming", "verdict": "pass", "message": "scope"},
tests/test_pipeline_v2_prompt_serializer.py:262:            {"role": "swe", "step": "implementing", "verdict": "pass", "message": "first impl"},
tests/test_pipeline_v2_prompt_serializer.py:263:            {"role": "qa", "step": "testing", "verdict": "pass", "message": "first qa"},
tests/test_pipeline_v2_prompt_serializer.py:264:            {"role": "qa", "step": "testing", "verdict": "reject", "message": "old reject"},
tests/test_pipeline_v2_prompt_serializer.py:265:            {"role": "swe", "step": "implementing", "verdict": "pass", "message": "latest impl"},
tests/test_pipeline_v2_prompt_serializer.py:266:            {"role": "qa", "step": "testing", "verdict": "pass", "message": "latest qa"},
tests_integration/test_opencode.py:4:    assert_nudge_verdict_submission,
tests_integration/test_opencode.py:22:def test_opencode_nudge_submits_verdict_via_cli(opencode_smoke_session) -> None:
tests_integration/test_opencode.py:23:    assert_nudge_verdict_submission("opencode", smoke_session=opencode_smoke_session)
tests_integration/test_copilot.py:4:    assert_nudge_verdict_submission,
tests_integration/test_copilot.py:22:def test_copilot_nudge_submits_verdict_via_cli(copilot_smoke_session) -> None:
tests_integration/test_copilot.py:23:    assert_nudge_verdict_submission("copilot", smoke_session=copilot_smoke_session)
tests_integration/test_codex.py:6:    assert_nudge_verdict_submission,
tests_integration/test_codex.py:31:        f'Run `litehive report --verdict pass --role swe --step implementing --task-id {task.id} '
tests_integration/test_codex.py:39:    assert thread[-1].verdict == "pass"
tests_integration/test_codex.py:43:def test_codex_nudge_submits_verdict_via_cli(codex_smoke_session) -> None:
tests_integration/test_codex.py:44:    assert_nudge_verdict_submission("codex", smoke_session=codex_smoke_session)
tests/test_stage_result_submission.py:19:        "verdict": "pass",
tests/test_stage_result_submission.py:32:    assert report.verdict == "pass"
tests/test_stage_result_submission.py:41:# AC-2: Extra unknown field → validation error, verdict is reject (no text fallback)
tests/test_stage_result_submission.py:46:        "verdict": "pass",
tests/test_stage_result_submission.py:50:    transcript = _transcript(payload) + "\nVERDICT: FAIL\nSUMMARY: text fallback\n"
tests/test_stage_result_submission.py:57:    # No text fallback — verdict is always reject when STAGE_RESULT is invalid
tests/test_stage_result_submission.py:58:    assert report.verdict == "reject"
tests/test_stage_result_submission.py:61:    # Also warns about missing CLI verdict
tests/test_stage_result_submission.py:66:# AC-3: Missing required verdict field → reject verdict, no text fallback
tests/test_stage_result_submission.py:69:def test_missing_verdict_produces_reject_with_warning() -> None:
tests/test_stage_result_submission.py:74:    transcript = _transcript(payload) + "\nVERDICT: PASS\nSUMMARY: text path\n"
tests/test_stage_result_submission.py:81:    # Text VERDICT: PASS is NOT parsed — no text fallback
tests/test_stage_result_submission.py:82:    assert report.verdict == "reject"
tests/test_stage_result_submission.py:85:    assert any("verdict" in w for w in report.warnings)
tests/test_stage_result_submission.py:95:        "verdict": "pass",
tests/test_stage_result_submission.py:111:        "verdict": "pass",
tests/test_stage_result_submission.py:134:        "verdict": "pass",
tests/test_stage_result_submission.py:158:        # verdict is missing
tests/test_stage_result_submission.py:159:        "summary": "no verdict here",
tests/test_stage_result_submission.py:161:    transcript = _transcript(payload) + "\nVERDICT: PASS\nSUMMARY: fallback\n"
tests/test_stage_result_submission.py:168:    # Verdict is reject — text VERDICT: PASS is not parsed
tests/test_stage_result_submission.py:169:    assert report.verdict == "reject"
tests/test_stage_result_submission.py:179:        "verdict": "pass",
tests/test_stage_result_submission.py:183:    transcript = _transcript(payload) + "\nVERDICT: PASS\nSUMMARY: fallback\n"
tests/test_stage_result_submission.py:190:    assert report.verdict == "reject"
tests/test_stage_result_submission.py:196:        "verdict": "pass",
tests/test_stage_result_submission.py:207:    assert report.verdict == "reject"
tests/test_stage_result_submission.py:221:    assert report.verdict == "reject"
tests/test_stage_result_submission.py:222:    assert report.summary == "implementing rejected without verdict"
tests/test_stage_result_submission.py:230:        transcript="VERDICT: PASS\nSUMMARY: looked good before crash\n",
tests/test_stage_result_submission.py:234:    assert report.verdict == "reject"
tests/test_stage_result_submission.py:235:    assert report.summary == "VERDICT: PASS"
tests/test_stage_result_submission.py:239:def test_legacy_fail_verdict_in_structured_submission_normalizes_to_reject() -> None:
tests/test_stage_result_submission.py:241:        "verdict": "fail",
tests/test_stage_result_submission.py:251:    assert report.verdict == "reject"
tests/test_pipeline_v2_last_report.py:3:Agent verdicts carry ``files_changed`` / ``tests_added`` in their
tests/test_pipeline_v2_last_report.py:11:from litehive.pipeline.nodes.agent import AgentNode, AgentVerdict
tests/test_pipeline_v2_last_report.py:29:    def run_turn(self, session: Any, prompt: Any, state: Any) -> AgentVerdict:
tests/test_pipeline_v2_last_report.py:30:        return AgentVerdict(
tests/test_pipeline_v2_last_report.py:42:def test_agent_verdict_metadata_flows_into_pass_event() -> None:
tests/test_pipeline_v2_last_report.py:43:    """Verify AgentNode._verdict_to_event copies metadata onto Pass."""
litehive/config/pipeline_states.py:10:The canonical transition table is ``ROUTES``: ``(stage, verdict) -> next_stage``.
litehive/config/pipeline_states.py:73:# Transition table: (current_stage, verdict) -> next_stage
litehive/config/pipeline_states.py:75:# Verdicts:
litehive/config/pipeline_states.py:80:# Omitted (stage, verdict) pairs are handled by the runner as:
tests_integration/test_claude.py:4:    assert_nudge_verdict_submission,
tests_integration/test_claude.py:22:def test_claude_nudge_submits_verdict_via_cli(claude_smoke_session) -> None:
tests_integration/test_claude.py:23:    assert_nudge_verdict_submission("claude", smoke_session=claude_smoke_session)
tests/test_pipeline_hook_reject_circuit_breaker.py:9:from litehive.pipeline.nodes.agent import AgentVerdict
tests/test_pipeline_hook_reject_circuit_breaker.py:26:    def run_turn(self, session: Any, prompt: Any, state: Any) -> AgentVerdict:
tests/test_pipeline_hook_reject_circuit_breaker.py:31:                return AgentVerdict(outcome="resume", metadata={"target_stage": "implementing"})
tests/test_pipeline_hook_reject_circuit_breaker.py:32:            return AgentVerdict(outcome=self.recovery_outcome)
tests/test_pipeline_hook_reject_circuit_breaker.py:33:        return AgentVerdict(outcome="pass")
litehive/config/startup_guidance.py:8:        "Do not redo the failed stage's work, do not implement the task itself, and do not submit the failed stage's verdict on the prior agent's behalf.",
litehive/config/startup_guidance.py:10:        "Submit your own recovery verdict describing the Litehive root cause you found, the fix you made, and why the failed stage should be retried.",
tests/test_feedback_cap.py:36:        '{"verdict":"pass","summary":"done","files_changed":["foo.py"],'
tests/test_feedback_cap.py:47:    assert report.verdict == "pass"
tests/test_feedback_cap.py:50:def test_parse_stage_report_text_caps_feedback_no_cli_verdict() -> None:
tests/test_feedback_cap.py:51:    """Without CLI verdict, feedback is still capped and verdict is reject."""
tests/test_feedback_cap.py:55:        "VERDICT: PASS\n"
tests/test_feedback_cap.py:69:    # Text VERDICT: PASS is no longer parsed — verdict is reject
tests/test_feedback_cap.py:70:    assert report.verdict == "reject"
litehive/models/report_models.py:82:    verdict: Literal["pass", "reject", "blocked", "comment"] = "comment"
litehive/models/report_models.py:87:    @field_validator("verdict", mode="before")
litehive/models/report_models.py:89:    def _normalize_thread_verdict(cls, value: object) -> object:
tests/test_pipeline_v2_bootstrap.py:19:from litehive.pipeline.nodes.agent import AgentVerdict, EngineBlockedError
tests/test_pipeline_v2_bootstrap.py:57:    def run_turn(self, session: Any, prompt: Any, state: Any) -> AgentVerdict:
tests/test_pipeline_v2_bootstrap.py:62:    def _run(engine, session, prompt, state) -> AgentVerdict:
tests/test_pipeline_v2_bootstrap.py:66:        return AgentVerdict(outcome="pass", reason="stub-auto-pass")
tests/test_pipeline_v2_bootstrap.py:71:def _always_block_behavior(engine, session, prompt, state) -> AgentVerdict:
litehive/models/runtime_models.py:40:    verdict: str | None = None
litehive/workspace/task_status.py:254:            verdict="comment",
tests/test_main.py:22:        ["litehive", "report", "--verdict", "pass", "--message", "ok"],
tests/test_main.py:32:        "--verdict",
tests/workspace_helpers.py:313:    argv = ["report", "--verdict", args.verdict, "--message", args.message]
tests/workspace_helpers.py:577:def _write_cli_verdict(
tests/workspace_helpers.py:581:    verdict: str = "pass",
tests/workspace_helpers.py:601:            verdict=verdict,
tests/workspace_helpers.py:602:            message=message or f"{step} {verdict}",
tests/workspace_helpers.py:647:    # Simulate CLI verdict submission via thread comment.
tests/workspace_helpers.py:650:        _write_cli_verdict(
tests/workspace_helpers.py:654:            verdict="pass",
tests/workspace_helpers.py:683:    # Simulate CLI verdict submission via thread comment.
tests/workspace_helpers.py:685:        _write_cli_verdict(
tests/workspace_helpers.py:689:            verdict="fail",
tests/workspace_helpers.py:720:    verdict: str = "PASS",
tests/workspace_helpers.py:729:    effective_verdict = verdict.lower()
tests/workspace_helpers.py:731:    # Simulate CLI verdict submission via thread comment.
tests/workspace_helpers.py:733:        _write_cli_verdict(
tests/workspace_helpers.py:737:            verdict=effective_verdict,
tests/workspace_helpers.py:836:    # Auto-write a CLI verdict for the active task in the workspace.
tests/workspace_helpers.py:846:            _write_cli_verdict(
tests/workspace_helpers.py:850:                verdict="pass",
tests/workspace_helpers.py:993:    "_write_cli_verdict",
tests/test_pipeline_v2_agent_retries.py:12:    AgentVerdict,
tests/test_pipeline_v2_agent_retries.py:30:    def run_turn(self, session: Any, prompt: Any, state: TaskState) -> AgentVerdict:
tests/test_pipeline_v2_agent_retries.py:37:        return step  # AgentVerdict
tests/test_pipeline_v2_agent_retries.py:77:            AgentVerdict(outcome="pass"),
tests/test_pipeline_v2_agent_retries.py:95:    claude = _ScriptedEngine("claude", [AgentVerdict(outcome="pass")])
tests/test_pipeline_v2_agent_retries.py:132:            AgentVerdict(outcome="pass"),
tests/test_pipeline_v2_agent_retries.py:151:# ── nudge on missing verdict ────────────────────────────────────────────
tests/test_pipeline_v2_agent_retries.py:159:            AgentVerdict(outcome="pass"),
tests/test_pipeline_v2_agent_retries.py:189:            AgentVerdict(outcome="pass"),         # success
tests/test_pipeline_v2_agent_retries.py:205:    claude = _ScriptedEngine("claude", [AgentVerdict(outcome="pass")])
tests/test_pipeline_v2_agent_retries.py:260:    claude = _ScriptedEngine("claude", [AgentVerdict(outcome="pass")])
litehive/workspace/runtime_tracking.py:40:            "verdict": None,
litehive/workspace/runtime_tracking.py:227:            "verdict": None,
litehive/workspace/runtime_tracking.py:246:            "status": "completed" if report.verdict in {"pass", "accept"} else report.verdict,
litehive/workspace/runtime_tracking.py:251:            "verdict": report.verdict,
litehive/workspace/runtime_tracking.py:263:            "verdict": None,
litehive/workspace/runtime_tracking.py:403:        if not stripped or stripped.startswith("VERDICT:"):
tests/test_debug_command.py:124:# -- Verdict display --
tests/test_debug_command.py:127:def test_debug_shows_verdict(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
tests/test_debug_command.py:132:        TaskThreadComment(role="swe", step="implementing", verdict="pass", message="All good"),
tests/test_debug_command.py:139:    assert "verdict: pass" in output
tests/test_debug_command.py:140:    assert "verdict_step: implementing" in output
tests/test_debug_command.py:141:    assert "verdict_message: All good" in output
tests/test_debug_command.py:144:def test_debug_no_verdict(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
tests/test_debug_command.py:151:    assert "verdict: none" in output
tests/test_engine_variants_and_timeline.py:337:                '{"type":"assistant","message":{"content":[{"type":"text","text":"VERDICT: PASS\\n"}]}}',
tests/test_engine_variants_and_timeline.py:357:    assert adapter.render_transcript(execution).splitlines()[0] == "VERDICT: PASS"
tests/test_engine_variants_and_timeline.py:365:    # Text-based verdict parsing removed; without CLI verdict or STAGE_RESULT JSON,
tests/test_engine_variants_and_timeline.py:366:    # verdict defaults to reject.
tests/test_engine_variants_and_timeline.py:367:    assert report.verdict == "reject"
tests/test_engine_variants_and_timeline.py:368:    assert report.summary == "VERDICT: PASS"
tests/test_engine_variants_and_timeline.py:382:                '{"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"VERDICT: PASS\\n"}}',
tests/test_engine_variants_and_timeline.py:402:    assert transcript.splitlines()[0] == "VERDICT: PASS"
tests/test_engine_variants_and_timeline.py:410:    assert report.summary == "VERDICT: PASS"
tests/test_engine_variants_and_timeline.py:443:                '{"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"VERDICT: PASS\\n"}}',
tests/test_engine_variants_and_timeline.py:457:    assert report["summary"] == "VERDICT: PASS"
tests/test_engine_variants_and_timeline.py:470:    assert interrupted.transcript_snippet == "VERDICT: PASS"
tests/test_engine_variants_and_timeline.py:474:    assert resumed_report["summary"] == "VERDICT: PASS"
tests/test_engine_variants_and_timeline.py:507:    assert report.verdict == "reject"
tests/test_engine_variants_and_timeline.py:732:    stdout = '{"type":"text","part":{"text":"VERDICT: PASS\\nSUMMARY: did the thing"}}\n'
tests/test_engine_variants_and_timeline.py:741:    assert "VERDICT: PASS" in timeline.events[0].content
tests/test_engine_variants_and_timeline.py:859:    stdout = '{"type":"text","part":{"text":"VERDICT: PASS\\nSUMMARY: done"}}\n'
tests/test_engine_variants_and_timeline.py:1014:        return StageReport(task_id=task.id, step=step, verdict="pass", summary=f"{step} ok", files_changed=["app.txt"], tests={"added": 1, "passing": 1})
tests/test_engine_variants_and_timeline.py:1040:                "verdict": "pass",
litehive/recovery/workspace_repair.py:114:                "verdict": None,
litehive/recovery/workspace_repair.py:323:            "verdict": "blocked",
tests/test_tasks_and_subagents.py:633:                    "VERDICT: PASS\n"
tests/test_tasks_and_subagents.py:666:        "VERDICT: PASS\n"
tests/test_tasks_and_subagents.py:676:        "VERDICT: PASS\n"
tests/test_tasks_and_subagents.py:689:    # Text-based verdict parsing removed; summary is now first line of transcript.
tests/test_tasks_and_subagents.py:690:    assert report["summary"] == "VERDICT: PASS"
tests/test_tasks_and_subagents.py:735:                stdout="VERDICT: PASS\nSUMMARY: ok",
tests/test_tasks_and_subagents.py:752:def test_subagent_manager_uses_runtime_current_stage_for_cli_verdict_lookup(
tests/test_tasks_and_subagents.py:783:                            "verdict": "reject",
tests/test_tasks_and_subagents.py:924:                stdout="VERDICT: PASS\nSUMMARY: streaming",
tests/test_tasks_and_subagents.py:941:            ) == "VERDICT: PASS\nSUMMARY: streaming"
tests/test_tasks_and_subagents.py:944:                "VERDICT: PASS\nSUMMARY: streaming\n\n[stderr]\npartial stderr"
tests/test_tasks_and_subagents.py:947:            assert report["summary"] == "VERDICT: PASS"
tests/test_tasks_and_subagents.py:955:                    "VERDICT: PASS\n"
tests/test_tasks_and_subagents.py:981:        "VERDICT: PASS\nSUMMARY: streaming complete\nFILES_CHANGED:\n- litehive/external_cli.py\n"
tests/test_tasks_and_subagents.py:983:    assert report["summary"] == "VERDICT: PASS"
tests/test_tasks_and_subagents.py:1106:                "printf 'VERDICT: PASS\\nSUMMARY: live start\\n'; "
tests/test_tasks_and_subagents.py:1155:    assert report["summary"] == "VERDICT: PASS"
tests/test_tasks_and_subagents.py:1166:    assert report["summary"] == "VERDICT: PASS"
tests/test_tasks_and_subagents.py:1171:        .startswith("VERDICT: PASS\nSUMMARY: live start\n")
tests/test_tasks_and_subagents.py:1215:                stdout="VERDICT: PASS\nSUMMARY: partial",
tests/test_tasks_and_subagents.py:1229:                    stdout="VERDICT: PASS\nSUMMARY: partial",
tests/test_tasks_and_subagents.py:1268:def _subagent_manager_timeout_cannot_preserve_structured_pass_verdict(
tests/test_tasks_and_subagents.py:1299:                '{"verdict":"pass","summary":"partial timeout result","tests":{"added":1,"passing":1}}\n'
tests/test_tasks_and_subagents.py:1347:def _subagent_manager_timeout_cannot_preserve_structured_pass_verdict(
tests/test_tasks_and_subagents.py:1350:    _subagent_manager_timeout_cannot_preserve_structured_pass_verdict(tmp_path, monkeypatch)
tests/test_tasks_and_subagents.py:1397:                stdout="VERDICT: PASS\nSUMMARY: retry folder allocated safely\nFILES_CHANGED:\nTESTS_ADDED: 0\nTESTS_PASSING: 0\nWARNINGS:\n",
tests/test_tasks_and_subagents.py:1467:                stdout="VERDICT: PASS\nSUMMARY: silent streaming complete\n",
tests/test_tasks_and_subagents.py:1536:                    "VERDICT: PASS\nSUMMARY: sandboxed execution\nFILES_CHANGED:\n"
tests/test_tasks_and_subagents.py:3759:                stdout=f"VERDICT: PASS\nSUMMARY: artifact pass {self.calls}\n",
litehive/tasks/reports.py:119:            ("report.yaml", "latest subagent report"),
litehive/tasks/reports.py:257:            verdict="comment",
litehive/tasks/reports.py:295:        comment.verdict == "pass"
litehive/tasks/reports.py:337:            header = f"[{c.created_at}] {c.role} ({c.step}) - {c.verdict} {RETRACTED_FILESYSTEM_MARKER}"
litehive/tasks/reports.py:346:        header = f"[{c.created_at}] {c.role} ({c.step}) — {c.verdict}"
tests/test_pipeline_v2_task_updates.py:1:"""Tests for TASK_UPDATE application from grooming verdict comments.
tests/test_pipeline_v2_task_updates.py:28:    msg = """Verdict: pass.
litehive/pipeline/prompt_serializer.py:15:  - finishes with the ``litehive report`` verdict instructions
litehive/pipeline/prompt_serializer.py:43:    verdicts.
litehive/pipeline/prompt_serializer.py:86:    sections.append(_verdict_instructions_section(prompt))
litehive/pipeline/prompt_serializer.py:104:            "verdict": c.verdict,
litehive/pipeline/prompt_serializer.py:203:        "IMPORTANT: this is a nudge because your prior turn ended without a verdict submission.",
litehive/pipeline/prompt_serializer.py:208:        "Do not continue exploratory work until you have submitted `litehive agent report` with the correct verdict."
litehive/pipeline/prompt_serializer.py:232:    - Never include recovery entries with verdict=comment (bookkeeping noise).
litehive/pipeline/prompt_serializer.py:241:        fallback:     grooming pass + last entry per (step, verdict)
litehive/pipeline/prompt_serializer.py:247:        if not (e.get("role") == "recovery" and e.get("verdict") == "comment")
litehive/pipeline/prompt_serializer.py:260:                e.get("verdict") == "reject"
litehive/pipeline/prompt_serializer.py:278:        g = _last_where(step="grooming", verdict="pass")
litehive/pipeline/prompt_serializer.py:285:                if e.get("verdict") == "reject" and e.get("step") in (
litehive/pipeline/prompt_serializer.py:292:        p = _last_where(step="implementing", verdict="pass")
litehive/pipeline/prompt_serializer.py:297:        p = _last_where(step="implementing", verdict="pass")
litehive/pipeline/prompt_serializer.py:300:        t = _last_where(step="testing", verdict="pass")
litehive/pipeline/prompt_serializer.py:305:        p = _last_where(step="implementing", verdict="pass")
litehive/pipeline/prompt_serializer.py:310:            if e.get("verdict") in ("reject", "blocked"):
litehive/pipeline/prompt_serializer.py:315:        # Fallback: grooming pass + last per (step, verdict)
litehive/pipeline/prompt_serializer.py:316:        g = _last_where(step="grooming", verdict="pass")
litehive/pipeline/prompt_serializer.py:321:            key = (e.get("step", "?"), e.get("verdict", "?"))
litehive/pipeline/prompt_serializer.py:341:        verdict = entry.get("verdict", "comment")
litehive/pipeline/prompt_serializer.py:343:        blocks.append(f"[{step}] {role} ({verdict}): {message}")
litehive/pipeline/prompt_serializer.py:356:    lines.append("Run these checks yourself before submitting your verdict. If they fail, the after-stage hook will reject your work and you will need to fix it.")
litehive/pipeline/prompt_serializer.py:360:def _verdict_instructions_section(prompt: dict[str, Any]) -> str:
litehive/pipeline/prompt_serializer.py:362:        "IMPORTANT: when you are done, submit your verdict by running:\n"
litehive/pipeline/prompt_serializer.py:363:        "  echo 'your report text' > /tmp/verdict_msg.txt\n"
litehive/pipeline/prompt_serializer.py:364:        "  litehive agent report --verdict <pass|reject|blocked> --message-file /tmp/verdict_msg.txt\n\n"
litehive/agents/base.py:10:        warning.replace("litehive agent report CLI", "litehive report CLI")
tests/test_task_comments.py:28:                    "verdict": "pass",
tests/test_task_comments.py:41:        TaskThreadComment(role="swe", step="implementing", verdict="pass", message="new"),
tests/test_task_comments.py:58:                    "verdict": "reject",
tests/test_task_comments.py:85:                    "verdict": "reject",
tests/test_task_comments.py:116:                    "verdict": "pass",
tests/test_task_comments.py:131:                    "verdict": "pass",
litehive/pipeline/runner.py:79:        ``files_changed`` / ``tests_added`` via the verdict submission,
litehive/agents/prompts.py:134:                    "- As the planner for grooming, either provide explicit `ACCEPTANCE_CRITERIA:` bullets or let the runner persist the inferred version by returning `VERDICT: PASS`.",
litehive/agents/prompts.py:135:                    "- You may return `VERDICT: PASS` without restating them; the runner will infer and persist the criteria after grooming.",
litehive/agents/prompts.py:136:                    "- If the current task context is not sufficient after all, return `VERDICT: REJECT` instead of passing grooming without criteria.",
litehive/agents/prompts.py:138:                    "- Return `VERDICT: REJECT` if the inferred criteria are incomplete or incorrect and the task still needs more information.",
litehive/agents/prompts.py:155:                        "- If the context is still insufficient, return `VERDICT: REJECT` and explain the missing information in `SUMMARY` or `WARNINGS`.",
litehive/agents/prompts.py:281:    # Instruct agents to submit their verdict via CLI
litehive/agents/prompts.py:285:            "IMPORTANT: When you are done, you MUST submit your verdict by running:",
litehive/agents/prompts.py:286:            f'  litehive report --verdict <pass|reject> --role {stage_owner} --step {step} --message "<your report>"',
litehive/agents/prompts.py:352:            "- Your job is not to redo the failed stage's work, not to re-run the task's implementation or verification, and not to submit the failed stage verdict on the previous agent's behalf.",
litehive/agents/prompts.py:358:            "- Submit your own recovery verdict describing the root cause, the Litehive fix you made, and why the failed stage should be retried.",
litehive/agents/prompts.py:389:            "- Only skip implementation and submit `litehive report --verdict pass` if `git diff main...HEAD` shows the expected changes and the acceptance criteria are met.",
litehive/agents/parsing.py:17:    # Step 1: Check if agent submitted a verdict via `litehive report` CLI.
litehive/agents/parsing.py:22:        step_comments = [c for c in thread if c.step == step and c.verdict != "comment"]
litehive/agents/parsing.py:28:                verdict=latest.verdict,  # type: ignore[arg-type]
litehive/agents/parsing.py:31:                else f"{step} {latest.verdict}",
litehive/agents/parsing.py:37:    # Step 2: Resource limit events produce a blocked verdict.
litehive/agents/parsing.py:47:            verdict="blocked",
litehive/agents/parsing.py:54:    # No CLI verdict submitted — treat agent non-completion as reject.
litehive/agents/parsing.py:58:        verdict="reject",
litehive/agents/parsing.py:59:        summary=f"{step} rejected: agent did not submit verdict via litehive report CLI",
litehive/agents/parsing.py:61:        warnings=["Agent did not submit verdict via litehive report CLI."],
litehive/agents/manager.py:330:                verdict="blocked",
litehive/tasks/queue_management.py:104:            "verdict": None,
litehive/pipeline/compat.py:51:                        last_verdict="pass" if result.final_stage == "done" else "fail",
litehive/cli/workspace.py:340:            print(f"flagged: {task.id} stage={_active_stage(task)} reason={task.flag_reason or 'unknown'} last_verdict={_last_verdict(task)} summary={_last_summary(task)}")
litehive/cli/workspace.py:398:def _last_verdict(task) -> str:
litehive/cli/workspace.py:399:    return task.runtime.last_stage.verdict or task.runtime.last_outcome.kind or "-"
tests/test_pipeline_v2_heru_factory.py:6:from litehive.pipeline.heru_factory import HeruEngineAdapter, _latest_verdict_after
tests/test_pipeline_v2_heru_factory.py:7:from litehive.pipeline.nodes.agent import AgentVerdict
tests/test_pipeline_v2_heru_factory.py:52:        "litehive.pipeline.heru_factory._latest_verdict_after",
tests/test_pipeline_v2_heru_factory.py:53:        lambda *args, **kwargs: AgentVerdict(outcome="pass", reason="ok"),
tests/test_pipeline_v2_heru_factory.py:56:    verdict = adapter.run_turn(
tests/test_pipeline_v2_heru_factory.py:68:    assert verdict.outcome == "pass"
tests/test_pipeline_v2_heru_factory.py:88:        "litehive.pipeline.heru_factory._latest_verdict_after",
tests/test_pipeline_v2_heru_factory.py:89:        lambda *args, **kwargs: AgentVerdict(outcome="pass", reason="ok"),
tests/test_pipeline_v2_heru_factory.py:107:def test_latest_verdict_after_rejects_empty_implementing_pass(tmp_path, monkeypatch) -> None:
tests/test_pipeline_v2_heru_factory.py:117:            verdict="pass",
tests/test_pipeline_v2_heru_factory.py:126:    verdict = _latest_verdict_after(
tests/test_pipeline_v2_heru_factory.py:133:    assert verdict is not None
tests/test_pipeline_v2_heru_factory.py:134:    assert verdict.outcome == "reject"
tests/test_pipeline_v2_heru_factory.py:135:    assert "execution checkout is clean" in verdict.reason
tests/test_pipeline_v2_heru_factory.py:138:def test_latest_verdict_after_allows_real_implementing_pass(tmp_path, monkeypatch) -> None:
tests/test_pipeline_v2_heru_factory.py:148:            verdict="pass",
tests/test_pipeline_v2_heru_factory.py:157:    verdict = _latest_verdict_after(
tests/test_pipeline_v2_heru_factory.py:164:    assert verdict is not None
tests/test_pipeline_v2_heru_factory.py:165:    assert verdict.outcome == "pass"
litehive/pipeline/engines.py:9:   ``Engine`` protocol (``run_turn(session, prompt, state) → AgentVerdict``)
litehive/cli/runner.py:43:    app.command("report", help="Submit a stage verdict for the active task")(report_command)
litehive/cli/runner.py:253:    verdict: Annotated[str, typer.Option(click_type=choice(["pass", "fail", "reject", "comment"]))] = ...,
litehive/cli/runner.py:281:    normalized_verdict = "reject" if verdict == "fail" else verdict
litehive/cli/runner.py:282:    comment = TaskThreadComment(role=role, step=step, verdict=normalized_verdict, message=message, files_changed=list(files_changed or []))
litehive/cli/runner.py:286:    print(f"verdict: {comment.verdict}")
litehive/pipeline/heru_factory.py:14:  - SubagentResult → ``AgentVerdict`` via the verdict reader, which checks
litehive/pipeline/heru_factory.py:31:    AgentVerdict,
litehive/pipeline/heru_factory.py:70:def _latest_verdict_after(
litehive/pipeline/heru_factory.py:75:) -> AgentVerdict | None:
litehive/pipeline/heru_factory.py:77:    ``created_at`` is newer than ``after_ts``, mapped to an ``AgentVerdict``.
litehive/pipeline/heru_factory.py:90:        and c.verdict in {"pass", "reject", "blocked"}
litehive/pipeline/heru_factory.py:98:        and latest.verdict == "pass"
litehive/pipeline/heru_factory.py:101:        return AgentVerdict(
litehive/pipeline/heru_factory.py:108:    return AgentVerdict(
litehive/pipeline/heru_factory.py:109:        outcome=latest.verdict,
litehive/pipeline/heru_factory.py:133:    def run_turn(self, session: Session, prompt: Any, state: TaskState) -> AgentVerdict:
litehive/pipeline/heru_factory.py:174:        # Did the agent submit a verdict during this turn?
litehive/pipeline/heru_factory.py:175:        verdict = _latest_verdict_after(self.workspace_root, state.task_id, step, before_turn)
litehive/pipeline/heru_factory.py:176:        if verdict is None:
litehive/pipeline/heru_factory.py:181:        # If this was a grooming verdict, the planner may have embedded a
litehive/pipeline/heru_factory.py:188:            message = verdict.reason or ""
litehive/pipeline/heru_factory.py:191:        return verdict
litehive/pipeline/task_updates.py:1:"""Apply grooming-stage TASK_UPDATE changes from an agent's verdict comment.
litehive/pipeline/task_updates.py:21:Called from ``HeruEngineAdapter.run_turn`` after the verdict reader
litehive/pipeline/task_updates.py:51:    verdict: str = "pass"
litehive/pipeline/task_updates.py:79:    """Apply any task field updates embedded in an agent's verdict message.
litehive/pipeline/nodes/agent.py:62:    """Agent finished its turn without submitting a verdict — nudge it.
litehive/pipeline/nodes/agent.py:67:    agent to submit a verdict. A separate ``nudge_budget`` applies; nudges
litehive/pipeline/nodes/agent.py:74:class AgentVerdict:
litehive/pipeline/nodes/agent.py:83:    def run_turn(self, session: Any, prompt: Any, state: TaskState) -> AgentVerdict: ...
litehive/pipeline/nodes/agent.py:133:              try: verdict = engine.run_turn(session, prompt, state)
litehive/pipeline/nodes/agent.py:173:        # ignores the first reminder to submit a verdict, a second reminder is
litehive/pipeline/nodes/agent.py:195:                "You finished your last turn without submitting a verdict via "
litehive/pipeline/nodes/agent.py:196:                "`litehive report --verdict <pass|reject|blocked>`. Please "
litehive/pipeline/nodes/agent.py:197:                "review your work and submit your verdict now."
litehive/pipeline/nodes/agent.py:239:        Returns an ``Event`` when the outcome is resolved (verdict or
litehive/pipeline/nodes/agent.py:265:                verdict = engine.run_turn(session, current_prompt, state)
litehive/pipeline/nodes/agent.py:267:                return self._verdict_to_event(verdict)
litehive/pipeline/nodes/agent.py:272:                        message=f"agent did not submit a verdict after {nudges_used} nudges: {exc}",
litehive/pipeline/nodes/agent.py:296:    def _verdict_to_event(self, verdict: AgentVerdict) -> Event:
litehive/pipeline/nodes/agent.py:297:        outcome = verdict.outcome.lower()
litehive/pipeline/nodes/agent.py:299:            return Pass(metadata=dict(verdict.metadata or {}))
litehive/pipeline/nodes/agent.py:301:            return Reject(source="agent", reason=verdict.reason)
litehive/pipeline/nodes/agent.py:303:            return Blocked(reason=verdict.reason)
litehive/pipeline/nodes/agent.py:304:        return Crash(exc_type="UnknownVerdict", message=verdict.outcome)
litehive/observability/status.py:228:                f"last_report={runtime.last_stage.step}/{runtime.last_stage.verdict} "
litehive/observability/status.py:395:    verdict = outcome.kind or task.runtime.last_stage.verdict or "-"
litehive/observability/status.py:397:    lines.append(f"  {task.id} {task.title} verdict={verdict} at {when}")
litehive/observability/status.py:507:        if data.get("verdict"):
litehive/observability/status.py:508:            detail_parts.append(f"verdict={data['verdict']}")
tests/test_pipeline_v2_end_to_end.py:29:from litehive.pipeline.nodes.agent import AgentVerdict, Engine, TransientError
tests/test_pipeline_v2_end_to_end.py:41:    """Always returns a ``pass`` verdict. One engine, one name."""
tests/test_pipeline_v2_end_to_end.py:45:    def run_turn(self, session: Any, prompt: Any, state: Any) -> AgentVerdict:
tests/test_pipeline_v2_end_to_end.py:49:        return AgentVerdict(outcome="pass")
tests/test_pipeline_v2_end_to_end.py:72:    """Emits verdicts driven by the target node name so the test can script per-stage outcomes."""
tests/test_pipeline_v2_end_to_end.py:77:    def run_turn(self, session: Any, prompt: Any, state: Any) -> AgentVerdict:
tests/test_pipeline_v2_end_to_end.py:82:            return AgentVerdict(outcome="resume", metadata={"target_stage": state.origin_stage or "implementing"})
tests/test_pipeline_v2_end_to_end.py:83:        return AgentVerdict(outcome=outcome)
tests/test_pipeline_v2_end_to_end.py:228:    def run_turn(self, session: Any, prompt: Any, state: Any) -> AgentVerdict:
tests/test_pipeline_v2_end_to_end.py:232:        return AgentVerdict(outcome="pass")
tests/test_pipeline_v2_end_to_end.py:263:    def run_turn(self, session: Any, prompt: Any, state: Any) -> AgentVerdict:
tests/test_pipeline_v2_end_to_end.py:299:            return AgentVerdict(outcome="reject", reason=f"fail at {state.stage}")
tests/test_pipeline_v2_end_to_end.py:300:        return AgentVerdict(outcome="pass")
litehive/pipeline/agents/recovery.py:4:from ..nodes.agent import AgentVerdict
litehive/pipeline/agents/recovery.py:15:  - `litehive task logs <task_id>` — task journal (v1 style) with stage entries, verdict submissions, and operator notes.
litehive/pipeline/agents/recovery.py:19:  - `.litehive/tasks/<task_id>/comments.yaml` — verdict history (`thread.yaml` is legacy fallback during migration).
litehive/pipeline/agents/recovery.py:22:- Your job is not to redo the failed stage's work, not to re-run the task's implementation or verification, and not to submit the failed stage verdict on the previous agent's behalf.
litehive/pipeline/agents/recovery.py:28:- Submit your own recovery verdict describing the root cause, the Litehive fix you made, and why the failed stage should be retried.
litehive/pipeline/agents/recovery.py:39:    Verdict mapping differs from a regular stage agent: recovery emits
litehive/pipeline/agents/recovery.py:60:    def _verdict_to_event(self, verdict: AgentVerdict) -> Event:
litehive/pipeline/agents/recovery.py:61:        outcome = verdict.outcome.lower()
litehive/pipeline/agents/recovery.py:63:            return RecoverySucceeded(resume=verdict.metadata.get("target_stage") or "")
litehive/pipeline/agents/recovery.py:65:            target = verdict.metadata.get("target_stage", "")
litehive/pipeline/agents/recovery.py:71:        return RecoveryFailed(reason=verdict.reason or "recovery_failed")
litehive/pipeline/events.py:35:        the agent submits a ``pass`` verdict via ``litehive report``.
litehive/pipeline/events.py:43:    ``metadata`` carries the verdict's ``files_changed`` / ``tests_added``
litehive/pipeline/events.py:135:    Fired by agent nodes when the agent submits a ``blocked`` verdict —
litehive/pipeline/events.py:207:    """The recovery agent returned a successful verdict.
litehive/pipeline/events.py:209:    Fired only by ``RecoveryAgent._verdict_to_event`` in response to a
litehive/pipeline/events.py:224:    Fired only by ``RecoveryAgent._verdict_to_event`` when the recovery
litehive/pipeline/events.py:225:    verdict is anything other than ``resume`` / ``advance`` / ``done`` /
litehive/pipeline/events.py:237:    Fired by ``RecoveryAgent._verdict_to_event`` when the agent returns
litehive/cli/agent_cli.py:3:When ``LITEHIVE_AGENT_ROLE`` is set, agents use ``litehive agent report``
litehive/cli/agent_cli.py:4:instead of ``litehive report``. The verdict options are restricted per role
litehive/cli/agent_cli.py:5:so agents literally cannot submit verdicts they're not allowed to use.
litehive/cli/agent_cli.py:27:VERDICT_ALLOWLIST: dict[str, set[str]] = {
litehive/cli/agent_cli.py:55:@agent_app.command("report", help="Submit your stage verdict")
litehive/cli/agent_cli.py:57:    verdict: Annotated[str, typer.Option("--verdict", help="pass, reject, or blocked")],
litehive/cli/agent_cli.py:76:    normalized_verdict = "reject" if verdict == "fail" else verdict.strip().lower()
litehive/cli/agent_cli.py:78:    allowed = VERDICT_ALLOWLIST.get(agent_role, {"pass", "reject", "blocked"})
litehive/cli/agent_cli.py:79:    if normalized_verdict not in allowed:
litehive/cli/agent_cli.py:108:        verdict=normalized_verdict,
litehive/cli/agent_cli.py:115:    print(f"verdict: {normalized_verdict}")
litehive/cli/app.py:59:app.add_typer(agent_app, name="agent", help="Agent-restricted commands (verdict submission)")
litehive/pipeline/agents/guidance.py:14:        "Do not redo the failed stage's work, do not implement the task itself, and do not submit the failed stage's verdict on the prior agent's behalf.",
litehive/pipeline/agents/guidance.py:16:        "Submit your own recovery verdict describing the Litehive root cause you found, the fix you made, and why the failed stage should be retried.",
litehive/pipeline/agents/swe.py:9:- When you are done coding, submit `litehive report --verdict pass`. Your work will be checked by:
litehive/pipeline/agents/swe.py:13:- Do NOT submit `--verdict reject`. You are the implementer, not QA. If you cannot proceed at all, submit `--verdict blocked` with an explanation. Reject is for downstream stages (testing, accepting, hooks) to send work back to you, not for you to send work back to yourself.
litehive/pipeline/agents/swe.py:15:- **You own the whole codebase, not just your diff.** "Out of scope" and "not my job" are not valid excuses. If a failure blocks verification of your work, fix the failure. The task's acceptance criteria define what you must achieve; the path to get there (including fixing unrelated broken things) is your responsibility. If a fix requires non-trivial work outside the obvious scope, still fix it — and note it in your verdict message so the reviewer sees what you did and why. The alternative is getting stuck in retry loops where QA keeps failing on something you could have fixed in 30 seconds.
litehive/pipeline/agents/swe.py:18:- **If the work is already done:** run `git diff main...HEAD`, verify each acceptance criterion is met, then submit `--verdict pass` with concrete evidence (test output, command output, file contents that prove each criterion). QA and the reviewer will verify your claim.
litehive/pipeline/agents/swe.py:19:- **If this is a duplicate of another task:** submit `--verdict pass` with evidence pointing at the original task (commit sha, task id, what it implemented). QA and the reviewer verify that the original task actually covers this one.
litehive/cli/task_debug_support.py:83:    # -- Verdict from thread --
litehive/cli/task_debug_support.py:84:    _print_verdict(root, task, ref.role)
litehive/cli/task_debug_support.py:93:                if isinstance(report_data, dict) and report_data.get("verdict"):
litehive/cli/task_debug_support.py:94:                    print(f"report_verdict: {report_data['verdict']}")
litehive/cli/task_debug_support.py:154:def _print_verdict(root, task, role):
litehive/cli/task_debug_support.py:155:    """Cross-reference task comments for the latest non-comment verdict matching the role."""
litehive/cli/task_debug_support.py:157:    verdict_entry = None
litehive/cli/task_debug_support.py:159:        if entry.role == role and entry.verdict != "comment":
litehive/cli/task_debug_support.py:160:            verdict_entry = entry
litehive/cli/task_debug_support.py:163:    if verdict_entry is not None:
litehive/cli/task_debug_support.py:164:        print(f"verdict: {verdict_entry.verdict}")
litehive/cli/task_debug_support.py:165:        print(f"verdict_step: {verdict_entry.step}")
litehive/cli/task_debug_support.py:166:        # Show first line of verdict message
litehive/cli/task_debug_support.py:167:        first_line = verdict_entry.message.split("\n", 1)[0][:120]
litehive/cli/task_debug_support.py:168:        print(f"verdict_message: {first_line}")
litehive/cli/task_debug_support.py:170:        print("verdict: none")
litehive/cli/pool.py:31:        verdict = str(report_data.get("verdict") or "").strip()
litehive/cli/pool.py:32:        if step and verdict:
litehive/cli/pool.py:33:            outcomes.append(f"{step}={verdict}")
litehive/cli/pool.py:49:    """Collect step/verdict/duration_seconds from all reports for a task."""
litehive/cli/pool.py:64:        verdict = str(data.get("verdict") or "").strip()
litehive/cli/pool.py:65:        if not step or not verdict:
litehive/cli/pool.py:69:        stats.append({"step": step, "verdict": verdict, "duration_seconds": duration})
litehive/cli/pool.py:91:            verdict = stat["verdict"]
litehive/cli/pool.py:96:            if verdict in ("pass", "accept"):
litehive/pipeline/agents/planner.py:7:- **You cannot submit --verdict reject.** Your job is to SHAPE tasks, not reject them. If the task as written is wrong, rewrite it via TASK_UPDATE. If it mixes concerns, split it: narrow the current task via TASK_UPDATE and create follow-up tasks via `litehive task add`. If it's genuinely not worth doing, close it with `outcome: wont_do` in TASK_UPDATE. If it's already done, close it with `outcome: duplicate`. The planner's only valid verdicts are `pass` and `blocked` (use blocked only if you literally cannot shape the task because of infrastructure failure).
```

```tool
output:
import pytest

from litehive.tasks import create_task, load_task_thread, require_task, set_active_task

from .helpers import (
    assert_nudge_verdict_submission,
    assert_successful_smoke_session,
    execute_engine_prompt,
    prepare_smoke_session,
    require_real_engine,
)


pytestmark = pytest.mark.integration


@pytest.fixture(scope="module")
def codex_smoke_session(module_integration_root):
    return prepare_smoke_session("codex", cwd=module_integration_root)


def test_codex_smoke_prompt_succeeds(codex_smoke_session) -> None:
    assert_successful_smoke_session(codex_smoke_session)


def test_codex_can_invoke_litehive_report_and_persist_thread_comment(integration_root) -> None:
    require_real_engine("codex")
    task = create_task(integration_root, title="Integration report task", auto_commit=False)
    set_active_task(integration_root, task.id)
    prompt = (
        f'Run `litehive report --verdict pass --role swe --step implementing --task-id {task.id} '
        '--workspace . --message "integration report from codex"` exactly once.'
    )
    _, execution = execute_engine_prompt("codex", prompt=prompt, cwd=integration_root)
    assert execution.exit_code == 0, execution.transcript
    thread = load_task_thread(integration_root, require_task(integration_root, task.id))
    assert thread[-1].role == "swe"
    assert thread[-1].step == "implementing"
    assert thread[-1].verdict == "pass"
    assert thread[-1].message == "integration report from codex"


def test_codex_nudge_submits_verdict_via_cli(codex_smoke_session) -> None:
    assert_nudge_verdict_submission("codex", smoke_session=codex_smoke_session)
```

I’m checking the exact `TASK_UPDATE` shape the runner expects so the grooming report can update the task record cleanly on pass. After that I’ll write the final scoped contract and submit the planner verdict.

```tool
output:
"""Apply grooming-stage TASK_UPDATE changes from an agent's verdict comment.

Grooming agents can emit either:

1. A structured ``TASK_UPDATE:`` YAML block in their report message, or
2. Plain-text ``ACCEPTANCE_CRITERIA: / PLAN: / CONSTRAINTS: /
   PM_COMPLEXITY: / PLANNED_EFFORT:`` sections.

Both paths funnel into ``litehive.workspace.workflow.apply_task_updates_from_report``,
which expects a ``StageReport``-shaped object with ``task_update`` (dict)
and ``feedback`` (text) fields.

Agents submit via ``litehive report``, which writes a ``TaskThreadComment``
with only a plain ``message`` string — no structured ``task_update``
field. So this module constructs a shim object carrying the comment's
message as ``feedback`` (letting the text-section extractors run) and
passes it through. If the comment's message happens to contain a YAML
``TASK_UPDATE:`` block, we parse it and set ``task_update`` on the
shim so the structured path runs.

Called from ``HeruEngineAdapter.run_turn`` after the verdict reader
detects a fresh agent submission.
"""

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from litehive.models import TaskRecord


_TASK_UPDATE_BLOCK = re.compile(
    r"^TASK_UPDATE:\s*\n(.*?)(?=\n\s*\n|\Z)",
    re.MULTILINE | re.DOTALL,
)


@dataclass
class _ReportShim:
    """Minimal duck-typed object that ``apply_task_updates_from_report`` reads."""

    task_update: dict[str, Any] | None = None
    feedback: str = ""
    files_changed: list[str] = field(default_factory=list)
    tests: dict[str, Any] | None = None
    warnings: list[str] = field(default_factory=list)
    summary: str = ""
    verdict: str = "pass"


def extract_yaml_block(message: str) -> dict[str, Any] | None:
    """Pull a ``TASK_UPDATE:`` YAML block out of the message if present."""
    if not message:
        return None
    match = _TASK_UPDATE_BLOCK.search(message)
    if not match:
        return None
    body = match.group(1).strip()
    if not body:
        return None
    try:
        parsed = yaml.safe_load(body)
    except yaml.YAMLError:
        return None
    if isinstance(parsed, dict):
        return parsed
    return None


def apply_task_updates_from_comment(
    workspace_root: Path,
    task: TaskRecord,
    *,
    message: str,
) -> bool:
    """Apply any task field updates embedded in an agent's verdict message.

    Returns True if anything was applied, False otherwise. Errors from
    the underlying apply path are swallowed and logged to stderr —
    a malformed TASK_UPDATE shouldn't fail the pipeline.
    """
    from litehive.workspace.workflow import apply_task_updates_from_report

    shim = _ReportShim(
        task_update=extract_yaml_block(message),
        feedback=message or "",
    )
    try:
        return apply_task_updates_from_report(workspace_root, task, shim)
    except Exception as exc:
        import sys

        print(
            f"[task_updates] ignored error applying task update: {exc}",
            file=sys.stderr,
        )
        return False
```

```tool
output:
"""Tests for TASK_UPDATE application from grooming verdict comments.

Exercises both paths that ``apply_task_updates_from_comment`` has to
handle: (1) a structured YAML block the planner embeds in its message,
and (2) plain-text section extraction as a fallback.
"""

from pathlib import Path

import pytest

from litehive.pipeline.task_updates import (
    extract_yaml_block,
    apply_task_updates_from_comment,
)
from litehive.tasks.crud import create_task, get_task

from tests.workspace_helpers import ensure_workspace


@pytest.fixture
def workspace(tmp_path: Path) -> Path:
    ensure_workspace(tmp_path)
    return tmp_path


def test_extract_yaml_block_pulls_task_update_section() -> None:
    msg = """Verdict: pass.

TASK_UPDATE:
goal: Build the thing
acceptance_criteria:
  - First criterion
  - Second criterion

Summary: done."""
    parsed = extract_yaml_block(msg)
    assert parsed is not None
    assert parsed["goal"] == "Build the thing"
    assert parsed["acceptance_criteria"] == ["First criterion", "Second criterion"]


def test_apply_task_updates_from_comment_updates_task_record(workspace: Path) -> None:
    task = create_task(workspace, title="t", goal="placeholder")

    message = """Grooming pass.

TASK_UPDATE:
goal: Sharpened goal statement
acceptance_criteria:
  - The tool prints ok
  - Exit code is zero
plan:
  - Step one
  - Step two
"""

    applied = apply_task_updates_from_comment(workspace, task, message=message)
    assert applied is True

    reloaded = get_task(workspace, task.id)
    assert reloaded.goal == "Sharpened goal statement"
    assert reloaded.acceptance_criteria == ["The tool prints ok", "Exit code is zero"]
    assert reloaded.plan == ["Step one", "Step two"]
```

```tool
output:
    """Exit if the current role is not in ``allowed``."""
    role = _current_role()
    if role is None or role not in allowed:
        print("You are not authorized to perform this command.")
        raise typer.Exit(1)
    return role


@agent_app.command("update", help="Update task fields (planner/reviewer only)")
def agent_update_command(
    task_id: Annotated[str | None, typer.Option("--task-id")] = None,
    workspace: Annotated[Path, typer.Option("--workspace")] = Path.cwd(),
    goal: Annotated[str | None, typer.Option("--goal")] = None,
    acceptance_criteria: Annotated[list[str] | None, typer.Option("--acceptance-criteria")] = None,
    plan: Annotated[list[str] | None, typer.Option("--plan-step")] = None,
    constraints: Annotated[list[str] | None, typer.Option("--constraint")] = None,
    pm_complexity: Annotated[str | None, typer.Option("--pm-complexity")] = None,
    planned_effort: Annotated[str | None, typer.Option("--planned-effort")] = None,
    priority: Annotated[str | None, typer.Option("--priority")] = None,
) -> None:
    _require_role({"planner", "reviewer"})

    from litehive.workspace.task_status import update_task

    tid = task_id or os.environ.get("LITEHIVE_TASK_ID")
    if not tid:
        raise typer.Exit(1)
    try:
        root = resolve_workspace(tid, workspace=workspace)
    except ValueError:
        raise typer.Exit(1)

    sentinel = ...
    update_task(
        root,
        tid,
        goal=goal if goal is not None else sentinel,
        acceptance_criteria=acceptance_criteria if acceptance_criteria is not None else sentinel,
        plan=plan if plan is not None else sentinel,
        constraints=constraints if constraints is not None else sentinel,
        pm_complexity=pm_complexity if pm_complexity is not None else sentinel,
        planned_effort=planned_effort if planned_effort is not None else sentinel,
        priority=priority if priority is not None else sentinel,
    )
    print(f"task: {tid}")
    print("updated: ok")


@agent_app.command("close", help="Close a task (planner/reviewer only)")
def agent_close_command(
    task_id: Annotated[str | None, typer.Option("--task-id")] = None,
    workspace: Annotated[Path, typer.Option("--workspace")] = Path.cwd(),
    outcome: Annotated[str, typer.Option("--outcome", help="duplicate, deferred, or wont_do")] = "duplicate",
    reason: Annotated[str, typer.Option("--reason")] = "",
) -> None:
    _require_role({"planner", "reviewer"})

    from litehive.workspace.task_status import close_task

    tid = task_id or os.environ.get("LITEHIVE_TASK_ID")
    if not tid:
        raise typer.Exit(1)
    try:
        root = resolve_workspace(tid, workspace=workspace)
    except ValueError:
        raise typer.Exit(1)

    close_task(root, tid, outcome=outcome, reason=reason)
    print(f"task: {tid}")
    print(f"outcome: {outcome}")
```

```tool
output:
litehive/workspace/task_status.py:17:    VALID_PLANNED_EFFORTS,
litehive/workspace/task_status.py:436:_CLOSE_OUTCOME_REASON_CODES = {"wont_do", "deferred", "duplicate", "execution_cancelled"}
litehive/workspace/task_status.py:464:    if outcome not in _CLOSE_OUTCOME_REASON_CODES:
litehive/workspace/task_status.py:465:        allowed = ", ".join(sorted(_CLOSE_OUTCOME_REASON_CODES))
litehive/workspace/task_status.py:564:    pm_complexity: str | None | object = ...,
litehive/workspace/task_status.py:565:    planned_effort: str | None | object = ...,
litehive/workspace/task_status.py:568:    auto_commit: bool | object = ...,
litehive/workspace/task_status.py:570:    outcome_reason: str | None | object = ...,
litehive/workspace/task_status.py:597:                str(outcome_reason)
litehive/workspace/task_status.py:598:                if outcome_reason is not ... and outcome_reason is not None
litehive/workspace/task_status.py:601:            if outcome_str not in _CLOSE_OUTCOME_REASON_CODES:
litehive/workspace/task_status.py:602:                allowed = ", ".join(sorted(_CLOSE_OUTCOME_REASON_CODES))
litehive/workspace/task_status.py:731:        if pm_complexity is not ...:
litehive/workspace/task_status.py:732:            if pm_complexity is not None and pm_complexity not in VALID_PM_COMPLEXITIES:
litehive/workspace/task_status.py:733:                raise ValueError(f"Unsupported PM complexity '{pm_complexity}'")
litehive/workspace/task_status.py:734:            task.pm_complexity = pm_complexity  # type: ignore[assignment]
litehive/workspace/task_status.py:736:        if planned_effort is not ...:
litehive/workspace/task_status.py:737:            if planned_effort is not None and planned_effort not in VALID_PLANNED_EFFORTS:
litehive/workspace/task_status.py:738:                raise ValueError(f"Unsupported planned effort '{planned_effort}'")
litehive/workspace/task_status.py:739:            task.planned_effort = planned_effort  # type: ignore[assignment]
litehive/workspace/task_status.py:761:        if auto_commit is not ...:
litehive/workspace/task_status.py:762:            task.git.auto_commit = auto_commit
litehive/workspace/workflow.py:104:def apply_task_updates_from_report(root: Path, task: TaskRecord, report: "object") -> bool:
litehive/workspace/workflow.py:108:    from litehive.tasks.constants import VALID_PLANNED_EFFORTS, VALID_PM_COMPLEXITIES
litehive/workspace/workflow.py:154:    pm_complexity = extract_report_line(feedback, "PM_COMPLEXITY")
litehive/workspace/workflow.py:155:    if "pm_complexity" not in updates and pm_complexity in VALID_PM_COMPLEXITIES:
litehive/workspace/workflow.py:156:        updates["pm_complexity"] = pm_complexity
litehive/workspace/workflow.py:158:    planned_effort = extract_report_line(feedback, "PLANNED_EFFORT")
litehive/workspace/workflow.py:159:    if "planned_effort" not in updates and planned_effort in VALID_PLANNED_EFFORTS:
litehive/workspace/workflow.py:160:        updates["planned_effort"] = planned_effort
litehive/workspace/workflow.py:177:        pm_complexity=updates.get("pm_complexity", ...),
litehive/workspace/workflow.py:178:        planned_effort=updates.get("planned_effort", ...),
litehive/workspace/workflow.py:186:        auto_commit=updates.get("auto_commit", ...),
litehive/workspace/workflow.py:188:        outcome_reason=updates.get("outcome_reason", ...),
litehive/workspace/task_status.py:17:    VALID_PLANNED_EFFORTS,
litehive/workspace/task_status.py:436:_CLOSE_OUTCOME_REASON_CODES = {"wont_do", "deferred", "duplicate", "execution_cancelled"}
litehive/workspace/task_status.py:464:    if outcome not in _CLOSE_OUTCOME_REASON_CODES:
litehive/workspace/task_status.py:465:        allowed = ", ".join(sorted(_CLOSE_OUTCOME_REASON_CODES))
litehive/workspace/task_status.py:564:    pm_complexity: str | None | object = ...,
litehive/workspace/task_status.py:565:    planned_effort: str | None | object = ...,
litehive/workspace/task_status.py:568:    auto_commit: bool | object = ...,
litehive/workspace/task_status.py:570:    outcome_reason: str | None | object = ...,
litehive/workspace/task_status.py:597:                str(outcome_reason)
litehive/workspace/task_status.py:598:                if outcome_reason is not ... and outcome_reason is not None
litehive/workspace/task_status.py:601:            if outcome_str not in _CLOSE_OUTCOME_REASON_CODES:
litehive/workspace/task_status.py:602:                allowed = ", ".join(sorted(_CLOSE_OUTCOME_REASON_CODES))
litehive/workspace/task_status.py:731:        if pm_complexity is not ...:
litehive/workspace/task_status.py:732:            if pm_complexity is not None and pm_complexity not in VALID_PM_COMPLEXITIES:
litehive/workspace/task_status.py:733:                raise ValueError(f"Unsupported PM complexity '{pm_complexity}'")
litehive/workspace/task_status.py:734:            task.pm_complexity = pm_complexity  # type: ignore[assignment]
litehive/workspace/task_status.py:736:        if planned_effort is not ...:
litehive/workspace/task_status.py:737:            if planned_effort is not None and planned_effort not in VALID_PLANNED_EFFORTS:
litehive/workspace/task_status.py:738:                raise ValueError(f"Unsupported planned effort '{planned_effort}'")
litehive/workspace/task_status.py:739:            task.planned_effort = planned_effort  # type: ignore[assignment]
litehive/workspace/task_status.py:761:        if auto_commit is not ...:
litehive/workspace/task_status.py:762:            task.git.auto_commit = auto_commit
litehive/workspace/workflow.py:104:def apply_task_updates_from_report(root: Path, task: TaskRecord, report: "object") -> bool:
litehive/workspace/workflow.py:108:    from litehive.tasks.constants import VALID_PLANNED_EFFORTS, VALID_PM_COMPLEXITIES
litehive/workspace/workflow.py:154:    pm_complexity = extract_report_line(feedback, "PM_COMPLEXITY")
litehive/workspace/workflow.py:155:    if "pm_complexity" not in updates and pm_complexity in VALID_PM_COMPLEXITIES:
litehive/workspace/workflow.py:156:        updates["pm_complexity"] = pm_complexity
litehive/workspace/workflow.py:158:    planned_effort = extract_report_line(feedback, "PLANNED_EFFORT")
litehive/workspace/workflow.py:159:    if "planned_effort" not in updates and planned_effort in VALID_PLANNED_EFFORTS:
litehive/workspace/workflow.py:160:        updates["planned_effort"] = planned_effort
litehive/workspace/workflow.py:177:        pm_complexity=updates.get("pm_complexity", ...),
litehive/workspace/workflow.py:178:        planned_effort=updates.get("planned_effort", ...),
litehive/workspace/workflow.py:186:        auto_commit=updates.get("auto_commit", ...),
litehive/workspace/workflow.py:188:        outcome_reason=updates.get("outcome_reason", ...),
litehive/config/model.py:54:    auto_commit: bool = True
litehive/tasks/crud.py:31:    VALID_PLANNED_EFFORTS,
litehive/tasks/crud.py:257:    pm_complexity: str | None = None,
litehive/tasks/crud.py:258:    planned_effort: str | None = None,
litehive/tasks/crud.py:260:    auto_commit: bool = True,
litehive/tasks/crud.py:274:    if pm_complexity is not None and pm_complexity not in VALID_PM_COMPLEXITIES:
litehive/tasks/crud.py:275:        raise ValueError(f"Unsupported PM complexity '{pm_complexity}'")
litehive/tasks/crud.py:276:    if planned_effort is not None and planned_effort not in VALID_PLANNED_EFFORTS:
litehive/tasks/crud.py:277:        raise ValueError(f"Unsupported planned effort '{planned_effort}'")
litehive/tasks/crud.py:299:            pm_complexity=pm_complexity,  # type: ignore[arg-type]
litehive/tasks/crud.py:300:            planned_effort=planned_effort,  # type: ignore[arg-type]
litehive/tasks/crud.py:304:                "auto_commit": auto_commit,
litehive/tasks/crud.py:389:                    "auto_commit": True,
litehive/tasks/__init__.py:7:    "VALID_PLANNED_EFFORTS": (".constants", "VALID_PLANNED_EFFORTS"),
litehive/tasks/constants.py:13:VALID_PLANNED_EFFORTS = set(get_args(PlannedEffort))
litehive/tasks/templates.py:314:        f"- PM complexity: {task.pm_complexity or '-'}",
litehive/tasks/templates.py:315:        f"- Planned effort: {task.planned_effort or '-'}",
litehive/tasks/templates.py:340:    lines.append(f"- Complexity: {task.pm_complexity or 'Not estimated.'}")
litehive/tasks/templates.py:341:    lines.append(f"- Planned effort: {task.planned_effort or 'Not sized.'}")
litehive/models/task_models.py:62:    auto_commit: bool = True
litehive/models/task_models.py:73:    auto_commit: bool = True
litehive/models/task_models.py:95:    pm_complexity: TaskComplexity | None = None
litehive/models/task_models.py:96:    planned_effort: PlannedEffort | None = None
litehive/models/task_models.py:136:    pm_complexity: TaskComplexity | None = None
litehive/models/task_models.py:137:    planned_effort: PlannedEffort | None = None
litehive/models/task_models.py:163:            pm_complexity=self.pm_complexity,
litehive/models/task_models.py:164:            planned_effort=self.planned_effort,
litehive/models/task_models.py:172:                auto_commit=self.git.auto_commit,
litehive/cli/import_cli.py:284:                    auto_commit=True,
litehive/cli/task_cli.py:116:    print(f"pm_complexity: {task.pm_complexity or '-'}")
litehive/cli/task_cli.py:117:    print(f"planned_effort: {task.planned_effort or '-'}")
litehive/cli/task_cli.py:223:    print(f"pm_complexity: {task.pm_complexity or '-'}")
litehive/cli/task_cli.py:224:    print(f"planned_effort: {task.planned_effort or '-'}")
litehive/cli/task_cli.py:379:            pm_complexity=updates.get("pm_complexity", ...),
litehive/cli/task_cli.py:380:            planned_effort=updates.get("planned_effort", ...),
litehive/cli/task_cli.py:387:            auto_commit=updates.get("auto_commit", ...),
litehive/cli/task_cli.py:396:    print(f"pm_complexity: {task.pm_complexity or '-'}")
litehive/cli/task_cli.py:397:    print(f"planned_effort: {task.planned_effort or '-'}")
litehive/cli/task_cli.py:399:    print(f"auto_commit: {task.git.auto_commit}")
litehive/cli/templates/workspace_config.yaml:105:auto_commit: true
litehive/cli/parse.py:11:    VALID_PLANNED_EFFORTS,
litehive/cli/parse.py:157:    "pm_complexity",
litehive/cli/parse.py:158:    "planned_effort",
litehive/cli/parse.py:166:    "auto_commit",
litehive/cli/parse.py:168:    "outcome_reason",
litehive/cli/parse.py:228:    if "pm_complexity" in data:
litehive/cli/parse.py:229:        pm_complexity = data["pm_complexity"]
litehive/cli/parse.py:230:        if pm_complexity is not None and pm_complexity not in VALID_PM_COMPLEXITIES:
litehive/cli/parse.py:232:            raise ValueError(f"{source} field 'pm_complexity' must be one of: {allowed}, or null")
litehive/cli/parse.py:233:        updates["pm_complexity"] = pm_complexity
litehive/cli/parse.py:235:    if "planned_effort" in data:
litehive/cli/parse.py:236:        planned_effort = data["planned_effort"]
litehive/cli/parse.py:237:        if planned_effort is not None and planned_effort not in VALID_PLANNED_EFFORTS:
litehive/cli/parse.py:238:            allowed = ", ".join(sorted(VALID_PLANNED_EFFORTS))
litehive/cli/parse.py:239:            raise ValueError(f"{source} field 'planned_effort' must be one of: {allowed}, or null")
litehive/cli/parse.py:240:        updates["planned_effort"] = planned_effort
litehive/cli/parse.py:298:    if "auto_commit" in data:
litehive/cli/parse.py:299:        auto_commit = data["auto_commit"]
litehive/cli/parse.py:300:        if not isinstance(auto_commit, bool):
litehive/cli/parse.py:301:            raise ValueError(f"{source} field 'auto_commit' must be true or false")
litehive/cli/parse.py:302:        updates["auto_commit"] = auto_commit
litehive/cli/parse.py:312:    if "outcome_reason" in data:
litehive/cli/parse.py:313:        outcome_reason = data["outcome_reason"]
litehive/cli/parse.py:314:        if outcome_reason is not None and not isinstance(outcome_reason, str):
litehive/cli/parse.py:315:            raise ValueError(f"{source} field 'outcome_reason' must be a string or null")
litehive/cli/parse.py:316:        if outcome_reason is not None:
litehive/cli/parse.py:317:            updates["outcome_reason"] = outcome_reason
litehive/cli/parse.py:340:        "pm_complexity": task.pm_complexity,
litehive/cli/parse.py:341:        "planned_effort": task.planned_effort,
litehive/cli/parse.py:349:        "auto_commit": task.git.auto_commit,
litehive/agents/prompts.py:248:    lines.append(f"- Current PM complexity: {task.pm_complexity or '-'}")
litehive/agents/prompts.py:249:    lines.append(f"- Current planned effort: {task.planned_effort or '-'}")
litehive/agents/prompts.py:254:                "- Use `PM_COMPLEXITY: simple|moderate|complex`.",
litehive/agents/prompts.py:255:                "- Use `PLANNED_EFFORT: xs|s|m|l|xl`.",
litehive/agents/prompts.py:366:            "- During grooming, you can emit a structured `TASK_UPDATE:` YAML block to update any task field (goal, acceptance_criteria, constraints, plan, pm_complexity, planned_effort, priority, auto_commit, etc.).",
litehive/agents/prompts.py:367:            "- To close a task as duplicate, wont_do, or deferred, include `outcome: <status>` and optional `outcome_reason: <text>` in the TASK_UPDATE block.",
litehive/agents/prompts.py:368:            "- To park a task (pause without closing), include `action: park` in the TASK_UPDATE block.",
litehive/agents/prompts.py:380:            "- You may close a task as duplicate, wont_do, or deferred by including `outcome: <status>` with optional `outcome_reason` in a TASK_UPDATE block. You may park a task with `action: park`.",
litehive/cli/github_import.py:183:        auto_commit=True,
litehive/cli/agent_cli.py:136:    pm_complexity: Annotated[str | None, typer.Option("--pm-complexity")] = None,
litehive/cli/agent_cli.py:137:    planned_effort: Annotated[str | None, typer.Option("--planned-effort")] = None,
litehive/cli/agent_cli.py:160:        pm_complexity=pm_complexity if pm_complexity is not None else sentinel,
litehive/cli/agent_cli.py:161:        planned_effort=planned_effort if planned_effort is not None else sentinel,
litehive/pipeline/task_updates.py:7:   PM_COMPLEXITY: / PLANNED_EFFORT:`` sections.
litehive/pipeline/agents/reviewer.py:9:- You may close a task as duplicate, wont_do, or deferred by including `outcome: <status>` with optional `outcome_reason` in a TASK_UPDATE block. You may park a task with `action: park`.
litehive/observability/status.py:77:    if task.pm_complexity or task.planned_effort:
litehive/observability/status.py:79:            f"  pm_complexity={task.pm_complexity or '-'} planned_effort={task.planned_effort or '-'}"
litehive/observability/status.py:104:    lines.append(f"  auto_commit={task.git.auto_commit}")
litehive/pipeline/agents/planner.py:9:- During grooming, emit a structured `TASK_UPDATE:` YAML block to update any task field (goal, acceptance_criteria, constraints, plan, pm_complexity, planned_effort, priority, auto_commit, etc.).
litehive/pipeline/agents/planner.py:10:- To close a task as duplicate, wont_do, or deferred, include `outcome: <status>` and optional `outcome_reason: <text>` in the TASK_UPDATE block — then submit `pass`.
litehive/pipeline/agents/planner.py:11:- To park a task (pause without closing), include `action: park` in the TASK_UPDATE block — then submit `pass`.
"""Task state transition and persistence helpers."""

from pathlib import Path

from litehive.config import state_path
from litehive.models import TaskRecord, WorkspaceState, utcnow
from litehive.storage import runtime_store

from litehive.workspace.locking import workspace_mutation_guard
from litehive.tasks.paths import task_dir, task_file
from litehive.tasks.persistence import (
    load_state,
    serialize_state,
    write_atomic_files_and_then,
)


def workspace_transition_writes(
    root: Path,
    *,
    tasks: list[TaskRecord] | tuple[TaskRecord, ...] = (),
    state: WorkspaceState | None = None,
    journal_messages: dict[str, str] | None = None,
) -> dict[Path, str]:
    from litehive.tasks.crud import serialize_task_record

    writes: dict[Path, str] = {}
    for task in tasks:
        writes[task_file(root, task)] = serialize_task_record(task)
        if journal_messages is None or task.id not in journal_messages:
            continue
        journal_path = task_dir(root, task) / "journal.md"
        existing = journal_path.read_text(encoding="utf-8") if journal_path.exists() else ""
        writes[journal_path] = f"{existing}\n## {utcnow()}\n{journal_messages[task.id]}\n"
    if state is not None:
        state = merged_state_for_runner_owned_write(
            root,
            state=state,
            protected_task_ids=[task.id for task in tasks],
        )
        writes[state_path(root)] = serialize_state(state)
    return writes


def _merge_queue_preserving_future_changes(
    *,
    desired_queue: list[str],
    latest_queue: list[str],
    protected_task_ids: list[str] | tuple[str, ...],
) -> list[str]:
    protected: list[str] = []
    seen_protected: set[str] = set()
    for task_id in protected_task_ids:
        if task_id in seen_protected:
            continue
        seen_protected.add(task_id)
        protected.append(task_id)
    if not protected:
        return list(desired_queue)

    protected_set = set(protected)
    latest_unprotected = [task_id for task_id in latest_queue if task_id not in protected_set]
    protected_positions = [
        (
            sum(1 for preceding in desired_queue[:index] if preceding not in protected_set),
            task_id,
        )
        for index, task_id in enumerate(desired_queue)
        if task_id in protected_set
    ]
    if not protected_positions:
        return list(latest_unprotected)

    merged = list(latest_unprotected)
    inserted = 0
    inserted_ids: set[str] = set()
    for unprotected_before, task_id in protected_positions:
        if task_id in inserted_ids:
            continue
        insertion_index = min(unprotected_before + inserted, len(merged))
        merged.insert(insertion_index, task_id)
        inserted_ids.add(task_id)
        inserted += 1
    return merged


def merged_state_for_runner_owned_write(
    root: Path,
    *,
    state: WorkspaceState,
    protected_task_ids: list[str] | tuple[str, ...] = (),
) -> WorkspaceState:
    latest_state = load_state(root)
    merged_state = state.model_copy(deep=True)
    merged_state.queue = _merge_queue_preserving_future_changes(
        desired_queue=state.queue,
        latest_queue=latest_state.queue,
        protected_task_ids=protected_task_ids,
    )
    merged_state.next_task_number = max(state.next_task_number, latest_state.next_task_number)
    return merged_state


def apply_task_updates_from_report(root: Path, task: TaskRecord, report: "object") -> bool:
    """Apply structured and text-based task updates from a stage report."""
    from litehive.cli.parse import parse_rich_task_update_document

    from litehive.tasks.constants import VALID_PLANNED_EFFORTS, VALID_PM_COMPLEXITIES
    from litehive.tasks.journal import append_journal
    from litehive.tasks.normalization import (
        extract_report_line,
        extract_report_list_section,
        infer_acceptance_criteria,
        normalize_acceptance_criteria,
        normalize_task_text_list,
    )
    from litehive.workspace.task_status import update_task

    updates: dict[str, object] = {}

    # Preferred: structured task_update from STAGE_RESULT or TASK_UPDATE YAML block.
    if report.task_update:
        try:
            updates = parse_rich_task_update_document(
                report.task_update, source="report task_update"
            )
        except ValueError as exc:
            append_journal(root, task, f"Warning: Ignoring malformed task update in report: {exc}")

    # Fallback/Supplemental: text-based list sections.
    feedback = report.feedback
    if "acceptance_criteria" not in updates:
        text_criteria = normalize_acceptance_criteria(
            extract_report_list_section(feedback, "ACCEPTANCE_CRITERIA")
        )
        if not text_criteria and not task.acceptance_criteria:
            text_criteria = infer_acceptance_criteria(task)
        if text_criteria and not task.acceptance_criteria:
            updates["acceptance_criteria"] = text_criteria

    if "constraints" not in updates:
        text_constraints = normalize_task_text_list(
            extract_report_list_section(feedback, "CONSTRAINTS")
        )
        if text_constraints and not task.constraints:
            updates["constraints"] = text_constraints

    if "plan" not in updates:
        text_plan = normalize_task_text_list(extract_report_list_section(feedback, "PLAN"))
        if text_plan and not task.plan:
            updates["plan"] = text_plan

    # Fallback/Supplemental: PM sizing lines.
    pm_complexity = extract_report_line(feedback, "PM_COMPLEXITY")
    if "pm_complexity" not in updates and pm_complexity in VALID_PM_COMPLEXITIES:
        updates["pm_complexity"] = pm_complexity

    planned_effort = extract_report_line(feedback, "PLANNED_EFFORT")
    if "planned_effort" not in updates and planned_effort in VALID_PLANNED_EFFORTS:
        updates["planned_effort"] = planned_effort

    if not updates:
        return False

    journal_message = "Task record updated from grooming output:\n" + "\n".join(
        f"- {key}: `{value}`" for key, value in updates.items()
    )

    # Use update_task logic to apply updates.
    updated = update_task(
        root,
        task.id,
        goal=updates.get("goal", ...),
        acceptance_criteria=updates.get("acceptance_criteria", ...),
        constraints=updates.get("constraints", ...),
        plan=updates.get("plan", ...),
        pm_complexity=updates.get("pm_complexity", ...),
        planned_effort=updates.get("planned_effort", ...),
        depends_on=updates.get("depends_on", ...),
        human_checkpoints=updates.get("human_checkpoints", ...),
        task_type=updates.get("task_type", ...),
        mode=updates.get("mode", ...),
        priority=updates.get("priority", ...),
        model=updates.get("model", ...),
        retry_limit=updates.get("retry_limit", ...),
        auto_commit=updates.get("auto_commit", ...),
        outcome=updates.get("outcome", ...),
        outcome_reason=updates.get("outcome_reason", ...),
        action=updates.get("action", ...),
        journal_message=journal_message,
    )

    # Re-sync the passed-in task object so the caller sees the changes.
    for field_name in updated.__class__.model_fields:
        if field_name == "runtime":
            continue
        setattr(task, field_name, getattr(updated, field_name))

    return True


def persist_task_and_state(
    root: Path,
    *,
    task: TaskRecord,
    state: WorkspaceState,
    journal_message: str | None = None,
) -> None:
    persist_tasks_and_state(
        root,
        tasks=[task],
        state=state,
        journal_messages={task.id: journal_message} if journal_message is not None else None,
    )


def persist_tasks_and_state(
    root: Path,
    *,
    tasks: list[TaskRecord] | tuple[TaskRecord, ...],
    state: WorkspaceState,
    journal_messages: dict[str, str] | None = None,
) -> None:
    from litehive.tasks.crud import ensure_runtime_ignored, task_state_for_storage

    for task in tasks:
        task.updated_at = utcnow()
    writes = workspace_transition_writes(
        root,
        tasks=tasks,
        state=state,
        journal_messages=journal_messages,
    )
    with workspace_mutation_guard(root):
        merged_state = merged_state_for_runner_owned_write(
            root,
            state=state,
            protected_task_ids=[task.id for task in tasks],
        )
        write_atomic_files_and_then(
            writes,
            lambda: runtime_store(root).save_runtime_transaction(
                task_states={task.id: task_state_for_storage(task) for task in tasks},
                workspace_state=merged_state,
            ),
        )
        ensure_runtime_ignored(root)


def persist_tasks_and_state_without_runner_guard(
    root: Path,
    *,
    tasks: list[TaskRecord] | tuple[TaskRecord, ...],
    state: WorkspaceState,
    journal_messages: dict[str, str] | None = None,
) -> None:
    from litehive.tasks.crud import ensure_runtime_ignored, task_state_for_storage

    for task in tasks:
        task.updated_at = utcnow()
```

```tool
output:
"""Shared constants for the tasks package."""

import threading
from pathlib import Path
from typing import get_args

from litehive.models import PlannedEffort, TaskComplexity

VALID_TASK_PRIORITIES = {"low", "medium", "high", "critical"}
VALID_TASK_ENGINES = {"codex", "opencode", "gemini", "copilot", "claude", "goz"}
VALID_HUMAN_CHECKPOINTS = {"before_acceptance", "before_commit"}
VALID_PM_COMPLEXITIES = set(get_args(TaskComplexity))
VALID_PLANNED_EFFORTS = set(get_args(PlannedEffort))
VALID_TASK_TYPES = {"adapter", "bugfix", "docs", "intake", "refactor", "research", "review"}
TASK_PRIORITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}

MISSING = object()
# A live runner that hasn't refreshed its heartbeat in this many seconds is considered late.
HEARTBEAT_LATE_THRESHOLD_SECONDS = 60
CLOSED_TASK_STATUSES = {"cancelled", "wont_do", "deferred", "duplicate"}
RESUMABLE_TASK_STATUSES = {"interrupted", "parked"}

RUNNER_LOCKS: dict[Path, "_RunnerLockState"] = {}  # type: ignore[name-defined]
RUNNER_LOCKS_MUTEX = threading.Lock()

---
```

The only concrete failure evidence in the brief is Codex under bwrap. Claude is a plausible parallel case, but Copilot is still speculative from the current repo evidence, so I’m deciding whether to narrow this task and spin out an inventory follow-up instead of forcing one task to solve unknown engine state.

```tool
output:
You are not authorized to perform this command.
```

I’ve finished the task shaping. I’m submitting a grooming pass with a tightened contract that keeps Codex as the required unblocker, preserves the default-sandbox flipback, and avoids turning this task into an unbounded engine audit.

```tool
output:
task: T-0370
step: grooming
verdict: pass
role: planner
```

Submitted a grooming `pass` for `T-0370` with a rewritten task contract.

I narrowed the task around the confirmed Codex sandbox regression, kept the required end-to-end sandbox smoke and default re-enable, and explicitly constrained broader engine wiring so this doesn’t turn into an unbounded session-state audit. I also noted that a separate follow-up inventory task would be appropriate for speculative engines, but direct `litehive task add` was unauthorized in this workspace.

[stderr]
Reading additional input from stdin...
